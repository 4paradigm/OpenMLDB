Welcome to use PTest 0.1.0

PTest is a universal test framework for python based, linux background test tasks. 
Usage:
    Usage:
    options:
        [{-h, --help}]                  :  help list
        {-p project, --project=project} :  project name
        [{-g group, --group=group}]     :  group name: grp_xx folder (MUST starts with 'grp')
        [{-s suite, --suite=suite}]     :  suite name: sut_xx.py (MUST starts with 'sut')
        [{--ps}] :customize execution steps:run project setup (used in debug test case)
        [{--pt}] :customize execution steps:run project teardown (used in debug test case)
        [{--rt}] :customize execution steps:run test cases including group and suite level(used in debug test case)
        [{--gs}] :customize execution steps:run group setup (used with '--rt' in debug test case)
        [{--gt}] :customize execution steps:run group teardown (used with '--rt' in debug test case)
        [{--ss}] :customize execution steps:run suite setup (used with '--rt' in debug test case)
        [{--st}] :customize execution steps:run suite teardown (used with '--rt' in debug test case)
        [{--tc}] :customize execution steps:run test methods in suite(used with '--rt' in debug test case)
        [{--rp}] :specify it needs to run report

    examples:
        ptest -p examples/ha3/subProjectName
        ptest -p examples/ha3/subProjectName -g examples/ha3/subProjectName/grp_xx
        ptest -p examples/ha3/subProjectName -g grp_xx
        ptest -p examples/ha3/subProjectName --ps
        ptest -p examples/ha3/subProjectName --rt
        ptest -p examples/ha3/subProjectName -g examples/ha3/subProjectName/grp_xx --rt
        ptest -p examples/ha3/subProjectName -s examples/ha3/subProjectName/grp_xx/sut_xx.py --rt
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt
        ptest -p examples/ha3/subProjectName -g grp_xx -s sut_xx.py --rt
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py testXX testXXX --rt
        ptest -p examples/ha3/subProjectName -g grp_xx --rt --gs
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt --ss
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt --gs --ss
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt --tc
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py testXX testXXX --rt --tc
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt --st
        ptest -p examples/ha3/subProjectName -s grp_xx/sut_xx.py --rt --st --gt
        ptest -p examples/ha3/subProjectName --pt


Options:
  -h, --help            show this help message and exit
  -p PROJECT, --project=PROJECT
                        specify the test project dir
  -g GROUP, --group=GROUP
                        specify the test group dir
  -s SUITE, --suite=SUITE
                        specify the test suite file
  --ps                  execute project setup
  --pt                  execute project teardown
  --rt                  execute test cases including groupSetUp, suiteSetUp,
                        caseSetup, test methods, caseTearDown, suiteTearDown,
                        groupTearDown
  --gs                  used with '--rt' together to execute group setup
  --gt                  used with '--rt' together to execute group teardown
  --ss                  used with '--rt' together to execute suite setup
  --st                  used with '--rt' together to execute suite teardown
  --tc                  used with '--rt' together to execute test methods
  --rp                  specify it needs to run report in case debug phase
