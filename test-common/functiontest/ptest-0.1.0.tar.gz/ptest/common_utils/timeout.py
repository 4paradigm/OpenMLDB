import signal
import time
import sys

class TimeoutError(Exception):
    def __init__(self, value = "Timed Out"):
        co = sys._getframe(2)
        date = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        self.value = str(date) + " " + co.f_code.co_filename + " " + str(co.f_lineno) + " " + str(value)

    def __str__(self):
        return repr(self.value)

def timeout(seconds_before_timeout):
    def decorate(f):
        def handler(signum, frame):
            raise TimeoutError()

        def new_f(*args, **kwargs):
            old = signal.signal(signal.SIGALRM, handler)
            signal.alarm(seconds_before_timeout)
            try:
                result = f(*args, **kwargs)
            finally:
                signal.signal(signal.SIGALRM, old)
            signal.alarm(0)
            return result

        new_f.func_name = f.func_name
        return new_f

    return decorate


##############################################################
# class Ha2ToolUtilsTest
##############################################################
class TestTimeOut:
    @timeout(2)
    def mytest(self):
        print "Start"
        for i in range(1,10):
            time.sleep(1)
            print "%d seconds have passed" % i


if __name__ == '__main__':
    a = TestTimeOut()
    a.mytest()
