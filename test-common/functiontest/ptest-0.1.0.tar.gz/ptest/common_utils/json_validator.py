#!/usr/bin/env python
import os;
import popen2
import sys;
import json

class JsonValidator:
    '''
    Validate json file!!
    '''
    def validateFile(self, file):
        f = open(file)
        content = f.read()
        f.close()
        ret =self.validateJsonString(content)
        if ret == False:
            print 'ERROR: Json file [%(file)s] Validate Fail!!!!' % {'file':file}
        return ret

    def validateJsonString(self, jsonString):
        try:
            obj = json.read(jsonString)
        except json.ReadException,xx:
            return False
        return True
    
    def validateDir(self, dir):
        topdown = True
        for root, dirs, files in os.walk(dir, topdown):
            for name in files:
                if name.startswith(".") or name.startswith("#"):
                    continue
                if not name.endswith(".json"):
                    continue
                file = os.path.join(root, name)
                if (self.validateFile(file) == True):
                    continue
                else:
                    return False

            for name in dirs:
                if (name == '.svn'):
                    dirs.remove(name)
                    continue
                pass
            pass
        return True


if __name__ == '__main__':
    jsonValidator = JsonValidator()
    retCode = jsonValidator.validateDir('/home/admin/jgr/console/')
    print 'retCode', retCode
