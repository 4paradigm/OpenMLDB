import time
import signal
import re
import os
import sys

class SystemWrapper(object):
    # description: start a new process to run a method with args as its parameters
    @classmethod
    def startMethodProcess(self, method, args=()):
        try:
            pid = os.fork()
        except OSError, e:
            print >>sys.stderr, "fork failed: errorCode[%d], errorMsg[%s]" % (e.errno, e.strerror)
            return -1
        
        if 0 == pid: #child process
            try:
                if method:
                    method(*args)
            except KeyboardInterrupt:
                pass
            exit(0)
        # parent
        return pid
    
    # description: start a new process to run a binary
    @classmethod
    def startBinaryProcess(self, processName, parameters=[], envVariables={}, workingDir=None):
        try:
            pid = os.fork()
        except OSError, e:
            print >>sys.stderr, "fork failed: errorCode[%d], errorMsg[%s]" % (e.errno, e.strerror)
            return -1
        if 0 == pid: 
            # child
            try:
                print "processName:", processName
                if workingDir is not None:
                    os.chdir(workingDir)
                os.setsid()
                os.umask(0)
                # os.close(1)
                # os.close(2)
                # sys.stdout = open('stdout.out', "w+") 
                # sys.stderr = open('stderr.out', "w+") 
                for key in envVariables.keys():
                    os.putenv(key, envVariables[key])
                os.execvp(processName, [processName] + parameters)
            except KeyboardInterrupt:
                pass
            exit(0)
        # parent
        return pid

    @classmethod
    def waitProcessExit(self, pid):
        if pid <= 0:
            return
        try:
            # supported in python 3.3
            # idType = os.P_PID
            # options = os.WEXITED | os.WSTOPPED| os.WNOWAIT
            # os.waitid(idType, pid, options)
            print "wait process exit, pid:", pid
            os.waitpid(pid, 0)
        except OSError:
            pass

    @classmethod
    def processDirExist(self, pid):
        processDir = "/proc/" + str(pid)
        if os.path.exists(processDir):
            print "processDir exist:", processDir
            return True
        return False

    @classmethod
    def killProcess(self, pid, signal=signal.SIGTERM):
        if (pid > 0):
            os.kill(pid, signal)

if __name__ == "__main__":
    # processName = "/bin/sleep"
    #args = ["20"]
    
    # processName = "/home/xiuping.duan/abench/src/app/abench"
    # args = "-m 5000 -p 48 -s 300 --http -o /home/xiuping.duan/local_perf_conf/query/error.log -k 10.250.12.39 9685 /home/xiuping.duan/zixun_query/query.txt".split()

    processName = "/home/xiuping.duan/atest/local_perf_test//workbench/localdb/usr/local/bin/local_searcher"
    args = "-w /home/xiuping.duan/atest/local_perf_test//temp/ha3/index/inc_build_update_index -c /home/xiuping.duan/atest/local_perf_test//temp/ha3/conf/search/inc_build_update_conf/0 -t 16 --address 10.250.12.39:9685 -s -p newssearch:0_0 -m perf".split()
    envVariables={}
    envVariables["LD_LIBRARY_PATH"] = "/home/xiuping.duan/atest/local_perf_test/workbench/localdb/usr/local/lib64:/home/xiuping.duan/atest/local_perf_test/workbench/localdb/usr/local/lib:/usr/local/lib64:/usr/local/lib:/usr/ali/java/jre/lib/amd64/server/"
    pid = SystemWrapper.start(processName, args, envVariables)
    print "pid:", pid
