import traceback

class FileUtils:
    @classmethod
    def read(self, file_name):
        strs = ""
        list = self.doRead(file_name)
        for str in list:
            strs = strs + str
        return strs

    @classmethod
    def doRead(self, file_name):
        list = []
        try:
            f = open(file_name, 'r')
            list = f.readlines()
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror)
        except ValueError:
            print "Could not convert data to an integer."
        except:
            print "Unexpected error:", sys.exc_info()[0]
        finally:
            try:
                f.close()
            except:
                print traceback.print_exc()
        return list

    @classmethod
    def write(self, strs, file_name):
        rst = False
        try:
            f = open(file_name, 'a')
            f.write(strs)
            rst = True
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror)
        except ValueError:
            print "Could not convert data to an integer."
        except:
            print "Unexpected error:", sys.exc_info()[0]
        finally:
            try:
                f.close()
            except:
                print traceback.print_exc()
        return rst

