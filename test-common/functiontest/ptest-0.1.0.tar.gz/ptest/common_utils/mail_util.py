#!/usr/bin/env python
#coding=utf-8

import re
import sys
import datetime
import smtplib
import base64
import optparse
import types
from email.Header import Header
from email.MIMEText import MIMEText
from email.MIMEMultipart import MIMEMultipart
from email.MIMEImage import MIMEImage


class MailUtils:
    '''
    arguments:
        {-d destaddress |--destaddress=destaddress}
        [{-s subject |--subject=subject}]
        [{-c content |--content=content}]

    options:
        -d destaddress, --destaddress=destaddress        : address that e-mails sends to
        -s subject, --subject=subject                    : subject of the mail
        -c content, --content=content                    : content of the mail

    examples:
        python commonutil/mail_util.py -d zijun.jiangzj@aliyun-inc.com -s "this is a mail subject" -c "this is a mail content"
    '''

    def __init__(self, options_list=[]):
        self.initArgments()
        self.parseArgments(options_list)

    def initArgments(self):
        self.src_address = ""
        self.dest_address = ""
        self.subject = ""
        self.content = ""
        self.msg = MIMEMultipart('related')
        self.msgTemp = MIMEMultipart('alternative')
        self.index = 1

    def parseArgments(self, options_list):
        if len(options_list) < 2:
            self.printUsage()
        self.parser = optparse.OptionParser(usage=self.__doc__)
        self.parser.add_option('-d', '--destaddress', dest='destaddress')
        self.parser.add_option('-s', '--subject', dest='subject', default='')
        self.parser.add_option('-c', '--content', dest='content', default='')
        self.parser.add_option('-i', '--images',  dest='images', default='') #seperated by , when more than one images
        (options, args) = self.parser.parse_args(options_list)
        if options.destaddress == None or len(options.destaddress) < 1:
            print "e-mail address must be specified! exit now"
            self.printUsage()
        self.options = options
        self.validateArgs()

    def validateArgs(self):
        checkList = []
        if type(self.options.destaddress) is types.StringType:
            checkList.append(self.options.destaddress)
            self.options.destaddress = [self.options.destaddress]
        elif type(self.options.destaddress) is types.ListType:
            checkList = self.options.destaddress
        else:
            print "mail dest address only support string or list type"
            self.printUsage
        for addr in checkList:
            expression="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"
            if None == re.search(expression, addr):
                print "you've specified a wrong e-mail address! exit now"
                self.printUsage()
        self.dest_address = self.options.destaddress
        self.subject = self.options.subject
        self.content = self.options.content
        self.images = self.options.images
         
    def printUsage(self):
        print self.__doc__
        sys.exit(1)
    
    def addfile(self, file):
        msgTemp = MIMEMultipart('alternative')
        att = MIMEText(open(file, 'rb').read(), 'base64','utf-8')
        att["Content-Type"] = 'application/octet-stream'
        att["Content-Disposition"] = 'attachment; filename=' + file
        msgTemp.attach(att)
        self.msg.attach(msgTemp)
    
    def insertImage(self, file, image_name=""):
        fp = open(file, 'rb')
        msgImage = MIMEImage(fp.read())
        fp.close()
        if image_name == "":
            str='<image%d>' % self.index
        else:
            str='%s' % image_name
        msgImage.add_header('Content-ID', str)
        self.msg.attach(msgImage)
        self.index = self.index + 1
        #msgAlternative = MIMEMultipart('alternative')
        #msgTemp = MIMEMultipart('alternative')
        #msgText = MIMEText('<b>Some <i>HTML</i> text</b> and an image.<br><img src="cid:image1"><br>Nifty!', 'html','utf-8')
        #msgTemp.attach(msgText)
        #self.msg.attach(msgTemp)
 
    def addContent(self, content, format='plain'):
        msgTemp = MIMEMultipart('alternative')
        self.msgText = MIMEText(content, format, 'utf-8')
        msgTemp.attach(self.msgText)
        self.msg.attach(msgTemp)

    def sendMail(self):    
        self.msg['subject'] = Header(self.subject,'utf-8')
        if not self.src_address:
            self.src_address = self.dest_address[0]
        self.msg['from'] = self.src_address
        self.msg['to'] = ','.join(self.dest_address)
        server = smtplib.SMTP("smtp.ops.aliyun-inc.com")
        self.addContent(self.content, 'html')
        if self.images:
            image_list = self.images.split(',') 
            image_str = ""
            for image in image_list:
                image_str += " -i " + image
                self.insertImage(image)
        print self.msg['to']
        server.sendmail(self.msg['from'], self.dest_address, self.msg.as_string())
        server.close


if __name__== '__main__' :    
    instance = MailUtils(sys.argv)
    instance.sendMail()


