import time

class TimeUtility:
    #description Return the time as a floating point number expressed in seconds since the epoch, in UTC
    @classmethod
    def currentTime(self):
        return time.time()

    @classmethod
    def convertCurrentTime2DirString(self):
        return time.strftime('%Y%m%d_%H%M%S', time.localtime(time.time()))

    @classmethod
    def convertCurrentTime2String(self):
        return time.strftime('%Y/%m/%d %H:%M:%S', time.localtime(time.time()))

    @classmethod
    def convertTime2String(self, timeSec):
        return time.strftime('%Y/%m/%d %H:%M:%S', time.localtime(timeSec))

    @classmethod
    def convertTimeInterval2String(self, timeInterval):  # timeInterval seconds
        hours = timeInterval / (60*60)
        minutes = (timeInterval/60) % 60
        seconds = timeInterval % 60
        return hours, minutes, seconds

    @classmethod
    def convertStr2Time(self, timeStr, timeFormat):
        #returns a floating point number
        return time.mktime(time.strptime(timeStr, timeFormat))

        
