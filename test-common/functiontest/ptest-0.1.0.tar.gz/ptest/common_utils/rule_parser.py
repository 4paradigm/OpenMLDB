# -*- coding:utf-8 -*-
import json

class RuleParser(object):
    def __init__(self, rule):
        if isinstance(rule, basestring):
            self.rule = json.loads(rule)
        else:
            self.rule = rule
        self.validate(self.rule)

    class Functions(object):

        ALIAS = {
            '=': 'eq',
            '!=': 'neq',
            '>': 'gt',
            '>=': 'gte',
            '<': 'lt',
            '<=': 'lte',
            'and': 'and_',
            'in': 'in_',
            'or': 'or_',
            'not': 'not_',
            'str': 'str_',
            'int': 'int_',
            'float': 'float_',
            '+': 'plus',
            '-': 'minus',
            '*': 'multiply',
            '/': 'divide'
        }

        def eq(self, *args):
            return args[0] == args[1]

        def neq(self, *args):
            return args[0] != args[1]

        def in_(self, *args):
            return args[0] in args[1:]

        def gt(self, *args):
            return args[0] > args[1]

        def gte(self, *args):
            return args[0] >= args[1]

        def lt(self, *args):
            return args[0] < args[1]

        def lte(self, *args):
            return args[0] <= args[1]

        def not_(self, *args):
            return not args[0]

        def or_(self, *args):
            return any(args)

        def and_(self, *args):
            return all(args)

        def int_(self, *args):
            return all([isinstance(f, int) for f in args])

        def float_(self, *args):
            return all([isinstance(f, float) for f in args])

        def str_(self, *args):
            return isinstance(args[0], str)

        def upper(self, *args):
            return args[0].upper()

        def lower(self, *args):
            return args[0].lower()

        def plus(self, *args):
            return sum(args)

        def minus(self, *args):
            return args[0] - args[1]

        def multiply(self, *args):
            return args[0] * args[1]

        def divide(self, *args):
            return float(args[0]) / float(args[1])

        def abs(self, *args):
            return abs(args[0])

    @staticmethod
    def validate(rule):
        print '========='
        print rule
        if not isinstance(rule, list):
            raise Exception('Rule must be a list, got {}'.format(type(rule)))
        if 0 < len(rule) < 2:
            raise Exception('Must have at least one argument.')

    def _evaluate(self, rule, fns):
        """

        :param rule:
        :param fns:
        :return:
        """
        def _recurse_eval(arg):
            if isinstance(arg, list):
                return self._evaluate(arg, fns)
            else:
                return arg

        if len(rule) == 0:
            return True
        r = list(map(_recurse_eval, rule))
        r[0] = self.Functions.ALIAS.get(r[0]) or r[0]
        func = getattr(fns, r[0])
        return func(*r[1:])

    def evaluate(self):
        fns = self.Functions()
        ret = self._evaluate(self.rule, fns)
        if not isinstance(ret, bool):
            raise Exception('In common usage, a rule must return a bool value,'
                            'but get {}, please check the rule to ensure it is true')
        return ret

if __name__ == '__main__':
    rule = ["int", 3, 5]
    t = RuleParser(rule)
    print t.evaluate()
