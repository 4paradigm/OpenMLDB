import os
import re
import sys
import traceback
import shutil
import tempfile
import process

'''
read
write
substitute
'''

HDFS_PREFIX = 'hdfs://'
HADOOP_HOME = '/usr/local/hadoop'

class FileUtils:
    @classmethod
    def cp(self, sourcefile, destfile):
        proc = process.Process()
        hadoopBin = os.path.join(HADOOP_HOME, 'bin/hadoop')
        if not sourcefile.startswith(HDFS_PREFIX) and destfile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -copyFromLocal %(sourcefile)s %(destfile)s' % locals()
        elif sourcefile.startswith(HDFS_PREFIX) and destfile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -cp %(sourcefile)s %(destfile)s' % locals()
        elif sourcefile.startswith(HDFS_PREFIX) and not destfile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -copyToLocal %(sourcefile)s %(destfile)s' % locals()
        else:
            cmd = 'cp -rf %(sourcefile)s %(destfile)s' % locals()
        proc.run(cmd)

    @classmethod
    def rm(self, sourcefile):
        proc = process.Process()
        hadoopBin = os.path.join(HADOOP_HOME, 'bin/hadoop')
        if sourcefile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -rm -r -f %(sourcefile)s' % locals()
        else:
            cmd = 'rm -rf %(sourcefile)s' % locals()
        proc.run(cmd)

    @classmethod
    def exists(self, sourcefile):
        proc = process.Process()
        hadoopBin = os.path.join(HADOOP_HOME, 'bin/hadoop')
        if sourcefile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -ls  %(sourcefile)s' % locals()
        else:
            cmd = 'ls %(sourcefile)s' % locals()
        _, _, ret = proc.run(cmd)
        if 0 == ret:
            return True
        else:
            return False


    @classmethod
    def mkdir(self, sourcefile):
        proc = process.Process()
        hadoopBin = os.path.join(HADOOP_HOME, 'bin/hadoop')
        if sourcefile.startswith(HDFS_PREFIX):
            cmd = '%(hadoopBin)s fs -mkdir -p %(sourcefile)s' % locals()
        else:
            cmd = 'mkdir -p %(sourcefile)s' % locals()
        proc.run(cmd)

    @classmethod
    def read(self, file_name):
        strs = ""
        list = self.__doRead(file_name)
        for str in list:
            strs = strs + str
        return strs

    @classmethod
    def read2(self, file_name):
        list = self.__doRead(file_name)
        return list

    @classmethod
    def write(self, strs, file_name, mode='a'):
        #note that users must specify "\n" in strs for a new line 
        #                     since it is 'append' mode
        rst = False
        try:
            f = open(file_name, mode)
            f.write(strs)
            rst = True
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror)
        except ValueError:
            print "Could not convert data to an integer."
        except:
            print "Unexpected error: in FileUtils::write", sys.exc_info()[0]
            print traceback.print_exc()
        finally:
            try:
                f.close()
            except:
                print traceback.print_exc()
        return rst
    
    @classmethod
    def replace(self, file, src, dest):
        dest = str(dest)
        try:
            old_file = open(file)
            fh, abs_path = tempfile.mkstemp()
            new_file = open(abs_path,'w')
            for line in old_file:
                new_line = line.replace(src, dest)
                new_file.write(new_line)
            new_file.close()
            os.close(fh)
            old_file.close()
            os.remove(file)
            shutil.move(abs_path, file) 
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror) 
        except:
            print "Unexpected error: in FileUtils::substitute()", sys.exc_info()[0]
            print traceback.print_exc()
        finally:
            pass

    @classmethod
    def substitute(self, file, pattern, subst):
        subst = str(subst)
        try:
            old_file = open(file)
            fh, abs_path = tempfile.mkstemp()
            new_file = open(abs_path,'w')
            for line in old_file:
                p = re.compile(pattern)
                new_line = p.sub(subst, line)
                new_file.write(new_line)
            new_file.close()
            os.close(fh)
            old_file.close()
            os.remove(file)
            shutil.move(abs_path, file) 
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror) 
        except:
            print "Unexpected error: in FileUtils::substitute()", sys.exc_info()[0]
            print traceback.print_exc()
        finally:
            pass

    @classmethod
    def listFileName(self, path, pattern):
        fileNames = []
        path = self.normalizePath(path)
        
        #--- Layered_conf_dev ---
        if type(pattern).__name__ == 'str':
                cmd = "find %s -name \"%s\"" % (path, pattern)
        elif type(pattern).__name__ == 'list':
                cmd = "find %s -name \"%s\"" % (path, pattern[0])
                for iter in pattern[1:]:
                        cmd += " -or -name \"%s\"" % iter
        else:
                print "Cannot handle the pattern"
                return fileNames

        proc = process.Process()
        strs = proc.expressRun(cmd)
        fileNames = strs.splitlines()
        return fileNames

    @classmethod
    def normalizePath(self, path):
        newPath = path
        if newPath[-1] != '/':
            newPath += '/'
        return newPath

    '''
    @classmethod
    def grepLineNum(self, str, file_name):
        line_num = 0
        try:
            f = open(file_name, 'r')
            list = f.readlines()
            for line in list:
                line_num += 1
                if line.find(str) >= 0:                    
                    break                                
        except IOError, (errno, strerror):
            print "I/O error(%s): %s" % (errno, strerror)
        except ValueError:
            print "Could not convert data to an integer."
        except:
            print "Unexpected error: in FileUtils::grepLineNum()", sys.exc_info()[0]
            print traceback.print_exc()
        finally:
            try:
                f.close()
            except:
                print traceback.print_exc()
        return line_num
    '''

    @classmethod
    def __doRead(self, file_name):
        list = []
        try:
            f = open(file_name, 'r')
            list = f.readlines()
        except IOError, (errno, strerror):
            print file_name
            print "I/O error(%s): %s" % (errno, strerror)
        except ValueError:
            print "Could not convert data to an integer."
        except:
            print "Unexpected error: in FileUtils::__doRead()", sys.exc_info()[0]
            print traceback.print_exc()
        finally:
            try:
                f.close()
            except:
                print traceback.print_exc()
        return list

if __name__ == '__main__':
        runner =  FileUtils()
        #test listFileName with str pattern
        rlstFileList = runner.listFileName('.','*.py')
        print "Find with str pattern:", rlstFileList
        #test listFileName with list pattern
        rlstFileList = runner.listFileName('.', ['*util*', '*io'])
        print "Find with list pattern", rlstFileList
        #test listFileName with unknown pattern type
        rlstFileList = runner.listFileName('.', int(10))
        print "Find with unknown pattern type", rlstFileList

