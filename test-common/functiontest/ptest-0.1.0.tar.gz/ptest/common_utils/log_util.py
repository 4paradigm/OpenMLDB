import atest.log as log

#TODO:zhangf-mod-20170401
#log.warn("Deprecated: Use of 'common_utils.log_util' is deprecated. ")
#log.warn("Please use 'atest.log' instead.")

LOGGER = log.root 

