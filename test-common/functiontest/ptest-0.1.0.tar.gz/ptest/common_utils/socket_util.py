import os
import socket

class SocketUtil:
    @classmethod
    def getHostName(self):
        return socket.gethostname()
    
    @classmethod
    def getLocalIPAddress(self):
        ip = os.popen("/sbin/ifconfig | grep 'inet addr' | awk '{print $2}'").read()
        return ip[ip.find(':')+1:ip.find('\n')]
    

if __name__ == "__main__":
    socketUtil = SocketUtil()
    print "getHostName=", socketUtil.getHostName()
    print "getLocalIPAddress=", socketUtil.getLocalIPAddress()

