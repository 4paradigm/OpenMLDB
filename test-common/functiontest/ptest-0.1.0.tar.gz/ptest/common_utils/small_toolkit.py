#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Module for collecting small and useful function which are not easily to be categoried"""
import os
import re
import sys
import time
import inspect
import traceback
import subprocess
from datetime import datetime
import atest.log as log

def logException(e):
    log.warn("Exception happens:%s\n%s" % 
             (str(e), traceback.format_exc()))

def except_trapper(func):
    def do_func(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception,e:
            logException(e)
            return None
    return do_func

def log_clsfunc_begin_end(func):
    def do_func(*args, **kwargs):
        caller = inspect.stack()[1][0].f_locals['self']
        class_name = caller.__class__.__name__
        file_name = os.path.basename(sys._getframe(1).f_code.co_filename)
        module_name = os.path.splitext(file_name)[0]
        try:
            log.debug("BEGIN %s::%s::%s"%(module_name, class_name, func.__name__))
            ret = func(*args, **kwargs)
        finally:
            log.debug("END %s::%s::%s"%(module_name, class_name, func.__name__))
        return ret
    return do_func


def uniqueList(myList, needStrip=True):
    ret = []
    for x in myList:
        if needStrip:
            x = x.strip()
        if x and x not in ret:
            ret.append(x)
    return ret
    
def isPythonFile(file):
    return file.endswith('.py')

def getCurrentTime(ymdsep='-', msep=' ', hmssep='.'):
    fmt = ymdsep.join(['%Y', '%m', '%d']) + msep + hmssep.join(['%H', '%M', '%S'])
    return time.strftime(fmt, time.localtime(time.time()))

def str2bool(str):
    return str.lower() == "true"

def cpu_count():
    """Returns the number of processors on this machine."""
    try:
        return os.sysconf("SC_NPROCESSORS_CONF")
    except ValueError:
        pass
    #could not detect number of processors; assuming 1
    return 1

def removeEndSlash(str):
    ret = str[:-1] if str.endswith('/') else str
    return ret

def isValidUserPort(port):
    if (1025 <= int(port) <= 65534):
        return True
    else:
        return False

def execute_cmd(cmd):
    child = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).stdout
    return child.readlines()

def fequal(a, b):
    if abs(a-b)<0.00000001:
        return True
    else:
        return False

def str2float(str):
    str = str.strip()
    floatNum = 0.0
    try:
        floatNum = float(str)
    except Exception, e:
        log.error("change str[%s] to float failed!" % str)
    return floatNum

@except_trapper
def time2str(myDateTime):
    return myDateTime.strftime("%Y-%m-%d %H:%M:%S")

@except_trapper
def str2time(timeStr):
    return datetime.strptime(timeStr, "%Y-%m-%d %H:%M:%S")
    
def removePrefix(str, prefix='/'):
    """
    eg: str='//temp/workbench', return will be 'temp/workbench'
    """
    assert(str)
    items = re.findall('[^/]', str)
    if items:
        id = str.index(items[0])
        return str[id:]
    else:
        return ''
      
