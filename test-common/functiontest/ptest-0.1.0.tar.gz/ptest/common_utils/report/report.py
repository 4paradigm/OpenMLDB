# -*- coding: utf8 -*-
#! /usr/bin/python

import os
import smtplib
import time

from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import email.utils


class TestReport:
    pass

class HTMLTestReport(TestReport):

    def __init__(self, obj):
        self.title = obj['status'].upper() + " ["
        self.title += obj['plan_name'] + "] " 
        self.title += "PTest Report"

        self.sender = obj["executor"]
        self.receivers = obj['people']

        if self.sender not in self.receivers:
            self.receivers.append(self.sender)


        self.html = self._gen_html_content(obj)

    def _read_temp(self, name):
        baseDir = os.path.dirname(os.path.abspath(__file__))
        temp = os.path.join(baseDir, 'template', '%(name)s.temp.html')
        temp = temp % locals()

        return open(temp).read()

    def _gen_mail_list(self, obj):
        ret = ""
        temp = self._read_temp('mail_list')
        for email in obj['people']:
            ret += temp % {'email' : email}
        return ret

    def _gen_statistics(self, obj):
        statics = obj['statics']
        return ((
            "Passed=%d&nbsp;&nbsp;"
            "Failed=%d&nbsp;&nbsp;"
            "Aborted=%d&nbsp;&nbsp;"
            "Canceled=%d&nbsp;&nbsp;"
        ) % (statics['passed'], statics['failed'], statics['aborted'], statics['canceled']))

    def _gen_test_params(self, obj):
        ret = ""
        temp = self._read_temp('test_param')
        for k, v in obj['param'].iteritems():
            ret += temp % {'key' : k, 'value' : v}
        return ret

    def _gen_test_results(self, obj):
        ret = ""
        passed_temp = self._read_temp('case_passed')
        failed_temp = self._read_temp('case_failed')
        aborted_temp = self._read_temp('case_aborted')
        canceled_temp = self._read_temp('case_canceled')

        for name, data in obj['results'].iteritems():
            status = data['status']
            if status == 'passed':
                ret += passed_temp % {'case_addr' : name, 'duration' : data['duration']}
            elif status == 'canceled':
                ret += canceled_temp % {'case_addr' : name}
            elif status == 'failed':
                ret += failed_temp % {'case_addr' : name, 'reason' : data['note'], 'duration' : data['duration']}
            elif status == 'aborted':
                ret += aborted_temp % {'case_addr' : name, 'reason' : data['note'], 'duration' : data['duration']}
                
            if 'note' in data:
                for note_line in data['note']:
                    case_note_temp = self._read_temp('case_note')
                    ret += case_note_temp % {'case_note' : note_line}

        return ret

    def _gen_note_content(self, obj):
        if not obj['note']:
            return ""

        note_temp = self._read_temp('note')
        
        content = ""
        for note in obj['note']:
            for split in note.split('\n'):
                content += split + "<br>"

        return note_temp % {'note_content' : content}

    def _gen_html_content(self, obj):
        
        def time2str(timestamp):
            return time.strftime(
                "%Y-%m-%d %H:%M:%S", time.localtime(timestamp)
            )

        report_dict = {
            'test_plan' : obj['plan_name'],
            'mail_list' : self._gen_mail_list(obj),
            'hostname' : obj['hostname'],
            'hostip' : obj['hostip'],
            'local_path' : obj['local_path'],
            'statistics' : self._gen_statistics(obj),
            'start_time' : time2str(obj['start_time']),
            'stop_time' : time2str(obj['stop_time']),
            'duration' : "%.3f" % (obj['stop_time'] - obj['start_time']),
            'test_params' : self._gen_test_params(obj),
            'test_results' : self._gen_test_results(obj),
            'note' : self._gen_note_content(obj),
        }

        return self._read_temp('test_report') % report_dict

    def send_by_email(self):
        msg = MIMEMultipart('alternative')
        msg['Subject'] = Header(self.title)
        msg['From'] = 'noreply@4paradigm.com'
        msg['To'] = ", ".join(self.receivers)
        msg['Date'] = email.utils.formatdate()
        msg.attach(MIMEText(self.html, 'html', 'utf-8'))
        server = smtplib.SMTP('mail.4paradigm.com', 465)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login('noreply@4paradigm.com', 'paradigm4postfix')
        server.sendmail('noreply@4paradigm.com', self.receivers, msg.as_string())
        server.quit()

    def save_on_file(self, report_file):
        report_file.write(self.html)


if __name__ == '__main__':
    obj = {
        'status': 'passed',
        'plan_name': 'Pico functiontest',
        'executor': 'zhangfei@4paradigm.com',
        'people': ['zhangfei@4paradigm.com'],
        'hostname': 'model-hdp01',
        'hostip': '172.27.2.101',
        'local_path': '/Users/zhangfei/work/project/pico/FT/pico/functiontest/tmp',
        'statics': {
            "passed": 0,
            "failed": 1,
            "aborted": 2,
            "canceled": 3,
        },
        'start_time': time.time(),
        'stop_time': time.time(),
        'param': {
            'testKey': 'testValue',
        },
        'results':
            {
                '/home/case/case1':{
                    'reason': 'reason0',
                    'duration': 1.24,
                    'note': ['note0'],
                    'status': 'passed',
                },
            },
        'note': ['note0', 'note1'],
    }
    report = HTMLTestReport(obj)
    report.send_by_email()


