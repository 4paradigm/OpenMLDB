#!/usr/bin/env python
import ConfigParser

class MyConfigParser(ConfigParser.SafeConfigParser):
    def optionxform(self, option):
        '''keep the key case-sensitive.
        Default behave of SafeConfigParser is lower the case.
        '''
        return option
