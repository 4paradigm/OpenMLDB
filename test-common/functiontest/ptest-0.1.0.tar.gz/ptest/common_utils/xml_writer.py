# -*- coding: utf-8 -*-
import codecs
import xml.dom.minidom


##############################################################
#class XmlWriter
##############################################################
class XmlWriter:
    def __init__(self): 
        self.impl = xml.dom.minidom.getDOMImplementation()

    def createDocument(self, root_name="configuration"):
        dom = self.impl.createDocument(None, root_name, None)
        return dom

    def createElementWrapper(self, dom, tagname, value, type='text'):
        element = self.createElement(dom, tagname)
        text = None
        if value.find(']]>') > -1:
            type = 'text'
        if type == 'text':
            value = value.replace('&', '&amp;')
            value = value.replace('<', '&lt;')
            text = self.createTextNode(dom, value)
        elif type == 'cdata':
            text = self.createCDATASection(dom, value)
        element.appendChild(text)
        return element

    def write2XmlFile(self, dom, xml_file_name):
        clone_dom = dom.cloneNode(True)
        self.indent(clone_dom, clone_dom.documentElement)
        f = file(xml_file_name, 'wb')
        writer = codecs.lookup('utf-8')[3](f)
        clone_dom.writexml(writer, encoding = 'utf-8')
        clone_dom.unlink()
        writer.close()

    def indent(self, dom, node, indent = 0):
        #Copy child list because it will change soon
        children = node.childNodes[:]
        #Main node doesn't need to be indented
        if indent:
            text = dom.createTextNode('\n' + '\t' * indent)
            node.parentNode.insertBefore(text, node)
        if children:
            #Append newline after last child, except for text nodes
            if children[-1].nodeType == node.ELEMENT_NODE:
                text = dom.createTextNode('\n' + '\t' * indent)
                node.appendChild(text)
            #Indent children which are elements
            for n in children:
                if n.nodeType == node.ELEMENT_NODE:
                    self.indent(dom, n, indent + 1)

    def getDocumentRoot(self, dom):
        return dom.documentElement

    def createElement(self, dom, tagname):
        element = dom.createElement(tagname)
        return element

    def createTextNode(self, dom, text_val):
        text_node = dom.createTextNode(text_val)
        return text_node

    def createCDATASection(self, dom, value):
        node = dom.createCDATASection(value)
        return node


if __name__ == "__main__":
    a = XmlWriter()
    dom = a.createDocument()
    root = a.getDocumentRoot(dom)

    item = a.createElement(dom, 'property')
    child = a.createElementWrapper(dom, 'name', "hdfs_data")
    item.appendChild(child)
    child = a.createElementWrapper(dom, 'value', "/home/jiangzj/hdfs/hdfs_data/")
    item.appendChild(child)
    root.appendChild(item)

    a.write2XmlFile(dom, "b.xml")
