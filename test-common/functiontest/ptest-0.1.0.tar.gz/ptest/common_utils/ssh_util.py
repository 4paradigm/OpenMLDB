import os
import os.path
import shutil
import sys
import optparse

#from common_define import *
import common_utils.process as process
import common_utils.pexpect as pexpect

class SSHProcessor:
    '''
    arguments:
        {-p password|--password=password}
        {-i iplist|--iplist=iplist}

    options:
        -p password, --password=password        : os password
        -i iplist, --iplist=iplist              : dest iplist

    examples:
        python ssh_processor.py -p 123456 -i 10.250.12.15,10.250.12.11        
    '''

    def __init__(self, options_list):
        self.user = os.getlogin()
        self.home = "/home/" + self.user + "/"
        self.proc = process.Process()
        self.parseArgments(options_list)

    def parseArgments(self, options_list):
        if len(options_list) < 2:
            self.printUsage()
        self.parser = optparse.OptionParser(usage=self.__doc__)
        self.parser.add_option('-p', '--password', dest='password')
        self.parser.add_option('-i', '--iplist', dest='iplist')
        (options, args) = self.parser.parse_args(options_list)
        if options.password == None or len(options.password) < 1:
            self.printUsage()
        if options.iplist == None or len(options.iplist) < 1:
            self.printUsage()
        self.options = options
    
    def authenticate(self):
        self.handleLocalKeys()
        self.handleRemoteKeys()

    def handleLocalKeys(self):
        cur_dir = os.getcwd()
        os.chdir(self.home)
        if not os.path.exists(".ssh"):
            os.mkdir(".ssh")
        os.chmod(".ssh", 0700)

        if not os.path.exists(".ssh/id_rsa") or \
            not os.path.exists(".ssh/id_rsa.pub"):            
            if os.path.exists("id_rsa"):
                os.remove("id_rsa")
            if os.path.exists("id_rsa.pub"):
                os.remove("id_rsa.pub")
            cmd = 'ssh-keygen -f id_rsa -t rsa -N ""'            
            self.proc.run(cmd) 
            shutil.copy("id_rsa.pub", self.home + ".ssh/id_rsa.pub")
            shutil.copy("id_rsa", self.home + ".ssh/id_rsa")
            
        group = os.getgroups()
        cmd = "chown " + self.user + ":" + str(group[0]) + " "
        os.system(cmd + self.home + ".ssh/id_rsa.pub")    
        os.system(cmd + self.home + ".ssh/id_rsa")    
        if not os.path.exists(".ssh/authorized_keys"):
            os.system("touch .ssh/authorized_keys")
        os.system('chmod -R 600 .ssh/*')
        os.chdir(cur_dir)

    def handleRemoteKeys(self):
        iplist = self.options.iplist
        ips = iplist.split(",")
        for ip in ips:
            print "handling for ip: %s", ip
            key, error, code = self.proc.run("cat " + self.home + ".ssh/id_rsa.pub")
            cmd = "mkdir -p ~/.ssh;" + \
                  "chmod 700 ~/.ssh;" + \
                  "touch ~/.ssh/authorized_keys;" + \
                  "chmod -R 600 ~/.ssh/*;" + \
                  "grep \"" + key.strip() + "\" ~/.ssh/authorized_keys > /dev/null 2>&1;" + \
                  "echo \\\$?"
            dir_exists = self.proc.remoteRunExpect(self.user, self.options.password, ip, cmd)
            if dir_exists != "0":
                print "----------------------------------"
                cmd = "mkdir -p ~/.ssh;" + \
                      "echo \"" + key.strip() + "\" >> ~/.ssh/authorized_keys"
                self.proc.remoteRunExpect(self.user, self.options.password, ip, cmd)
            print "done for ip: %s", ip

    def printUsage(self):
        print self.__doc__
        sys.exit(1)


if __name__ == "__main__":
    instance = SSHProcessor(sys.argv)
    instance.authenticate()
