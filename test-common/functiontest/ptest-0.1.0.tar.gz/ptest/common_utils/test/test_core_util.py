#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, sys, unittest, shutil
currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + "/../../")
import common_utils.check_core_util as check_core_util
import common_utils.file_util as file_util
import tempfile
import shutil
import socket
import os, os.path

class TestCheckCoreUtil(unittest.TestCase):
    def setUp(self):
        self.checkCore = check_core_util.CheckCoreUtil()
        self.localIp = socket.gethostbyname(socket.gethostname())
        self.curPath = file_util.FileUtils.normalizePath(os.path.split(os.path.realpath(__file__))[0])

        self.tmpDir = self.curPath + "/temp"
        if os.path.exists(self.tmpDir):
            shutil.rmtree(self.tmpDir)

        subDir = self.tmpDir + "/subdir"
        os.makedirs(subDir)

        coreFile1 = self.tmpDir + "/core.1"
        os.system("touch %s" % coreFile1)
        self.assertTrue(os.path.exists(coreFile1))
        coreFile2 = subDir + "/core.2"
        os.system("touch %s" % coreFile2)
        self.assertTrue(os.path.exists(coreFile2))
        
    def tearDown(self):
        if os.path.exists(self.tmpDir):
            shutil.rmtree(self.tmpDir)

    # def testCheckCoreRemoteHost(self):
    #     cores = self.checkCore.checkCoreInRemoteHost(self.localIp, self.tmpDir, 'admin', 'admin@gal', True)
    #     self.assertEquals(2, len(cores))

    #     cores = self.checkCore.checkCoreInRemoteHost(self.localIp, self.tmpDir, 'admin', 'admin@gal', False)
    #     self.assertEquals(1, len(cores))
        
    def testCheckCoreLocalHost(self):
        cores = self.checkCore.checkCoreInLocalHost(self.tmpDir, "", True)
        self.assertEquals(2, len(cores))

    def testCheckCoreLocalHost2(self):
        cores = self.checkCore.checkCoreInLocalHost(self.tmpDir, "", False)
        self.assertEquals(1, len(cores))

def suite():
    suite = unittest.makeSuite(TestCheckCoreUtil, 'test')
    return suite

if __name__ == "__main__":
    unittest.main()
