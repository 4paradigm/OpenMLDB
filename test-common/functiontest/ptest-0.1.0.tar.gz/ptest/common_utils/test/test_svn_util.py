#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, sys, unittest, shutil
currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + "/../../")
import common_utils.svn_util as svn_util
import tempfile
import shutil

class Test_SVN_UTIL(unittest.TestCase):
    def setUp(self):
        self.svn =  svn_util.SVN()
        self.tempDir = None

    def tearDown(self):
        if self.tempDir and os.path.exists(self.tempDir):
            shutil.rmtree(self.tempDir)
        
    def test_svn_info(self):
        modulePath = currentPath + "/../../examples/prj_example/"
        svnurl, version = self.svn.getRevisionInfo(modulePath)
        self.assertTrue(svnurl != 'N/A')
        self.assertTrue(version != 'N/A')

    def test_svn_checkout_001(self):
        svnUrl = "http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/abuild/trunk/"
        self.tempDir = "abuild"
        data, error, code = self.svn.checkout(svnUrl, self.tempDir, svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertTrue(code == 0, 'stdout:%s error:%s'%(data, error))
                
    def test_svn_checkout_002(self):
        svnUrl = "http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/abuild/trunk/"
        self.tempDir = "abuild"
        data, error, code = self.svn.checkout(svnUrl, self.tempDir, svn_revision="87267", 
                                              svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertTrue(code == 0, 'stdout:%s error:%s'%(data, error))

    def test_svn_up(self):
        modulePath = currentPath + "/../../examples/prj_example/"
        ret = self.svn.update(modulePath, svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertTrue(ret)

    def test_svn_up_with_not_exist_path(self):
        modulePath = currentPath + "/dir_not_exist/"
        ret = self.svn.update(modulePath, svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertFalse(ret)

    def test_svn_up_with_wrong_svn(self):
        tmpDir = tempfile.mkdtemp()
        ret = self.svn.update(tmpDir, svn_user="huitian.tang", svn_pwd="tian20090710")
        shutil.rmtree(tmpDir)
        self.assertFalse(ret)

    def test_svn_up_to_latest_version(self):
        svnUrl = "http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/abuild/trunk/"
        self.tempDir = "abuild"
        data, error, code = self.svn.checkout(svnUrl, self.tempDir, svn_revision="87267", 
                                              svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertTrue(code == 0, 'stdout:%s error:%s'%(data, error))
        
        ret = self.svn.update(self.tempDir, svn_user="huitian.tang", svn_pwd="tian20090710")
        self.assertTrue(ret)
        
        

def suite():
    suite = unittest.makeSuite(Test_SVN_UTIL, 'test')
    return suite

if __name__ == "__main__":
    unittest.main()
