#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os, sys, unittest, shutil
currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + "/../../")
import common_utils.small_toolkit as small_toolkit
import common_utils.log_util as log_util

class Test_SMALLTOOLKIT(unittest.TestCase):
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_uniqueList_emptyStr(self):
        testList = ['']
        actualList = small_toolkit.uniqueList(testList)
        self.assertEqual([], actualList)

    @small_toolkit.log_clsfunc_begin_end     
    def test_uniqueList_duplicateItem(self):
        testList = ['1', '', '1', '']
        actualList = small_toolkit.uniqueList(testList)
        log_util.LOGGER.info('actualList=%s'%actualList)
        self.assertEqual(['1', ''], actualList)
    
    @small_toolkit.log_clsfunc_begin_end
    def test_uniqueList_duplicateItemWithSpace(self):
        testList = ['  1', '', '  1 ', '2 ', '  ']
        actualList = small_toolkit.uniqueList(testList)
        self.assertEqual(['1', '2'], actualList)
    
    @small_toolkit.log_clsfunc_begin_end
    def test_log_clsfunc_begin_end(self):
        try:
            raise Exception("mock exception")
        except Exception, e:
            log_util.LOGGER.error("Exception happened:%s"%e)
            
        
def suite():
    suite = unittest.makeSuite(Test_SMALLTOOLKIT, 'test')
    return suite

if __name__ == "__main__":
    unittest.main()
