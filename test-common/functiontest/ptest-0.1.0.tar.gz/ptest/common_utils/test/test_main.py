#!/bin/env python
import os
import sys
import unittest
import test_svn_util
import test_smalltoolkit

if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    allTests = unittest.TestSuite()
    allTests.addTest(test_svn_util.suite())
    allTests.addTest(test_smalltoolkit.suite())
    runner.run(allTests)
