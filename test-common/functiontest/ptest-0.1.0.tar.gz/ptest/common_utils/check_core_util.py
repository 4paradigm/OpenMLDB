import re
import os, os.path
import atest.log as log
import process

class CheckCoreUtil:
    def __init__(self):
        self.proc = process.Process()
        
    def checkCoreInRemoteHost(self, remoteIP, checkDir, osUser, osPasswd, recursive=True):
        cmd = ''
        if recursive:
            cmd = ' '.join(['ssh', osUser + '@' + remoteIP, "'" + 'sudo find', \
                            checkDir, '-name "core.[0-9]*"', '-exec ls -lh \{\} \;' + "'"])
        else:
            cmd = ' '.join(['ssh', osUser + '@' + remoteIP, "'" + 'sudo ls -lh', 
                            os.path.join(checkDir, 'core.[0-9]*') + "'"])

        return self.__getCoreFiles(cmd, osPasswd)

    def checkCoreInLocalHost(self, checkDir, osPasswd, recursive=True):
        checkDir = os.path.realpath(checkDir)
        log.debug("checkDir real path[%s]" % checkDir)
        if recursive:
            cmd = 'sudo find %s -name "core.[0-9]*" -exec ls -lh \{\} \;' % checkDir
        else:
            cmd = 'sudo find %s -maxdepth 1 -name "core.[0-9]*" -exec ls -lh \{\} \;' % checkDir

        return self.__getCoreFiles(cmd, osPasswd)

    def __getCoreFiles(self, cmd, osPasswd):
        log.debug("cmd: %s" % cmd)
        rets = self.proc.executePexpectLoop(cmd, osPasswd).strip()

        cores = []
        for core in rets.split("\n"):
            core = core.strip()
            if core and re.search('core.[0-9]+', core):
                cores.append(core)
        return cores
        



