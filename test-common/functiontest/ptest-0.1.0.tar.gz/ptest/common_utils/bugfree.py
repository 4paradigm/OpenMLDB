#!/usr/bin/env python
import os
import sys
import md5
import urllib
import urllib2

class Bugfree:
    def __init__(self, url="http://bugfree.corp.alimama.com", debug=1):
        self.url = url
        self.debug = debug
        self.sessionName = ""
        self.sessionRand = ""
        self.sessionID = ""
        pass
    
    def removeInvalidChar(self, strOld):
        strNew = strOld.replace(' ','%20').replace('/','%2F').replace('+','%20').replace('\t','%20%20%20%20')
        return strNew

    def startSession(self):
        print "starting a new session with bugfree server"
        result = self.httpPost(self.url + "/api.php?mode=getsid")
        array = result.split(chr(03))
        if array[0] == "success":
            self.sessionName = array[2].split(chr(04))[0]
            self.sessionID = array[2].split(chr(04))[1]
            self.sessionRand = array[2].split(chr(04))[2]
            return "success"
        else:
            print "error when starting session"
            exit()        

    def login(self, username, password):
        print "starting to login..."
        m = md5.new()
        auth = md5.new(md5.new(username + md5.new(password).hexdigest()).hexdigest() + self.sessionRand).hexdigest()
        requestUrl = self.url + "/api.php?mode=login&username=" + username \
                   + "&auth=" + auth \
                   + '&' + self.sessionName \
                   + '=' + self.sessionID
        if self.debug == 1:
            print requestUrl
        result = self.httpPost(requestUrl)
        if self.debug == 1:
            print result
        if result.find("success") != -1:
            return "success"

    def getBug(self, bugID):
        print "trying to get bug id: " + bugID
        requestUrl = self.url + "/api.php?mode=getbug&BugID=" + str(bugID) \
                   + "&" + self.sessionName \
                   + '=' + self.sessionID
        if self.debug == 1:
            print requestUrl
        result = self.httpPost(requestUrl)
        if self.debug == 1:
            print result 
        if result.find("success") != -1:
            return "success"
        pass

    def createBug(self, bugInfo):
        print "adding a bug"
        requestUrl = self.url + "/api.php?mode=addbug&ProjectID=" + bugInfo.getProjectID() \
                   + "&ModuleID=" + bugInfo.getModuleID() \
                   + "&BugTitle=" + (bugInfo.getBugTitle()).replace(" ","%20") \
                   + "&ReproSteps=" + (bugInfo.getReproSteps()).replace(" ","%20") \
                   + "&AssignedTo=" + (bugInfo.getAssignedTo()).replace(" ","%20") \
                   + "&BugSeverity=" + bugInfo.getBugSeverity() \
                   + "&BugType=" + self.removeInvalidChar((bugInfo.getBugType()).replace(" ","%20")) \
                   + "&HowFound=" + self.removeInvalidChar((bugInfo.getHowFound()).replace(" ","%20")) \
                   + "&OpenedBuild=" + self.removeInvalidChar((bugInfo.getOpenedBuild()).replace(" ","%20")) \
                   + "&ReplyNote=" + self.removeInvalidChar((bugInfo.getReplyNote()).replace(" ","%20")) \
                   + "&" + self.sessionName \
                   + "=" + self.sessionID
        if self.debug == 1:
            print requestUrl
        result = self.httpPost(requestUrl)
        if self.debug == 1:
            print result
        if result.find("success") != -1:
            array = result.split(chr(03))    
            bugid = array[2]
            return bugid
        else:
            return -1

    def updateBug(self, bugInfo):
        print "updating bug"        
        bugID = bugInfo.getBugID()
        if bugID == "":
            print "bugID error! "
            return
        requestUrl = self.url + "/api.php?mode=updatebug"
        requestUrl = requestUrl + "&BugID=" + bugID

        print bugInfo
        projectID  = bugInfo.getProjectID()
        moduleID =  bugInfo.getModuleID()
        bugTitle = bugInfo.getBugTitle()
        reproSteps = bugInfo.getReproSteps()
        assignedTo = bugInfo.getAssignedTo()
        bugSeverity = bugInfo.getBugSeverity()
        bugType =  bugInfo.getBugType()
        howFound = bugInfo.getHowFound()
        openedBuild = bugInfo.getOpenedBuild()
        replyNote =  bugInfo.getReplyNote()        

        if projectID != "":
            requestUrl = requestUrl+"&ProjectID=" + projectID
        if moduleID != "": 
            requestUrl = requestUrl+"&ModuleID=" + moduleID
        if bugTitle != "":
            requestUrl = requestUrl + "&BugTitile=" + bugTitle.replace(" ","%20")
        if reproSteps != "":
            requestUrl = requestUrl + "&ReproSteps=" + reproSteps.replace(" ","%20")
        if assignedTo != "":
            requestUrl = requestUrl + "&AssignedTo=" + assignedTo.replace(" ","%20")
        if bugSeverity != "":
            requestUrl = requestUrl + "&BugSeverity=" + bugSeverity.replace(" ","%20")
        if bugType != "":
            requestUrl = requestUrl + "&BugType=" + bugType.replace(" ","%20")
        if howFound != "":
            requestUrl = requestUrl + "&HowFound=" + howFound.replace(" ","%20")
        if openedBuild != "":
            requestUrl = requestUrl + "&OpenedBuild=" + openedBuild.replace(" ","%20")
        if replyNote != "":
            requestUrl = requestUrl + "&ReplyNote=" + self.removeInvalidChar(replyNote.replace(" ","%20"))

        requestUrl = requestUrl + "&" + self.sessionName + "=" + self.sessionID
        if self.debug == 1:
            print requestUrl
        result = self.httpPost(requestUrl)
        if self.debug == 1:
            print result
        if result.find("success") != -1:
            return "success"

    def deleteBug():
        pass

    def httpPost(self, url):
        opener = urllib2.build_opener()
        urllib2.install_opener(opener)
        req = urllib2.Request(url)
        u = urllib2.urlopen(req)
        result = u.read()
        if self.debug == 1:
            print result
        return result

class BugInfo:
    bugID = ""
    projectID = ""
    moduleID = ""
    bugTitle = ""
    reproSteps = ""
    assignedTo = ""
    bugSeverity = ""
    bugType = ""
    howFound = ""
    openedBuild = ""
    replyNote = ""

    def __init(self):
        pass

    def getBugID(self):
        return self.bugID

    def setBugID(self, bugID=""):
        self.bugID = bugID

    def getProjectID(self):
        return self.projectID

    def setProjectID(self, projectID=""):
        self.projectID = projectID

    def getModuleID(self):
        return self.moduleID
    
    def setModuleID(self, moduleID=""):
        self.moduleID = moduleID

    def getBugTitle(self):
        return self.bugTitle

    def setBugTitle(self, bugTitle=""):
        self.bugTitle = bugTitle

    def getReproSteps(self):
        return self.reproSteps

    def setReproSteps(self, reproSteps=""):
        self.reproSteps = reproSteps

    def getAssignedTo(self):
        return self.assignedTo

    def setAssignedTo(self, assignedTo=""):
        self.assignedTo = assignedTo

    def getBugSeverity(self):
        return self.bugSeverity

    def setBugSeverity(self, bugSeverity=""):
        self.bugSeverity = bugSeverity

    def getBugType(self):
        return self.bugType

    def setBugType(self, bugType=""):
        self.bugType = bugType

    def getHowFound(self):
        return self.howFound

    def setHowFound(self, howFound=""):
        self.howFound = howFound

    def getOpenedBuild(self):
        return self.openedBuild

    def setOpenedBuild(self, openedBuild=""):
        self.openedBuild = openedBuild

    def getReplyNote(self):
        return self.replyNote

    def setReplyNote(self, replyNote=""):
        self.replyNote = replyNote

