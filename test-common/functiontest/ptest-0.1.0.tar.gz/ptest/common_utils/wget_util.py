import os
import sys
import types
import common_utils.process as process
import common_utils.pexpect as pexpect

class Wget:
    def __init__(self):
        self.proc = process.Process()
        
    def download(self, urls, dest_dir):
        if not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        os.chdir(dest_dir)
        if type(urls) == types.ListType:
            pass
        else:
            urls = [urls]
        for url in urls:
            cmd = "wget %s"%url
            data, error, code = self.proc.run(cmd)
            if code != 0:
                print "download failed. stdout=%s error=%s"%(data, error)
                return False
            else:
                return True

