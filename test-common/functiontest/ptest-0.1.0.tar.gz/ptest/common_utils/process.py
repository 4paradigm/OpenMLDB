# process.py
"""        Wrapper for process control in python
@version:  $Id$
@author:   U{Jackie Jiang<mailto:zijun.jiangzj@aliyun-inc.com>}
@see:      http://grd.alibaba-inc.com/projects/heavenasks/wiki/HA3_Auto_Testing
"""

import time
import signal
import re
import os
import sys
import shlex
import subprocess
import pexpect
import traceback

import atest.log as log

#log.warn("Deprecated: Use of 'common_utils.process' is deprecated.")
#log.warn("Please use 'atest.auto' instead.")

class Process:
    GlobalTimout = 0
    intervalSecond = 1
    
    def run(self, cmd, timeout = GlobalTimout):
        ''' Usage:             fork a subprocess and run (foreground)
            Keyword arguments: cmd
            Returns:           data, error, code
        '''
        log.trace(cmd)
        env_table = os.environ
        if "LD_LIBRARY_PATH" in os.environ:
            env_table["LD_LIBRARY_PATH"] = os.environ["LD_LIBRARY_PATH"]
        p = subprocess.Popen(cmd, shell=True, close_fds=True, stdout=subprocess.PIPE,  \
                                  stderr=subprocess.PIPE, env=env_table)            
        if timeout <= 0:
            #set to be waiting endless
            timeout = -1
        while timeout > 0:
            if not p.poll() == None:
                break
            time.sleep(self.intervalSecond)
            timeout = timeout - self.intervalSecond
        if p.poll() == None and timeout >= 0:
            self.__killAll(p.pid)
            print 'Timeout: %s seconds, kill the process [%s]' % (timeout, cmd)
        stdout,stderr = p.communicate()
        return (stdout, stderr, p.returncode)

    def runXP(self, cmd, timeout = GlobalTimout):
        ''' Usage:             fork a subprocess and run (foreground)
            Keyword arguments: cmd
            Returns:           data, error, code
        '''
        import commands
        status, output = commands.getstatusoutput(cmd)
        return (output, '', status)

    def consoleRun(self, cmd, timeout = GlobalTimout):
        ''' Usage:             fork a subprocess and run (foreground)
            Keyword arguments: cmd
            Returns:           code
        '''
        args = shlex.split(cmd)
        p = subprocess.Popen(args)
        if timeout <= 0:
            #set to be waiting endless
            timeout = -1
        while timeout > 0:
            if not p.poll() == None:
                break
            time.sleep(intervalSecond)
            timeout = timeout - 1
        if p.poll() == None and timeout >= 0:
            self.__killAll(p.pid)
        p.communicate()
        return p.returncode

    def expressRun(self, cmd):
        ''' Usage:             fork a subprocess and run (foreground or backgournd)
            Keyword arguments: cmd
            Returns:           str
        '''
        str = os.popen(cmd).read()    
        return str.strip()

    def runWrapper(self, cmd, timeout = GlobalTimout):
        ''' Usage:             fork a subprocess and run (foreground)
                               also print the returns
            Keyword arguments: cmd
            Returns:           data, error, code
        '''
        data, error, code = self.run(cmd, timeout)
        print data
        print error
        print code
        return data, error, code

    def runSudo(self, cmd, password, logname=None, timeout=-1):
        cmd = "sudo %s" % cmd
        log.trace("cmd[%s]" % cmd)
        try:
            child = pexpect.spawn(cmd)
            if logname:
                log.trace("logname[%s]" % logname)
                fout = open(logname, 'w')
                child.logfile_read = fout
            else:
                child.logfile_read = child.stdout

            index = child.expect(['[Pp]assword:', pexpect.EOF, pexpect.TIMEOUT], timeout)
            if index==0:
                log.trace("need password")
                child.sendline(password)
                child.expect([pexpect.EOF, pexpect.TIMEOUT], timeout)
            elif index==1:
                log.trace("do not need password")
            elif index==2:
                log.trace("timeout...")
            if logname:
                child.logfile_read.close()
        except Exception, e:
            log.error("exception [%s] " % traceback.format_exc())
        finally:
            try:
                child.close()
            except:
                pass

    def remoteRun(self, user, host, cmd, timeout="600"):
        ''' Usage:             ssh                               
            Keyword arguments: user, host, cmd
            Returns:           data, error, code
        '''
        cmd = ['ssh', user + '@' + host, '-o ConnectTimeout=' + timeout, cmd]
        print ' '.join(cmd)
        p = subprocess.Popen(cmd, stdout = subprocess.PIPE,\
                            stderr = subprocess.PIPE, shell = False, close_fds = True)
        stdout,stderr = p.communicate()
        return (stdout, stderr, p.returncode)

    def remoteRunNoWait(self, user, host, cmd, timeout="600", output=None):
        ''' Usage:             ssh                               
            Keyword arguments: user, host, cmd
            Returns:           data, error, code
        '''
        if output is None:
            out = subprocess.PIPE
        else:
            out = open(output, 'w')
        cmd = ['ssh', user + '@' + host, '-o ConnectTimeout=' + timeout, cmd]
        p = subprocess.Popen(cmd, stdout=out, stderr=subprocess.PIPE, 
                             shell=False, close_fds=True)
        print ' '.join(cmd)
        return p.pid

    def remoteRunSudo(self, user, password, host, cmd):
        ''' Usage:             ssh                               
                               also with sudo expect
            Keyword arguments: user, host, cmd
            Returns:           data, error, code
        '''
        cmd = "ssh " + user + "@" + host + " \"sudo " + cmd + "\""
        print "cmd: ", cmd
        try:
            child = pexpect.spawn(cmd)
            child.expect('.*assword:')
            child.sendline(password)
            child.expect(pexpect.EOF)    
        except:
            pass
        finally:
            try:
                child.close() 
            except:
                pass

    def remoteRunExpect(self, user, password, host, cmd, timeout=30, logname=None):
        ''' Usage:             ssh                               
                               also with expect
            Keyword arguments: user, host, cmd
            Returns:           data, error, code
        '''
        code = 0
        cmd = "ssh -t " + user + "@" + host + " \"" + cmd + "\""
        log.debug("cmd: %s" % cmd)
        try:
            child = pexpect.spawn(cmd, [], timeout)
            if logname:
                fout = open(logname, 'w')
                child.logfile_read = fout
            else:
                child.logfile_read = child.stdout
                
            index = child.expect(['[Pp]assword:', pexpect.EOF, pexpect.TIMEOUT])
            if index == 0:
                child.sendline(password)
                child.expect([pexpect.EOF, pexpect.TIMEOUT])
            if logname:
                child.logfile_read.close()
        except KeyboardInterrupt:
            child.sendcontrol('c')
            child.expect(pexpect.EOF)
        except:
            pass
        finally:
            try:
                child.close() 
            except:
                pass

    def remoteCopy(self, source, target, timeout="600"):
        ''' Usage:             scp                               
            Keyword arguments: source, target
            Returns:           data, error, code
        '''
        cmd = ['scp','-o ConnectTimeout=' + timeout, '-r', source, target]
        p = subprocess.Popen(cmd, stdout = subprocess.PIPE,\
                            stderr = subprocess.PIPE, shell = False, close_fds = True)
        stdout,stderr = p.communicate()
        print ' '.join(cmd)
        return (stdout, stderr, p.returncode)

    def remoteCopyExpect(self, user, password, host, source, target, timeout=None):
        code = 0
        cmd = "scp -r %s %s@%s:%s" % (source, user, host, target)
        print "cmd: ", cmd
        try:
            child = pexpect.spawn(cmd)
            child.expect('.*assword:')
            child.sendline(password)
            code = child.expect([pexpect.EOF, pexpect.TIMEOUT], timeout)    
        except KeyboardInterrupt:
            child.sendcontrol('c')
            child.expect(pexpect.EOF)
        except:
            pass
        finally:
            try:
                child.close() 
            except:
                pass
        return code

    def executePexpectLoop(self, cmd, os_passwd, logname=None, timeout=-1):
        # foo = pexpect.spawn(cmd)
        foo = pexpect.spawn('/bin/bash', ['-c', cmd]) #support pipes command

        log.trace("executePexpect cmd=%s" % cmd)

        if logname:
            log.trace("logname[%s]" % logname)
            fout = open(logname, 'w')
            foo.logfile_read = fout
        else:
            foo.logfile_read = foo.stdout

        result = None

        while True:
            foo.before = None
            index = foo.expect(['.*password.*', '.*Password.*', '.*\[y/N\]:', pexpect.EOF, pexpect.TIMEOUT], timeout)
            if index in [0, 1]:
                log.trace("requires password...")
                foo.sendline(os_passwd)
            elif index == 2: 
                log.trace("meets [y/N]")
                foo.sendline("yes")
            elif index == 3:
                log.trace("meets pexpect.EOF")
                result = foo.before
                foo.close()
                break
            elif index == 4:
                log.trace("meets pexpect.TIMEOUT")
                result = foo.before
                foo.close()
                break

        if logname:
            foo.logfile_read.close()
        return result

    def __killAll(self, tokillpid, killsignal = signal.SIGKILL):
        tokillpid = str(tokillpid)
        pids = dict()
        p = re.compile('\s+')

        lines = os.popen('ps -ef').read().strip().split('\n')

        for line in lines[1:]:
            line = p.split(line.lstrip())
            pid = line[1]
            ppid = line[2]
            if pid == ppid:
                continue
            if(pids.has_key(ppid)):
                pids[ppid].append(pid)
            else:
                pids[ppid] = [pid]

        tokill = [tokillpid]
        loop = 0
        length = len(tokill)
        while loop < length:
            pid = tokill[loop]
            if pids.has_key(pid):
                tokill.extend(pids[pid])
                length = len(tokill)
            try:
                os.kill(int(pid), killsignal)
            except OSError:
                print 'Subprocess %s has already been killed' % pid
            loop = loop+1

    def remoteRunExpectLoop(self, user, password, host, cmd, timeout=30, logname=None):
        cmd = "ssh -t " + user + "@" + host + " \"" + cmd + "\""
        print "cmd: ", cmd
        return self.__remoteRunExpectLoop(user, password, host, cmd, timeout, logname)

    def remoteRunSudoExpectLoop(self, user, password, host, cmd, timeout=30, logname=None):
        cmd = "ssh -t " + user + "@" + host + " \"sudo " + cmd + "\""
        print "cmd: [", cmd, "]"
        return self.__remoteRunExpectLoop(user, password, host, cmd, timeout, logname)

    def __remoteRunExpectLoop(self, user, password, host, cmd, timeout=30, logname=None):
        child = pexpect.spawn(cmd, [], timeout)
        if logname:
            fout = open(logname, 'w')
            child.logfile_read = fout
        else:
            child.logfile_read = child.stdout
                
        while True:
            child.before = None
            index = child.expect(['.*password.*', '.*Password.*', '.*\[y/N\]:', pexpect.EOF, pexpect.TIMEOUT], timeout)
            if index in [0, 1]:
                #print "requires password..."
                child.sendline(password)
            elif index == 2: 
                #print "meets [y/N]"
                child.sendline("yes")
            elif index == 3:
                #print "meets pexpect.EOF"
                stdout = child.before
                child.close()
                break
            elif index == 4:
                #print "meets pexpect.TIMEOUT"
                stdout = child.before
                child.close()
                break
        if logname:
            child.logfile_read.close()
        #print "stdout: [", stdout, "]"
        #print "exitstatus: [", child.exitstatus, "]"
        return (stdout, stdout, child.exitstatus)

if __name__ == "__main__":
    proc = Process()
    proc.remoteRunExpect('xiuping.duan', '123456', '10.250.12.36', '/home/xiuping.duan/local_performance/local_perf_test/query/abench -p 48 -s 35 -o /home/xiuping.duan/local_performance/local_perf_test/query/abench.log --http -k 10.250.12.39 26353 /home/xiuping.duan/local_performance/local_perf_test/query/random.new_galaxy_query.log', timeout=40, logname='xxx.log')
    #proc.remoteRunExpect('xiuping.duan', '123456', '10.250.12.36', 'ls ~')
