import os, os.path, re, sys, shutil
import common_utils.process as process
import common_utils.pexpect as pexpect
import atest.log as log

class SVN:
    def __init__(self):
        self.proc = process.Process()

    def checkout(self, svn_url, dest_dir, svn_revision="", svn_user=None, svn_pwd=None):
        self.proc.run("rm -fr " + dest_dir)
        revClause = self.__generateClause("--revision", str(svn_revision))
        userClause = self.__generateClause("--username", svn_user)
        pwdClause = self.__generateClause("--password", svn_pwd)
        cmd = ' '.join(['co', svn_url, userClause, pwdClause, revClause, "--non-interactive", dest_dir])
        return self.__svnOp(cmd)

    def update(self, path, svn_revision="", svn_user=None, svn_pwd=None):
        if not os.path.exists(path):
            log.warn("path[%s] does not exist!" % path)
            return False

        revClause = self.__generateClause("--revClause", str(svn_revision))
        userClause = self.__generateClause("--username", svn_user)
        pwdClause = self.__generateClause("--password", svn_pwd)
        cmd = " ".join(["up", path, userClause, pwdClause, revClause])
        data, error, code = self.__svnOp(cmd)
        if code != 0:
            log.warn("svn up path[%s] failed!" % path)
            return False

        if data.find("revision") < 0:
            log.warn("svn up path[%s] failed! data[%s], error[%s], code[%s]" \
                     % (path, data, error, code))
            return False
        return True
        
        
    def __svnOp(self, op):
        cmd = ' '.join(["/usr/bin/svn", op])
        data, error, code = self.proc.run(cmd)
        return data, error, code
        
    def __generateClause(self, key, value):
        clause = (key + '=' + value) if (key and value) else ""
        return clause

    #TODO:zhangf-mode-20170401
    def getRevisionInfo(self, modulePath):
        return '', ''

    def getRevisionInfoRm(self, modulePath):
        modulePath = os.path.realpath(modulePath)
        cmd = ' '.join(['info', modulePath])
        svnurl, version = 'N/A', 'N/A'
        try:
            svninfo, error, code = self.__svnOp(cmd)
            assert(code == 0)
            svninfo = svninfo.split('\n')
            for item in svninfo:
                if item and re.search('^URL:', item):
                    svnurl = item[len('URL:'):].strip()
                elif item and re.search("^Revision:", item):
                    version = item[len('Revision:'):].strip()
                else:
                    continue
        except Exception, e:
            log.error("Exception happened: %s" % str(e))
        return svnurl, version
        
