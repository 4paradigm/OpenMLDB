import os, sys,glob, traceback
import framework.atest_base as atest_base
import common_utils.config_parser as config_parser
from common_utils.small_toolkit import *
import common_utils.svn_util as svn_util
import atest.log as log

class FixtureBase(atest_base.ATestBase):
    def __init__(self, confFile=None):
        log.debug("BEGIN %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        self.confFile = confFile
        self.parser = None
        if confFile != None:
            if os.path.exists(confFile):
                self.parser = config_parser.MyConfigParser()
                self.parser.read(confFile)
            else:
                log.debug("conf file %s not exists" % confFile)
        else:
            log.debug("conf file not specified")
        self.globalPerfImgURL = None
        atest_base.ATestBase.__init__(self)
        log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
    def getConfVal(self, section, key):
        if self.parser is not None:
            try:
                return self.parser.get(section, key)
            except Exception, e:
                logException(e)
                return None
        else:
            log.warn("conf file not specified or non-exists") 
            return None
         
    '''
    @To override: via subclasses.
    '''
    def setUp(self):
        pass
            
    '''
    @To override: via subclasses.
    '''
    def tearDown(self):
        pass
        
    def callSetUp(self):
        log.debug("BEGIN %s::%s" % (
            self.__class__.__name__, sys._getframe(0).f_code.co_name
        ))
        ret = True
        try:
            self.setUp()
        except Exception, e:
            logException(e)
            ret = False
        log.debug("END %s::%s" % (
            self.__class__.__name__, sys._getframe(0).f_code.co_name
        ))
        return ret

    def callTearDown(self):
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        try:
            self.tearDown()
        except Exception, e:
            logException(e)
        log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
    def setIntegralPerfImgURL(self, imgURL):
        self.globalPerfImgURL = imgURL
        
    def getIntegralPerfImgURL(self):
        return self.globalPerfImgURL
        

class ProjectFixtureBase(FixtureBase):
    def __init__(self, project_conf=None):
        FixtureBase.__init__(self,project_conf)
        self.startTime = ''
        self.endTime = ''
        self.groupName = None
        self.suiteName = None
        self.caseNames = None
        self.projectName = "" #need subclass to init
        self.projectPath = None
        self.svn = svn_util.SVN()
        self.caseSVNInfo = None
        self.testModuleRootPath = ""

    '''
    @provide for user
    '''
    def getProjectConfVal(self, section, key):
        return FixtureBase.getConfVal(self,section, key)
    
    '''
    @To override: via subclasses.
    '''
    def report(self):
        pass
        
    def callReport(self):
        log.debug("BEGIN %s::%s" % (
            self.__class__.__name__, sys._getframe(0).f_code.co_name
        ))
        try:
            self.report()
        except Exception, e:
            logException(e)
        log.debug("END %s::%s" % ( 
            self.__class__.__name__, sys._getframe(0).f_code.co_name
        ))
        
    '''
    @Note:setProjectName is not provided for user
    '''
    def setProjectName(self, projectName):
        self.projectName = projectName
    
    def getProjectName(self):
        return self.projectName

    def setProjectPath(self, projectPath):
        self.projectPath = projectPath
        assert(os.path.exists(self.projectPath))
        svnurl, version = self.svn.getRevisionInfo(self.projectPath)
        self.caseSVNInfo = (svnurl, version)
    
    def getCaseSVNURL(self):
        assert(self.caseSVNInfo is not None)
        return self.caseSVNInfo[0]

    def getCaseSVNRevision(self):
        assert(self.caseSVNInfo is not None)
        return self.caseSVNInfo[1]
        
    def setTestModuleRootPath(self, testModuleRootPath):
        assert(testModuleRootPath)
        if os.path.exists(testModuleRootPath):
            self.testModuleRootPath = testModuleRootPath
        else:
            #assume input param is relative path
            testModuleRootPath = removePrefix(testModuleRootPath, prefix='/')
            self.testModuleRootPath = os.path.join(self.getCurrentPath(), testModuleRootPath)
            

    def __getTestModules(self):
        items = glob.glob(os.path.join(self.testModuleRootPath, '*'))
        ret = []
        for item in items:
            modulePath = os.path.join(self.testModuleRootPath, item)
            if os.path.isdir(modulePath):
                ret.append(modulePath)
        return ret
    
    def getTestModuleSVNInfo(self):
        buildInfo = {}
        if os.path.exists(self.testModuleRootPath):
            modules = self.__getTestModules()
            svnurl, version = 'N/A', 'N/A'
            for module in modules:
                if module.find("_external") >= 0:
                    continue
                try:
                    svnurl, version = self.svn.getRevisionInfo(module)
                except Exception, e:
                    logException(e)
                else:
                    moduleName = os.path.basename(module)
                    buildInfo[moduleName] = (svnurl, version)
        else:
            log.warn('test module root path(%s) is not existed' % self.testModuleRootPath)
        return buildInfo
        
        
    def getProjectPath(self):
        return self.projectPath
        
    def setStartTime(self, startTime):
        self.startTime = startTime
        
    def getStartTime(self):
        return self.startTime
        
    def setEndTime(self, endTime):
        self.endTime = endTime
        
    def getEndTime(self):
        return self.endTime
        
    def setExecutionGroup(self, groupName):
        self.groupName = groupName
        
    def getExecutionGroup(self):
        return self.groupName
        
    def setExecutionSuite(self, suiteName):
        self.suiteName = suiteName
        
    def getExecutionSuite(self):
        return self.suiteName
         
    def setExecutionCases(self, caseNameList):
        self.caseNames = caseNameList
        
    def getExecutionCases(self):
        return self.caseNames
        

class GroupFixtureBase(FixtureBase):
    def __init__(self, group_conf=None):
        FixtureBase.__init__(self, group_conf)
        self.projectFixture = None
        self.groupName = ""
        
    '''
    @provide for user
    '''
    def getProjectName(self):
        if self.projectFixture:
            return self.projectFixture.getProjectName()
        else:
            return None
              
    '''
    @provide for user
    '''
    def getGroupName(self):
        return self.groupName
            
    '''
    @provide for user
    '''
    def getGroupConfVal(self, section, key):
        return FixtureBase.getConfVal(self, section, key)
        
    '''
    @provide for user
    '''
    def getProjectFixture(self):
        return self.projectFixture
             
    '''
    @provide for user
    '''
    def getProjectConfVal(self, section, key):
        if self.projectFixture:
            return self.projectFixture.getProjectConfVal(section, key)
        else:
            return None
            
    def setGroupName(self, groupName):
        self.groupName = groupName
             
    def setProjectFixture(self, projectFixture):
        self.projectFixture = projectFixture
