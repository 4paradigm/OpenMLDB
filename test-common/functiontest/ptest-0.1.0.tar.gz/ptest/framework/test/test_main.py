#!/usr/bin/env python
import os
import sys
import unittest
import test_assertions
import test_atestbase

if __name__ == "__main__":
    runner = unittest.TextTestRunner()
    allTests = unittest.TestSuite()
    allTests.addTest(test_assertions.suite())
    allTests.addTest(test_atestbase.suite())
    runner.run(allTests)
