#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import unittest
currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + "/../../")
import framework.atest_base as atest_base

class TestATestBase(unittest.TestCase):
    def setUp(self):
        self.remote_config = currentPath + '/config/atest.profile'
        self.local_config = currentPath + '/config/atest.profile.local'

    def tearDown(self):
        pass
    
    def test_getATestProfile(self):
        atestBase = atest_base.ATestBase()        
        self.assertTrue(os.path.exists(atestBase.getATestProfile()))
    
    def test_get_existedKey(self):
        atestBase = atest_base.ATestBase()        
        self.assertEqual('tanght', atestBase.get('global', 'os_user'))
        self.assertEqual('None', atestBase.get('extend_lib', 'extend_lib_path'))
        self.assertEqual('/home/tanght/ainst_installroot/usr/local/', 
                         atestBase.get('users', 'install_prefix'))
        
    def test_get_nonExistedSection(self):
        atestBase = atest_base.ATestBase()        
        self.assertEqual(None, atestBase.get('errorSection', 'non_existed'))
        
    def test_get_nonExistedKey(self):
        atestBase = atest_base.ATestBase()        
        self.assertEqual(None, atestBase.get('global', 'nonExisted'))
        
    def test_getXXX(self):
        atest_base.ATestBase.setATestProfile(self.remote_config)
        atestBase = atest_base.ATestBase()
        self.assertTrue(atest_base.ATestBase.getATestProfile() == self.remote_config)
        self.assertEqual(['10.250.12.22','10.250.12.23'], atestBase.getHostsList())
        self.assertEqual(['1969','8549'],
                         atestBase.getPortsList())
   
    def test_getSystemEnv_remote(self):
        atest_base.ATestBase.setATestProfile(self.remote_config)
        atestBase = atest_base.ATestBase()
        self.assertTrue("Redhat5.4" == atestBase.getSystemEnv())
   
    def test_getSystemEnv_local(self):
        atest_base.ATestBase.setATestProfile(self.local_config)
        atestBase = atest_base.ATestBase()
        self.assertTrue("Redhat5.4" == atestBase.getSystemEnv())
        
    def test_getHardwareEnv(self):
        atest_base.ATestBase.setATestProfile(self.remote_config)
        atestBase = atest_base.ATestBase()
        self.assertTrue("Mem:24G ; CPU:HT 16 processor" == atestBase.getHardwareEnv())
    
    def test_getClusterScale(self):
        atest_base.ATestBase.setATestProfile(self.remote_config)
        atestBase = atest_base.ATestBase()
        self.assertTrue("2 machine(s)" == atestBase.getClusterScale())
     

def suite():
    suite = unittest.makeSuite(TestATestBase, 'test')
    return suite

if __name__ == "__main__":
    unittest.main()
