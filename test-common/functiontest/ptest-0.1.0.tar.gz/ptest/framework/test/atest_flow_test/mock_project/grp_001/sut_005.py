#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_002 as casePool2
import grp_001.casePool_003 as casePool3

class Test5(casePool3.casePool_003, casePool2.casePool_002):
    def suiteSetup(self):  
        actual = self.getCaseRunningList()
        expected = ['test_pool1_001', 'test_pool1_002', 'test_pool1_003', 
                    'test_pool3_001', 'test_pool3_002', 'test_pool3_003',
                    'test_pool2_001', 'test_pool2_002', 'test_pool2_003',
                    'test5_001', 'test5_002']
        self.assertEqual(expected, actual, 'unexpected case running list')
        

    def suiteTeardown(self):
        pass 
    
    def test5_001(self):
        print "Test5::test5_001..."

    def test5_002(self):
        print "Test5::test5_002..."
