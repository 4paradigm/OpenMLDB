#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_001 as casePool

class casePool_002(casePool.casePool_001):
    def test_pool2_001(self):
        print "casePool_002::test_pool2_001..."  
        
    def test_pool2_002(self):
        print "casePool_002::test_pool2_002..."

    def test_pool2_003(self):
        print "casePool_002::test_pool2_003..."
         
