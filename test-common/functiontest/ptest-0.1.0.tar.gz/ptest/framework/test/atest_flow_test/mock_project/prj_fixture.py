#!/usr/bin/env python
# -*- coding: utf-8 -*-
import framework.fixture_base as fixture_base

class ProjectFixture(fixture_base.ProjectFixtureBase):
    def setUp(self):
        pass 

    def tearDown(self):
        pass        

    def report(self):
        pass
