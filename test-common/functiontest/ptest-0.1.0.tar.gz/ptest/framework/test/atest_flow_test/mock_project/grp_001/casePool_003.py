#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_001 as casePool

class casePool_003(casePool.casePool_001):
    def test_pool3_001(self):
        print "casePool_003::test_pool3_001..." 
        
    def test_pool3_002(self):
        print "casePool_003::test_pool3_002..."

    def test_pool3_003(self):
        print "casePool_003::test_pool3_003..."
         
