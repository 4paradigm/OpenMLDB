#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_001 as casePool

class Test2(casePool.casePool_001):
    def suiteSetup(self):  
        actual = self.getCaseRunningList()
        expected = ['test_pool1_001', 'test_pool1_002', 'test_pool1_003', 
                    'test2_001', 'test2_002', 'test2_003']
        self.assertEqual(expected, actual, 'unexpected case running list')

    def suiteTeardown(self):
        pass 
    
    def test2_001(self):
        print "Test2::test2_001..." 
        
    def test2_002(self):
        print "Test2::test2_002..."

    def test2_003(self):
        print "Test2::test2_003..."
         
