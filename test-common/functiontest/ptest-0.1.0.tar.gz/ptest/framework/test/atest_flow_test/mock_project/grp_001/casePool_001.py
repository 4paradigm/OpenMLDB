#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite

class casePool_001(test_suite.TestSuite):
    def test_pool1_001(self):
        print "casePool_001::test_pool1_001..." 
        
    def test_pool1_002(self):
        print "casePool_001::test_pool1_002..."

    def test_pool1_003(self):
        print "casePool_001::test_pool1_003..."
         
