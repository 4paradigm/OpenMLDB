#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_004 as casePool4

class Test7(casePool4.casePool_004):
    def suiteSetup(self):  
        actual = self.getCaseRunningList()
        expected = ['test_pool1_001', 'test_pool1_002', 'test_pool1_003', 
                    'test_pool2_001', 'test_pool2_002', 'test_pool2_003',
                    'test_pool3_001', 'test_pool3_002', 'test_pool3_003',
                    'test_pool4_002', 'test_pool4_003',
                    'test_pool4_001', 'test6_002']
        self.assertEqual(expected, actual, 'unexpected case running list')
        

    def suiteTeardown(self):
        pass 
    
    def test_pool4_001(self):
        print "Test6::test_pool4_001..."

    def test6_002(self):
        print "Test6::test6_002..."
