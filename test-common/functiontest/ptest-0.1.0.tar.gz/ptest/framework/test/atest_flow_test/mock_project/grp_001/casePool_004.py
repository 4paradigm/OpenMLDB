#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_002 as casePool_002
import grp_001.casePool_003 as casePool_003

class casePool_004(casePool_002.casePool_002, casePool_003.casePool_003):
    def test_pool4_001(self):
        print "casePool_004::test_pool4_001..." 
        
    def test_pool4_002(self):
        print "casePool_004::test_pool4_002..."

    def test_pool4_003(self):
        print "casePool_004::test_pool4_003..."
         
