#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite

class Test1(test_suite.TestSuite):
    def suiteSetup(self):  
        actual = self.getCaseRunningList() 
        expected = ['test_001', 'test_002', 'test_003']
        self.assertEqual(expected, actual, 'unexpected case running list')

    def suiteTeardown(self):
        pass 

    def __dotest(self):
        pass
    
    def test_001(self):
        print "Test1::test_001..." 
        
    def test_002(self):
        print "Test1::test_002..."

    def test_003(self):
        print "Test1::test_003..."
         
