#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_002 as casePool

class Test4(casePool.casePool_002):
    def suiteSetup(self):  
        actual = self.getCaseRunningList()
        expected = ['test_pool1_001', 'test_pool1_002', 'test_pool1_003', 
                    'test_pool2_001', 'test_pool2_002', 'test_pool2_003',
                    'test4_001', 'test4_002']
        self.assertEqual(expected, actual, 'unexpected case running list')

    def suiteTeardown(self):
        pass 
    
    def test4_001(self):
        print "Test4::test4_001..."

    def test4_002(self):
        print "Test4::test4_002..."
