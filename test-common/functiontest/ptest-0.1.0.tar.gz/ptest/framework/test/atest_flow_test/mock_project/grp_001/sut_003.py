#!/usr/bin/python
# -*- coding: utf-8 -*- 
import framework.test_suite as test_suite
import grp_001.casePool_001 as casePool

class Test3(casePool.casePool_001):
    def suiteSetup(self):  
        actual = self.getCaseRunningList()
        expected = ['test_pool1_001', 'test_pool1_002', 'test_pool1_003']
        self.assertEqual(expected, actual, 'unexpected case running list')

    def suiteTeardown(self):
        pass 
         
