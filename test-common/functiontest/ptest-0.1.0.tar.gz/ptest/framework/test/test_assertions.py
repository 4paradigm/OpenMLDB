#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
import unittest
currentPath = os.path.split(os.path.realpath(__file__))[0]
sys.path.append(currentPath + "/../../")
import framework.assertions as assertions

class TestAssertions(unittest.TestCase):
    def setUp(self):
        self.obj = assertions.AssertionError()
        self.expect1 = "hello, kitty"
        self.expect2 = "hello2, kitty"
        self.data = "this is a hello, kitty. good-bye"

        self.obj1 = None
        self.obj2 = ""

        self.bool1 = False
        self.bool2 = True
        

    def tearDown(self):
        pass
    
    def testAssertMatch(self):
        self.obj.assertMatch(self.expect1, self.data)

    def testAssertNotMatch(self):
        self.obj.assertNotMatch(self.expect2, self.data)
        
    def testAssertMatchNegCase(self):
        self.obj.assertMatch(self.expect2, self.data)

    def testAssertNone_001(self):
        self.obj.assertNone(self.obj1)

    def testAssertNone_002(self):
        self.obj.assertNone('hello')
    
    def testAssertNotNone_001(self):
        self.obj.assertNotNone(self.obj2)

    def testAssertNotNone_002(self):
        self.obj.assertNotNone(self.obj1)
    
    def testAssertTrue(self):
        self.obj.assertTrue(self.bool2, "self.bool2 = True, check self.bool2 is True")
        self.obj.assertTrue(not self.bool2, "self.bool2 = True,check not self.bool2 is False")

    def testAssertNotTrue(self):
        self.obj.assertNotTrue(self.bool1, "self.bool1 = False, check NotTrue")
        self.obj.assertNotTrue(self.bool2, "self.bool2 = True, check NotTrue")

    def testAsserts(self):
        self.obj.asserts(self.bool2, "msgC")
        self.obj.asserts(self.bool1, "self.bool1 = False, call asserts")

    def testAssertEqual(self):
        self.obj.assertEqual(1, 1, "check 1 == 1")
        self.obj.assertEqual(1, 2, "check 1 != 2")
    
    def testAssertEquals(self):
        self.obj.assertEquals(1, 1, "1 != 1")
        self.obj.assertEquals(1, 2, "1 != 2")

    def testAssertNotEqual(self):
        self.obj.assertNotEqual(1, 2, "1 == 2")
        self.obj.assertNotEqual(2, 2, "2 == 2")
    
    def testAssertNotEquals(self):
        self.obj.assertNotEquals(1, 2, "1 == 2")

    def testAssertGreater(self):
        self.obj.assertGreater(2, 1, "2 < 1")

    def testAssertGreaterEquals1(self):
        self.obj.assertGreaterEquals(2, 2, "2 < 2")
        self.obj.assertGreaterEquals(2, 1, "2 > 1")

    def testAssertLess(self):
        self.obj.assertLess(1, 2, "1 < 2")
        self.obj.assertLess(3, 2, "1 < 2")
        
    def testAssertLessEquals1(self):
        self.obj.assertLessEquals(1, 2, "1 > 2")

    def testAssertLessEquals2(self):
        self.obj.assertLessEquals(1, 1, "1 > 1")

    def testAssertLessDelta(self):
        self.obj.assertLessDelta(1.0003, 1.0002, 0.0001)
        self.obj.assertLessDelta(1.0013, 1.0002, 0.0002)

    def testAssertLessEqualsDelta1(self):
        self.obj.assertLessEqualsDelta(1.0011, 1.0006, 0.0008)
        self.obj.assertLessEqualsDelta(1.0009, 1.0006, 0.0003)
        self.obj.assertLessEqualsDelta(1.0016, 1.0009, 0.0003)

    def testAssertGreaterDelta(self):
        self.obj.assertGreaterDelta(1.0009, 1.0001, 0.0005)
        self.obj.assertGreaterDelta(1.0004, 1.0001, 0.0003)
        self.obj.assertGreaterDelta(1.0004, 1.0001, 0.0005)

    def testAssertGreaterEqualsDelta1(self):
        self.obj.assertGreaterEqualsDelta(1.0009, 1.0001, 0.0005)
        #self.obj.assertGreaterEqualsDelta(1.0009, 1.0001, 0.0008)

    def testAssertGreaterEqualsDelta2(self):
        self.obj.assertGreaterEqualsDelta(1.0009, 1.0001, 0.0005)
    
def suite():
    suite = unittest.makeSuite(TestAssertions, 'test')
    return suite

if __name__ == "__main__":
    unittest.main()
