import os
import sys
import os.path
import re
import framework.atest_base as atest_base
import common_utils.config_parser as config_parser
import common_utils.file_util as file_util
import common_utils.process as process
import common_utils.file_util as file_util
import framework.common_define as common_define

class TemplateHandler:
    template_value = ""

    def __init__(self, path):
        self.proc     = process.Process()
        self.path = os.path.abspath(path)
        #atest_profile = atest_base.ATestBase.getATestProfile()
        #self.parser   = config_parser.MyConfigParser()
        #self.parser.read(atest_profile)
        self.profile = []
        self.isProjLevel = not os.path.basename(self.path).startswith(common_define.GROUP_IDENTIFIER)

    def fill(self):
        self.__getProfile()
        map = self.__getATestProfileUserMap()
        list = self.__getTemplateConfList()
        for template_file in list:
            content = self.__getTempalteStr(template_file)
            filled_content = self.__fillTemplateStr(content, map)
            conf = self.__getConfFile(template_file)
            self.__dumpTempate2Confs(filled_content, conf)

    def __getProfile(self):
        # get ATest profile
        self.profile.append(atest_base.ATestBase.getATestProfile())

        if self.isProjLevel:
                #get profile in project level
                pathsToCheck = [
                                os.path.join(self.path, \
                                        common_define.PROJECT_IDENTIFIER \
                                        + common_define.CONFFILE_IDENTIFIER)
                               ]
        else:
                #get profile in group level
                pathsToCheck = [
                                os.path.join(os.path.dirname(self.path), \
                                        common_define.PROJECT_IDENTIFIER \
                                        + common_define.CONFFILE_IDENTIFIER),
                                os.path.join(self.path, \
                                        common_define.GROUP_IDENTIFIER \
                                        + common_define.CONFFILE_IDENTIFIER)
                               ]

        # call file_util to fetch the profile
        fileUtil = file_util.FileUtils()
        for path in pathsToCheck:
                self.profile.extend(fileUtil.listFileName(path,
                        '*.profile'))

    def __getATestProfileUserMap(self):
        map = {}
        parser = config_parser.MyConfigParser()
        parser.read(self.profile)
        for sectionName in parser.sections():
                for item in parser.items(sectionName):    
                        key = item[0]    
                        val = item[1]
                        map[key] = val
        return map

    def __getTemplateConfList(self):
        """If the input 'path' parameter is project directory,
        replace template file for prj_conf prj_lib and all groups in project.
        Otherwise, replace template file in the group conf directory."""
        list = []
        if os.path.exists(self.path):
            if self.isProjLevel:
                pathsToCheck = [
                            os.path.join(self.path, common_define.PROJECT_IDENTIFIER \
                                                       + common_define.CONFFILE_IDENTIFIER),
                            os.path.join(self.path, common_define.PROJECT_IDENTIFIER \
                                                       + common_define.LIB_IDENTIFIER),
                            os.path.join(self.path, common_define.GROUP_IDENTIFIER + '*')
                           ]
            else:
                pathsToCheck = [
                            os.path.join(self.path, common_define.GROUP_IDENTIFIER \
                                + common_define.CONFFILE_IDENTIFIER)
                           ]

            fileUtil = file_util.FileUtils()
            for path in pathsToCheck:
                #TODO:zhangf-mod-20170401
                #list.extend(fileUtil.listFileName(path, ['*.conf.template',
                #'*.tpl']))
                pass
        return list
    
    def __getTempalteStr(self, template):
        cmd = "cat " + template
        content = self.proc.expressRun(cmd)    
        return content

    def __fillTemplateStr(self, content, map):
        singlePattern = "%%\{%s\}%%";
        listPattern = "%%\{%s\[(-?[0-9]*)(:?)(-?[0-9]*)\]\}%%";
        newContent = content
        for k,v in map.iteritems():
            TemplateHandler.template_value = v
            singlePatternStr = singlePattern % k
            listPatternStr = listPattern % k
            newContent = re.sub(singlePatternStr, v, newContent)
            newContent = re.sub(listPatternStr, 
                                TemplateHandler.listPatternHandler, 
                                newContent)
        return newContent

    def __getConfFile(self, template_file):
        if template_file.endswith('.template'):
                conf = template_file[:len(template_file)-len('.template')]
        elif template_file.endswith('.tpl'):
                conf = template_file[:len(template_file)-len(".tpl")]
        return conf

    def __dumpTempate2Confs(self, filled_content, conf):
        os.system("rm -fr " + conf)
        os.system("touch " + conf)
        filled_content += "\n"
        file_util.FileUtils.write(filled_content, conf)

    @staticmethod    
    def listPatternHandler(m):
        filledList = TemplateHandler.template_value.split(",")
        groupLen  = len(m.groups())
        listOperator = m.group(2)
        if listOperator == '':
            try:
                index = int(m.group(1))
            except:
                errorMsg = "Fill template error, cannot covert [%s] to list index" % m.group(1)
                raise RuntimeError(errorMsg)
            return filledList[index]
        else:
            leftIndex = 0
            rightIndex = len(filledList)
            if m.group(1) != '':
                leftIndex = int(m.group(1))
            if m.group(3) != '':
                rightIndex = int(m.group(3))
            return ",".join(filledList[leftIndex : rightIndex])
        pass


