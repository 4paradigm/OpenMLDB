import sys
if sys.getdefaultencoding() != 'utf-8':
    reload(sys)
    sys.setdefaultencoding('utf-8')
import os, traceback
from common_utils.small_toolkit import *
import http_request_lib as http_util

try:
    import testresult_pb2 as proto
except ImportError:
    #TODO:zhangfei-mod-20170401
    import atest.log as log
    #log.warn("Failed to import testresult_pb2, unable to use AReport.")
    #log.warn("Please install python-protobuf if you need AReport.")

import result_common_define as common_define
from result_common_util import *
HERE = os.path.split(os.path.realpath(__file__))[0] 

