#!/usr/bin/env python
# -*- coding: utf-8 -*-

RESULT_STORE_SERVICE_URL = "/areport/save_result/"
PERF_BASELINE_RETRIEVE_URL = "/areport/perf_base_line/"
GET_METHOD = 'GET'
POST_METHOD = 'POST'


#result field
PROJECT_NAME = 'projectName'
START_TIME = 'startTime'
END_TIME = 'endTime'
TOTAL_CASES = 'totalCases'
TOTAL_FAILED = 'totalFailed'
TOTAL_PASSED = 'totalPassed'
UNEXPECTED_FAILED = 'unexpectedFailed'
UNEXPECTED_PASSED = 'unexpectedPassed'
CASE_SVN_URL = 'caseSvnURL'
CASE_SVN_REVISION = 'caseSvnRevision'
MAJOR_VERSION = 'majorReleaseVersion'
MINOR_VERSION = 'minorReleaseVersion'
RELEASE_VERSION = 'releaseVersion' 
CLUSTER_ENV = 'clusterEnv'
HARDWARE_ENV = 'hardwareEnv'
SYSTEM_ENV = 'systemEnv'
PERF_IMG_URL = 'imgURL'
PERF_IMG_BACKUP = 'imgBackupPath' 
TEST_RESULT = 'testResult'
TEST_DES = 'testDes'
OTHERS_INFO = 'others'
PERF_METRICS = 'metrics'
PERF_METRICS_VALUE = 'value'
CASE_FILE = 'caseFile'
CASE_FIRST_LINE = 'caseFirstLine'

#result
EXPECTED_PASS_RESULT  = "ep"
UNEXPECTED_PASS_RESULT = 'up'
EXPECTED_FAILED_RESULT = 'ef'
UNEXPECTED_FAILED_RESULT = 'uf'

#field in db
ASSERTION_MSG = "assertionMsg"
METRICS_VALUE = "metricsValue"

#response
ERROR_MSG = "errorMsg"

#others
MAX_RETRY_TIMES = 1
