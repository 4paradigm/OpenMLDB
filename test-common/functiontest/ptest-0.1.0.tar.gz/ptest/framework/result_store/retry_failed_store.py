#!/usr/bin/env python
"""This is provided for atest user to resave old faild result store"""
import os, sys, glob, traceback
HERE = os.path.split(os.path.realpath(__file__))[0]
APP_PATH = HERE + '/../../'
if not APP_PATH in sys.path:
    sys.path.append(APP_PATH)
from test_result_save_client import * 

result_store_service_url = '10.250.12.21:8000'

def resave(failedResult):
    failedStoreDir = os.path.join(HERE, 'failed_store')
    failedStores = glob.glob(failedStoreDir + '/')
    testResultStorer = TestResultStorer(result_store_service_url)
    status = testResultStorer.saveOld(failedResult)
    return status
    
def checkParam():
    argc = len(sys.argv)
    if argc < 2:
        print "Usage: python save_failed.py <failed_file>"
        return False
    else:
        failedFile = sys.argv[1]
        if not os.path.exists(failedFile):
            failedFile = os.path.join(HERE, failedFile)
            if not os.path.exists(failedFile):
                print "%s not existed"%failedFile
                return False
            else:
                pass
        else:
            pass
        return failedFile


if __name__ == "__main__":
    ret = checkParam()
    if ret is False:
        sys.exit(1)
    else:
        f = None
        try:
            f = open(ret)
            resultStr = f.read()
            status = resave(resultStr)
            if True == status:
                print "resave result succeed"
                os.remove(ret)
            else:
                print "resave result failed"
        except Exception, e:
            print "Exception happened:%s"%e
            traceback.print_exc()
        finally:
            if f != None:
                f.close()
        
