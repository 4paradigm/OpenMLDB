#!/usr/bin/env python
# -*- coding: utf-8 -*-

import atest.log as log
from result_common_import import *

class PerfResultDetailsClient:
    def __init__(self):
        self.testResult = ""
        self.assertionMsg = ""
        self.perfResultMetrics = {}

class PerfBaseLineClient:
    def __init__(self, resultStoreServiceAddr):
        remoteServiceIp, remoteServicePort = parseServiceAddr(resultStoreServiceAddr)
        self.httpCon = http_util.HttpConnection(remoteServiceIp, remoteServicePort) 
        self.remoteServiceIp = remoteServiceIp
        self.remoteServicePort = remoteServicePort
        self.remoteServiceURL = common_define.PERF_BASELINE_RETRIEVE_URL
    
    def getPerfBaseLine(self, prjName, version, startTime):
        success = False
        perfBaseLineMap = {}
        
        req = proto.PerfBaseLineRequest()
        req.projectName = prjName.strip()
        req.majorReleaseVersion, req.minorReleaseVersion = parseVersion(version)
        req.startTime = startTime.strip()
        serializedStr = req.SerializeToString()
        
        response= self.httpCon.request(common_define.GET_METHOD, self.remoteServiceURL, serializedStr)
        
        if response != None:
            success = self.getPerfBaseLineFromResponseData(perfBaseLineMap, response)
        else:
            log.warn("no response data for service IP[%s], service port[%s], service URL[%s]" \
                     % (self.remoteServiceIp, self.remoteServicePort, self.remoteServiceURL))
            success = False

        return success, perfBaseLineMap
    
    def getPerfBaseLineFromResponseData(self, perfBaseLineMap, responseData):
        resp = proto.PerfBaseLineResponse()
        try:
            resp.ParseFromString(responseData)
        except Exception, e:
            log.warn("parse perfResponse from string[%s] failed. exception[%s]" \
                     % (responseData, str(e)))
            return False

        if resp.errorInfo.errorCode == proto.TEST_RESULT_ERROR_NONE:
            if len(resp.perfResultDetails) > 0:
                self.getPerfMetrics(perfBaseLineMap, resp.perfResultDetails)
            else:
                log.warn("no base line!")
            return True
        else:
            if resp.errorInfo.HasField(common_define.ERROR_MSG):
                log.warn("get perf base line failed! error code[%d], error msg[%s]" \
                         % (resp.errorInfo.errorCode, resp.errorInfo.errorMsg))
            else:
                log.warn("get perf base line failed! error code[%d]" \
                         % resp.errorInfo.errorCode)
            return False
        

    def getPerfMetrics(self, perfBaseLineMap, perfResultDetails):
        for perfBaseLine in perfResultDetails:
            caseInfo = perfBaseLine.testCaseInfo
            completeCaseName = "%s::%s::%s::%s" % \
                (caseInfo.projectName, caseInfo.groupName, \
                     caseInfo.suiteName, caseInfo.caseName)

            perfResultClient = PerfResultDetailsClient()
            perfResultClient.testResult = perfBaseLine.testResult
            if perfBaseLine.HasField(common_define.ASSERTION_MSG):
                perfResultClient.assertionMsg = perfBaseLine.assertionMsg

            for perfResultMetrics in perfBaseLine.perfResultMetrics:
                if perfResultMetrics.HasField(common_define.METRICS_VALUE):
                    perfResultClient.perfResultMetrics[perfResultMetrics.metricsKey] = perfResultMetrics.metricsValue

            perfBaseLineMap[completeCaseName] = perfResultClient
