#!/usr/bin/env python
# -*- coding: utf-8 -*-

import httplib
import traceback

import atest.log as log

class HttpConnection:
    def __init__(self, ip, port, headers=None):
        self.__ipAddress = ':'.join([ip.strip(), port.strip()])
        self.__httpConnection = httplib.HTTPConnection(self.__ipAddress)
        if not headers:
            self.__headers = {
                            "Content-type": "application/x-www-form-urlencoded",
                            "Accept": "text/plain"
                           }
        else:
            self.__headers = headers

    def request(self, method, url, body):
        responseBody = None
        try:
            self.__httpConnection.request(method, url, body, self.__headers)
            httpResponse = self.__httpConnection.getresponse()
            responseBody = httpResponse.read()
        except Exception, e:
            log.error("Exception happened:%s" % e)
        finally:
            self.__httpConnection.close()

        return responseBody
            

