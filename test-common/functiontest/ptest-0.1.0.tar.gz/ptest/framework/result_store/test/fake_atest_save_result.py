#!/usr/bin/env python
import os, sys
"""APP_PATH is the root path where common_utils.log_util is"""
HERE = os.path.split(os.path.realpath(__file__))[0] 
PATHS = [HERE + '/../../../', HERE + '/../']
for curpath in PATHS:
    if curpath not in sys.path:
        sys.path.append(curpath)

from result_common_import import *
from test_result_save_client import *
import result_common_define as common_define

def saveATestResult(serviceURL):
    testResultStorer = TestResultStorer(serviceAddr)
    testResultStorer.setResultSummary({
                'totalFailed': 0, 
                'totalPassed': 1, 
                'hardwareEnv': 'Mem:24G; CPU:HT 16processor',
                'caseSvnURL': 'http://svn.simba.taobao.com/svn/Apsara/heavenasks/ha3_autotest/runtime_test/trunk/search_test', 
                'projectName': 'search_test', 
                'clusterEnv': '6 machine(s)', 
                'caseSvnRevision': '117645', 
                'unexpectedFailed': 0, 
                'releaseVersion': '0.5.0', 
                'startTime': '2011-11-29 21:50:12', 
                'systemEnv': 'Red Hat Enterprise Linux Server release 5.4 (Tikanga)', 
                'endTime': '2011-11-29 21:52:39', 
                'unexpectedPassed': 0, 
                'totalCases': 1})
    testResultStorer.setFuncResultDetails({ \
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndex': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx',
                            'testResult':(common_define.UNEXPECTED_FAILED_RESULT, '2011-11-17 04:54:49 grp_build/sut_doc_field.py:testCMDWrongBuild():22|Expect:1,Actual:0 totalHits incorrect query: config=cluster:daogou&&query=mobile&&sort=+id')
                        },
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndex2': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx2',
                            'testResult':(common_define.EXPECTED_FAILED_RESULT, '2011-11-17 04:54:49 grp_build/sut_doc_field.py:testCMDWrongBuild():22|Expect:1,Actual:0 totalHits incorrect query: config=cluster:daogou&&query=mobile&&sort=+id')
                        },
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndex3': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx2',
                            'testResult':(common_define.EXPECTED_PASS_RESULT, None)
                        },
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndex4': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx2',
                            'testResult':(common_define.UNEXPECTED_PASS_RESULT, None)
                        },
                        })
    
    testResultStorer.setPerfResultDetails({ \
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndexPerf1': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx',
                            'testResult':(common_define.UNEXPECTED_FAILED_RESULT, '2011-11-17 04:54:49 grp_build/sut_doc_field.py:testCMDWrongBuild():22|Expect:1,Actual:0 totalHits incorrect query: config=cluster:daogou&&query=mobile&&sort=+id'),
                            'imgURL':'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet',
                            'metrics':{
                                          'metricsKey1_metricsKey11':('139', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey2_metricsKey11':('170', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey3_metricsKey11':('241', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey4_metricsKey11':('150', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey5_metricsKey11':('160', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey6_metricsKey11':('240', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                      }
                        },
                        'HA3_Runtime::grp_bucket_test::sut_user_scene_test::testStartServiceWithoutIndex2Perf2': \
                        {
                            'testDes':'step1:xxxxx; step2:xxxxx; step3:xxxxxx2',
                            'testResult':(common_define.EXPECTED_PASS_RESULT, '2011-11-17 04:54:49 grp_build/sut_doc_field.py:testCMDWrongBuild():22|Expect:1,Actual:0 totalHits incorrect query: config=cluster:daogou&&query=mobile&&sort=+id'),
                            'imgURL':None,
                            'metrics':{
                                          'metricsKey1_metricsKey111':('137', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey2_metricsKey111':('57',  'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey3_metricsKey111':('217', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey4_metricsKey111':('157', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey5_metricsKey111':('157', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                          'metricsKey6_metricsKey111':('113', 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/anet/trunk/anet'),
                                      }
                        }})
    
    testResultStorer.setTestTarget({
                                    'ha3:':('http://svn.simba.taobao.com/svn/Apsara', '114994'),
                                    'autil':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                    'arpc':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                    'anet':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                    'fslib':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                    'local_agent':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                    'indexlib':('http://svn/Engine-Platform/search_basics/autil/trunk', '89600'),
                                   })
    status = testResultStorer.saveNew()
    print "status=", status

if __name__ == "__main__":
    argc = len(sys.argv)
    if argc < 2:
        print "Usage: python fake_atest_save_result.py 10.250.12.21:8000"
        sys.exit(1)
    else:
        serviceAddr = (sys.argv[1]).strip()
    saveATestResult(serviceAddr)
