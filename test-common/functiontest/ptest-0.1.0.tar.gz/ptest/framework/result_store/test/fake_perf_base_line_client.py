import httplib,urllib
import os, sys
HERE = os.path.split(os.path.realpath(__file__))[0]
"""APP_PATH is the root path where common_utils.log_util is"""
PATHS = [HERE + '/../../../', HERE + '/../']
for curpath in PATHS:
    if curpath not in sys.path:
        sys.path.append(curpath)

from testresult_pb2 import *
from perf_base_line_client import PerfBaseLineClient

def getPerfBaseLine(serviceAddr):
    prjName = "HA3_Runtime"
    version = "0.5.1"
    startTime = "2011-11-24 10:01:49"
    
    client = PerfBaseLineClient(serviceAddr)
    success, perfBaseLineMap = client.getPerfBaseLine(prjName, version, startTime)
    
    if success:
        if perfBaseLineMap:
            perfBaselineMap = {}
            for key, value in perfBaseLineMap.items():
                perfBaselineMap[key] = {}
                perfBaselineMap[key]["testResult"] = value.testResult
                perfBaselineMap[key]["assertionMsg"] = value.assertionMsg
                perfBaselineMap[key]["metrics"] = value.perfResultMetrics
            print "perfBaselineMap==>", perfBaselineMap
        else:
            print "perfBaseLineMap is empty"
    else:
        print "getPerfBaseLine failed!"
    
if __name__ == "__main__":
    argc = len(sys.argv)
    if argc < 2:
        print "Usage: python fake_perf_base_line_client.py 10.250.12.21:8000"
        sys.exit(1)
    else:
        serviceAddr = (sys.argv[1]).strip()
    getPerfBaseLine(serviceAddr)
