#!/usr/bin/env python
# -*- coding: utf-8 -*-

def parseServiceAddr(resultStoreServiceAddr):
    resultStoreServiceAddr = resultStoreServiceAddr.split(':')
    remoteServiceIp = resultStoreServiceAddr[0]
    remoteServicePort = resultStoreServiceAddr[1]
    return remoteServiceIp, remoteServicePort

def parseVersion(version):
    version = version.strip()
    lastDotIdx = version.rindex('.')
    majorVersion = version[:lastDotIdx]
    minorVersion = version[(lastDotIdx + 1):]
    return majorVersion, minorVersion
