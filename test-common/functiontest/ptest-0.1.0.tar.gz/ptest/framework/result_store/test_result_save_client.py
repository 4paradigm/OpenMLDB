#!/usr/bin/env python
# -*- coding: utf-8 -*-
import atest.log as log
from result_common_import import *

class TestResultStorer:
    def __init__(self, resultStoreServiceAddr):
        remoteStoreIp, remoteStorePort = parseServiceAddr(resultStoreServiceAddr)
        self.__PBTestResult = proto.TestResult()
        self.__remoteServiceURL = common_define.RESULT_STORE_SERVICE_URL
        self.__httpCon = http_util.HttpConnection(remoteStoreIp, remoteStorePort) 
        self.__funcResultLists = {}
        self.__perfResultLists = {}
        self.__testTargetLists = {}
        self.__projectName = None
        self.__startTime = None
        self.__endTime = None
        self.__totalCases = None
        self.__totalFailed = None
        self.__totalPassed = None
        self.__unexpectedFailed = None
        self.__unexpectedPassed = None
        self.__caseSvnURL = None
        self.__caseSvnRevision = None
        self.__majorReleaseVersion = None
        self.__minorReleaseVersion = None
        self.__clusterEnv = None
        self.__hardwareEnv = None
        self.__systemEnv = None
        self.__imgURL = None

    '''
    @provider for atest
    '''
    def setResultSummary(self, resultSummaryMap):
        log.debug("BEGIN %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        self.__projectName = resultSummaryMap[common_define.PROJECT_NAME]
        self.__startTime = resultSummaryMap[common_define.START_TIME]
        self.__endTime = resultSummaryMap[common_define.END_TIME]
        self.__totalCases = resultSummaryMap[common_define.TOTAL_CASES]
        self.__totalFailed = resultSummaryMap[common_define.TOTAL_FAILED]
        self.__totalPassed = resultSummaryMap[common_define.TOTAL_PASSED]
        self.__unexpectedFailed = resultSummaryMap[common_define.UNEXPECTED_FAILED]
        self.__unexpectedPassed = resultSummaryMap[common_define.UNEXPECTED_PASSED]
        self.__caseSvnURL = resultSummaryMap[common_define.CASE_SVN_URL]
        self.__caseSvnRevision = resultSummaryMap[common_define.CASE_SVN_REVISION]
        
        releaseVersion = resultSummaryMap[common_define.RELEASE_VERSION]
        majorReleaseVersion, minorReleaseVersion = parseVersion(releaseVersion) 
        self.__majorReleaseVersion = majorReleaseVersion
        self.__minorReleaseVersion = minorReleaseVersion
        
        self.__clusterEnv = resultSummaryMap[common_define.CLUSTER_ENV]
        self.__hardwareEnv = resultSummaryMap[common_define.HARDWARE_ENV]
        self.__systemEnv = resultSummaryMap[common_define.SYSTEM_ENV]
        if resultSummaryMap.has_key(common_define.PERF_IMG_URL):
            self.__imgURL = resultSummaryMap[common_define.PERF_IMG_URL]
        #self.imgBackupPath = resultSummaryMap[common_define.PERF_IMG_BACKUP]
        log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
    def __initPBFuncResultDetails(self):
        log.debug("BEGIN %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        for caseName, resultDetail in self.__funcResultLists.items():
            PBFuncResultDetails = self.__PBTestResult.funcResultDetails.add()
            projectName, groupName, suiteName, caseName = self.__splitCaseName(caseName)
            testResult = resultDetail[common_define.TEST_RESULT][0].strip()
            PBFuncResultDetails.testResult = testResult
            assertionMsg = resultDetail[common_define.TEST_RESULT][1]
            if assertionMsg:
                assertionMsg = self.__checkInFieldValue(assertionMsg, 2000)
                PBFuncResultDetails.assertionMsg = assertionMsg.decode('utf-8')
            
            PBTestCaseInfo = PBFuncResultDetails.testCaseInfo
            PBTestCaseInfo.projectName = projectName 
            PBTestCaseInfo.groupName = groupName
            PBTestCaseInfo.suiteName = suiteName
            PBTestCaseInfo.caseName = caseName
            
            if resultDetail.has_key(common_define.TEST_DES):
                testDes = resultDetail[common_define.TEST_DES]
                if testDes:
                    testDes = self.__checkInFieldValue(testDes, 1000)
                    PBFuncResultDetails.testDes = testDes.decode('utf-8')
            
            if resultDetail.has_key(common_define.CASE_FILE) and \
                resultDetail.has_key(common_define.CASE_FIRST_LINE):
                caseFile = resultDetail[common_define.CASE_FILE]
                caseFirstLine = resultDetail[common_define.CASE_FIRST_LINE]
                if caseFile and caseFirstLine:
                    PBFuncResultDetails.caseFile = caseFile
                    PBFuncResultDetails.caseFirstLineNo = caseFirstLine
                    
        log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
        
    def __checkInFieldValue(self, value, maxLength):
        return value[:maxLength] if len(value) > maxLength else value
        

    def __splitCaseName(self, caseNames):
        '''
        caseName:projectName::groupName::suiteName::caseName
        '''
        projectName, groupName, suiteName, caseName = None, None, None, None
        items = caseNames.split("::")
        assert(len(items) == 4)
        projectName, groupName, suiteName, caseName = items[0], items[1], items[2], items[3]
        return projectName, groupName, suiteName, caseName
    

    '''
    @provider for atest
    '''
    def setFuncResultDetails(self, funcResultLists):
        '''
        funcResultLists example:
        {
           projectName::groupName::suiteName::caseName: {
           'testDes':xxx,
           'testResult':(xxx, assertionMsg)
            }
            ...
        }
        '''
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        self.__funcResultLists = funcResultLists
        log.debug("END %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
    '''
    @provider for atest
    '''
    def setPerfResultDetails(self, perfResultLists):
        '''
        perfResultLists:
            {
               projectName::groupName::suiteName::caseName: {
                'testDes':xxx,
                'imgURL':xxx,
                'testResult':(xxx,assertionMsg)
                'metrics': {
                            'metricsKey1':{'value':value1, 'imgURL':metricsImgURL},
                            'metricsKey2':{'value':value1, 'imgURL':metricsImgURL},
                            ...
                           },
                'others':xxx,
               }
              ...
           }
        '''
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        self.__perfResultLists = perfResultLists
        log.debug("END %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        
    def __initPBPerfResultDetails(self):
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        for caseName, perfResult in self.__perfResultLists.items():
            projectName, groupName, suiteName, caseName = self.__splitCaseName(caseName)
            
            PBPerfResultDetails = self.__PBTestResult.perfResultDetails.add()
            testResult = perfResult[common_define.TEST_RESULT][0]
            PBPerfResultDetails.testResult = testResult
            
            assertionMsg = perfResult[common_define.TEST_RESULT][1]
            if assertionMsg:
                assertionMsg = self.__checkInFieldValue(assertionMsg, 2000)
                PBPerfResultDetails.assertionMsg = assertionMsg.decode('utf-8')
            
            if perfResult.has_key(common_define.PERF_IMG_URL):
                imgURL = perfResult[common_define.PERF_IMG_URL]
                if imgURL:
                    PBPerfResultDetails.imgURL = perfResult[common_define.PERF_IMG_URL]
            
            if perfResult.has_key(common_define.OTHERS_INFO):
                others = perfResult[common_define.OTHERS_INFO]
                if others:
                    PBPerfResultDetails.others = others

            if perfResult.has_key(common_define.PERF_METRICS): 
                metricsMap = perfResult[common_define.PERF_METRICS]
                for metricsKey, metricsValue in metricsMap.items():
                    PBMetrics = PBPerfResultDetails.perfResultMetrics.add()
                    PBMetrics.metricsKey = metricsKey
                
                    if metricsValue.has_key(common_define.PERF_METRICS_VALUE): 
                        value = metricsValue[common_define.PERF_METRICS_VALUE]
                        if value:
                            PBMetrics.metricsValue = value
                    if metricsValue.has_key(common_define.PERF_IMG_URL):
                        imgURL = metricsValue[common_define.PERF_IMG_URL]
                        if imgURL:
                            PBMetrics.imgURL = imgURL
                 
            PBTestCaseInfo = PBPerfResultDetails.testCaseInfo
            PBTestCaseInfo.projectName = projectName
            PBTestCaseInfo.groupName = groupName
            PBTestCaseInfo.suiteName = suiteName
            PBTestCaseInfo.caseName = caseName
            
            if perfResult.has_key(common_define.TEST_DES):
                testDes = perfResult[common_define.TEST_DES]
                if testDes:
                    testDes = self.__checkInFieldValue(testDes, 1000)
                    PBPerfResultDetails.testDes = testDes.decode('utf-8')
            
            if perfResult.has_key(common_define.CASE_FILE) and \
                perfResult.has_key(common_define.CASE_FIRST_LINE):
                caseFile = perfResult[common_define.CASE_FILE]
                caseFirstLine = perfResult[common_define.CASE_FIRST_LINE]
                if caseFile and caseFirstLine:
                    PBPerfResultDetails.caseFile = caseFile
                    PBPerfResultDetails.caseFirstLineNo = caseFirstLine
        log.debug("END %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
                      
    '''
    @provider for atest
    '''
    def setTestTarget(self, testTargetLists):
        '''
        example testTargetLists:
        {
            $moduleName:($moduleSvnURL, $moduleSvnRevision),
            ...
        }
        '''
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        self.__testTargetLists = testTargetLists
        log.debug("END %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        

    '''
    @provider for atest
    '''
    def saveNew(self):
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        try:
            PBResultSummary = self.__PBTestResult.resultSummary 
            self.__initResultSummaryPB(PBResultSummary)
            self.__initPBFuncResultDetails()
            self.__initPBPerfResultDetails()
            self.__initPBTestTarget()
            serializedPBResult = self.__PBTestResult.SerializeToString()
            status = self.__postSaveRequest(serializedPBResult)
            if status is True:
                return status
            else:
                self.__saveFailedStore2Local(serializedPBResult)
                return False
        except Exception, e:
            log.warn("Exception happened:%s" % e)
            return False
        finally:
            log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
    
    
    def __postSaveRequest(self, serializedPBResult):
        tryTimes = 0
        while tryTimes < common_define.MAX_RETRY_TIMES:
            response= self.__httpCon.request(common_define.POST_METHOD, self.__remoteServiceURL, serializedPBResult)
            if response != None:
                resp = proto.SaveResultResponse()
                try:
                    resp.ParseFromString(response)
                except Exception, e:
                    log.warn("parse saveResultResponse from string[%s] failed!" % response)
                else:
                    if resp.errorInfo.errorCode == proto.TEST_RESULT_ERROR_NONE:
                        log.info("^_^save result succeed")
                        return True
                    else:
                        if resp.errorInfo.HasField("errorMsg"):
                            log.warn(":( save test result failed! errorCode[%d], errorMsg[%s]" \
                                                     % (resp.errorInfo.errorCode, resp.errorInfo.errorMsg) )
                        else:
                            log.warn(":( save test result failed! errorCode[%d]" \
                                                     % resp.errorInfo.errorCode)
            else:
                log.warn("http connection call failed")
            tryTimes += 1
        log.warn("save result failed for %d times" % common_define.MAX_RETRY_TIMES)
        return False

    '''
    @provider for atest
    '''
    def saveOld(self, serializedPBResult):
        log.debug("BEGIN %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))
        return self.__postSaveRequest(serializedPBResult)

    def __saveFailedStore2Local(self, resultStr):
        f = None
        failedFile = 'failed_store/result_%s.file'%getCurrentTime(ymdsep='_', msep='_', hmssep='_')
        try:
            failedFile = os.path.join(HERE, failedFile)
            f = open(failedFile, 'w')
            f.write(resultStr)
        except Exception, e:
            log.warn("Exception happened:%s"%e)
            log.warn('failed result is stored in local file(%s) failed!!'%failedFile)
            return None
        else:
            log.warn('failed result is stored in local file(%s) succeed'%failedFile)
            return failedFile
        finally:
            if f is not None:
                f.close()
        
        
    def __initResultSummaryPB(self, PBResultSummary):
        log.debug("BEGIN %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        PBResultSummary.projectName = self.__projectName
        PBResultSummary.startTime = self.__startTime
        PBResultSummary.endTime = self.__endTime
    
        PBResultSummary.totalCases = self.__totalCases
        PBResultSummary.totalFailed = self.__totalFailed
        PBResultSummary.totalPassed = self.__totalPassed
        PBResultSummary.unexpectedFailed = self.__unexpectedFailed
        PBResultSummary.unexpectedPassed = self.__unexpectedPassed
        
        PBResultSummary.caseSvnURL = self.__caseSvnURL
        PBResultSummary.caseSvnRevision = self.__caseSvnRevision
    
        PBResultSummary.majorReleaseVersion = self.__majorReleaseVersion
        PBResultSummary.minorReleaseVersion =self.__minorReleaseVersion

        PBResultSummary.clusterEnv = self.__clusterEnv
        PBResultSummary.hardwareEnv = self.__hardwareEnv
        PBResultSummary.systemEnv = self.__systemEnv
        if self.__imgURL:
            PBResultSummary.imgURL = self.__imgURL
        log.debug("END %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        

    def __initPBTestTarget(self):
        log.debug("BEGIN %s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        for moduleName, svnPath in self.__testTargetLists.items():
            PBTestTarget = self.__PBTestResult.testTarget.add()
            PBTestTarget.module = moduleName
            PBTestTarget.moduleSvnURL = svnPath[0]
            PBTestTarget.moduleSvnRevision = svnPath[1]
        log.debug("END %s::%s"%(self.__class__.__name__, sys._getframe(0).f_code.co_name))              

