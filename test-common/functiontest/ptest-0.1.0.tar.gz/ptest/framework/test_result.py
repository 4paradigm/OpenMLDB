import sys
import atest.log as log

class TestResult:
    def __init__(self):
        self.__all = 0
        self.__failures = []
        self.__errors = []
        self.__success = []
         
        self.__unexpected_pass = []
        self.__unexpected_failed = []
        self.__expected_failed = []
        self.__caseResultMap = {}

        self.durationMap = {}
        

    def startTest(self):
        self.__all = self.__all + 1
        

    def getAll(self):
        return self.__all
        

    def getTotalFailed(self):
        return len(self.__unexpected_failed) + len(self.__expected_failed)
        

    def getTotalPassed(self):
        return len(self.__success)
        

    def getTotalUnexpectedFailed(self):
        return len(self.__unexpected_failed)
        

    def getTotalUnexpectedPassed(self):
        return len(self.__unexpected_pass)
        

    def getTotalExpectedFailed(self):
        return len(self.__expected_failed)
        

    def addFailure(self, test, msg):
        self.__failures.append((test, msg))
        log.info("%s::%s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name, test))
        

    def addError(self, test, msg):
        self.__errors.append((test, msg))
        log.info("%s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name))
        

    def addSuccess(self, test, msg=""):
        self.__success.append((test, msg))
        log.info("%s::%s::%s" % (self.__class__.__name__, sys._getframe(0).f_code.co_name, test))
        

    def addUnexpectedPass(self, test, msg=""):
        self.__unexpected_pass.append((test, msg))
        

    def addUnexpectedFailed(self, test, msg=""):
        self.__unexpected_failed.append((test, msg))
        

    def addExpectedFailed(self, test, msg=""):
        self.__expected_failed.append((test, msg))
        

    def updateCaseResultMap(self, caseName, detailResult):
        self.__caseResultMap[caseName] = detailResult


    def setDuration(self, test, value):
        self.durationMap[test] = value
         

    def getCaseResultMap(self):
        return self.__caseResultMap
        

    def __repr__(self):
        return "[%s run=%i failures=%i errors=%i unexpected_passed=%i]" % \
                (self.__class__, self.__all, len(self.__failures), \
                 len(self.__errors), len(self.__unexpected_pass))


    '''
    @provide for user
    '''
    def getDuration(self):
        return self.durationMap

    '''
    @provide for user
    '''
    def getFailures(self):
        return self.__failures
        

    '''
    @provide for user
    '''
    def getErrors(self):
        return self.__errors
        

    '''
    @provide for user
    '''
    def getSuccesses(self):
        return self.__success
        

    '''
    @provide for user
    '''
    def getUnexpectedPass(self):
        return self.__unexpected_pass
        

    '''
    @provide for user
    '''
    def getUnexpectedFailed(self):
        return self.__unexpected_failed
        
    '''
    @provide for user
    '''
    def getExpectedFailed(self):
        return self.__expected_failed
        

    def __add__(self, anotherResult):
        self.__all += anotherResult.__all
        self.__failures += anotherResult.__failures
        self.__errors += anotherResult.__errors
        self.__success += anotherResult.__success
        self.__unexpected_pass += anotherResult.__unexpected_pass
        self.__unexpected_failed += anotherResult.__unexpected_failed
        self.__expected_failed += anotherResult.__expected_failed
        self.__caseResultMap.update(anotherResult.__caseResultMap)
        return self
        
