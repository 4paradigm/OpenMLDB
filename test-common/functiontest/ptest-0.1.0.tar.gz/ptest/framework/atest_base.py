#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import traceback

from common_utils.small_toolkit import *
import atest.log as log
import common_utils.log_util as log_util # TODO remove it from atest

import common_utils.socket_util as socket_util
import common_utils.config_parser as config_parser
import common_utils.file_util as file_util

import framework.assertions as assertions
import framework.common_define as common_define
import framework.result_store.result_common_define as result_common_define


class ATestBase(assertions.AssertionError):
    LOGGER = log_util.LOGGER   # TODO remove it! 
    UNKNOWN = 'N/A'
    perfBaselineMetrics = {}
    aTestProfile = None

    def __init__(self):
        globalConfigFile = self.getATestProfile()
        if globalConfigFile: 
            self.globalConfigParser = config_parser.MyConfigParser()
            self.globalConfigParser.read(globalConfigFile)
        else:
            self.globalConfigParser = None
        self.userConfigFile   = None
        self.userConfigParser = None
        assertions.AssertionError.__init__(self)
        self.currentPath = "" 
        self.portList = []     
        self.hosts = self.getHostsList() 
        self.testType = None    
        #--- To support get value with section, key in user-defined profile ---
        self.groupPath = ""
        self.groupProfile = []
        self.groupProfileParser = None

    @classmethod
    def getATestProfile(cls):
        globalConfigFile = cls.aTestProfile
        if not cls.aTestProfile:
            atestRoot = os.path.split(os.path.realpath(__file__))[0] + '/../'
            globalConfigFile = os.path.join(atestRoot, "conf/atest.profile")
        if os.path.exists(globalConfigFile):
            return globalConfigFile
        else:
            log.error("atest.profile not found in '%s/conf'"%atestRoot)
            return None
        

    @classmethod
    def setATestProfile(cls, aTestProfile):
        cls.aTestProfile = aTestProfile    
        

    def setTestType2Func(self):
        return self.__setTestType(common_define.FUNC_TEST)
        

    def setTestType2Perf(self):
        return self.__setTestType(common_define.PERF_TEST)


    def __setTestType(self, testType):
        if testType in self.getSupportedTestType():
            self.testType = testType
            return True
        else:
            log.warn('unsupported test type(%s)' % testType)
            return False
        

    def getTestType(self):
        return self.testType
    

    def getSupportedTestType(self):
        return [common_define.FUNC_TEST, common_define.PERF_TEST]
        
    @classmethod
    def setPerfBaselineMetrics(cls, perfBaselineMetrics):
        cls.perfBaselineMetrics = perfBaselineMetrics
        
    @classmethod
    def getPerfBaselineMetrics(cls):
        return cls.perfBaselineMetrics
    

    @classmethod
    def getPerfBaseline(cls, prjName, grpName, suiteName, caseName, metricsKey=None):
        assert(prjName and grpName and suiteName and caseName)
        caseName = '::'.join([prjName, grpName, suiteName, caseName])
        log.info("completeCaseName:%s" % caseName)
         
        perfBaselineMetricsMap = cls.getPerfBaselineMetrics()
        log.info("perfBaselineMetricsMap=%s" % perfBaselineMetricsMap)
        
        if not metricsKey:
            #return the whole perf metrics for this case
            if perfBaselineMetricsMap.has_key(caseName):
                return perfBaselineMetricsMap[caseName]
            else:
                log.warn("perfBaselineMetricsMap does not have metrics for case(%s)" % caseName)
                return {}
        else:
            #return a specified metrics for a case
            testResult, assertionMsg, metricsValue = None, None, None
            if caseName in perfBaselineMetricsMap.keys():
                testResult = perfBaselineMetricsMap[caseName][result_common_define.TEST_RESULT]
                assertionMsg = perfBaselineMetricsMap[caseName][result_common_define.ASSERTION_MSG] 
                allMetricsInBaseline = perfBaselineMetricsMap[caseName][result_common_define.PERF_METRICS]
                if metricsKey in allMetricsInBaseline.keys():
                    metricsValue = float(allMetricsInBaseline[metricsKey])
                else:
                    log.warn("specified metricsKey(%s) not found in perfBaselineMetricsMap" % metricsKey)
            else:
                log.info("specified case(%s) not found in perfBaselineMetricsMap" % caseName)
            return testResult, assertionMsg, metricsValue
            
        
    def isValidServiceAddr(self, serviceAddr):
        """
        serviceAddr:ip:port
        """
        if not serviceAddr:
            return False
        serviceAddrList = serviceAddr.split(":")
        log.debug("serviceAddrList=%s" % serviceAddrList)
        ip = serviceAddrList[0]
        port = serviceAddrList[1]
        isValidIp = re.match('[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}',ip)
        if not isValidIp:
            log.warn("serviceAddr(%s) ip(%s) is invalid" % (serviceAddr, ip))
        isValidPort = isValidUserPort(port)
        if not isValidPort:
            log.warn("serviceAddr(%s) port(%s) is invalid" % (serviceAddr, port))
        return isValidIp and isValidPort
        

    def isValidReleaseVersion(self, version):
        return re.match('^[0-9]+\.([0-9]+\.)*[0-9]+', version)
        

    def getClusterScale(self):
        if len(self.hosts) > 0:
            return ','.join(self.hosts)
        else:
            return socket_util.SocketUtil.getLocalIPAddress()
            

    def getSystemEnv(self):
        cmd = '/bin/cat /etc/redhat-release'
        ret = self.__executeCMD(cmd)
        versionList = re.findall('[0-9]\.[0-9]', ret)
        return 'Redhat' + versionList[0]
        

    def getHardwareEnv(self):
        return " ; ".join([self.__getMemory(), self.__getCPU()])
        

    def __getMemory(self):
        cmd = '/bin/cat /proc/meminfo | grep MemTotal'
        ret = self.__executeCMD(cmd)
        if ret != self.UNKNOWN:
            mem = ret.split(':')[1].strip().split(' ')
            if mem[1].lower() == 'kb':
                ret = str(int(mem[0])/(1024*1024)) + 'G'
            else:
                ret = str(mem[0]) + mem[1]
        return 'Mem:' + ret
        
    
    def __getCPU(self):
        cmd = "/bin/cat /proc/cpuinfo | grep 'processor' |wc -l"
        ret = self.__executeCMD(cmd)
        if ret != self.UNKNOWN:
            ret += ' processor'
            cmd = "/bin/cat /proc/cpuinfo | grep 'flags' |uniq"
            ret2 = self.__executeCMD(cmd)
            if ret2 != self.UNKNOWN:
                flags = ret2.split(':')[1].strip().split(' ')
                flags = [flag.lower() for flag in flags]
                if 'ht' in flags:
                    ret = 'HT ' + ret
        return 'CPU:' + ret

        
    def __getHardDisk(self):
        cmd = '/bin/df -h'
        ret = self.__executeCMD(cmd)
        ret = 'Disk:\n' + ret
        return ret

    def __executeCMD(self, cmd, returnList=False):
        if self.hosts:
            host = self.hosts[0]
            log.info('execute cmd(%s) in remote host(%s)' % (cmd,host))
            cmd = '/usr/bin/ssh %s '%host + '"' + cmd + '"'
        else:
            log.info('execute cmd(%s) in local host' % cmd)
        ret = execute_cmd(cmd)
        if ret:
            if not returnList:
                return (' '.join(ret)).strip()
            else:
                return ret
        else:
            return self.UNKNOWN
    
    
    def setCurrentPath(self, currentPath):
        self.currentPath = currentPath
    

    '''
    @provider for user to use in suite, prj_fixture, grp_fixture
    '''
    def getCurrentPath(self):
        return self.currentPath
    

    def setPortList(self, portList):
        self.portList = portList
    

    '''
    @provider for user to use in prj_fixture, grp_fixture, suite
    '''
    def getPortList(self):
        return self.portList
    

    @classmethod
    def parsePorts(cls, portList):
        """portList support the following: 
           1. portM1,portM2,portM3;portN1,portN2,...,portNn
           2. portM1:portMn;portN1:portNn
        """
        ret = []
        try:
            portLists = portList.strip().split(';')
            portLists = [p.strip() for p in portLists if p.strip()]
            for portList in portLists:
                ports = [p.strip() for p in portList.split(':')]
                if len(ports) == 2:
                    start = int(ports[0])
                    end = int(ports[1])
                    if not isValidUserPort(start):
                        raise Exception("port(%d) is not in valid user port range(1025~65534)"%start)
                    if not isValidUserPort(end):
                        raise Exception("port(%d) is not in valid user port range(1025~65534)"%end)
                    if start > end:
                        raise Exception("start port(%d) should be less than end port(%d) in port range"%(start, end))
                    ret.append([str(p) for p in range(start, end+1)])
                else:
                    ports = [p.strip() for p in portList.split(',') if p.strip()]
                    for port in ports:
                        if not isValidUserPort(port):
                            raise Exception("port:%s is not in valid user port range(1025~65534)"%port)
                    ret.append(ports)
            ret = uniqueList(ret, needStrip=False)
        except Exception, e:
            logException(e) 
        return ret


    '''
    @provide for user to get value of any key set in atest.profile
    '''
    @except_trapper
    def get(self, section, key):
        #TODO:zhangfei-mod-20170401
        try:
            value = self.globalConfigParser.get(section, key).strip() 
        except:
            value = ''
        return value
    
    def getBool(self, section, key):
        """
        transfer string type of 'true' or 'false' to bool type
        """
        ret = self.get(section, key)
        return str2bool(ret) if ret else False
    
    @except_trapper
    def getHostsList(self):
        hosts = self.get("global", "hosts_list")
        hostsList = hosts.split(",")
        return uniqueList(hostsList) 
        
    @except_trapper
    def getPortsList(self):
        strs = self.get("global", "ports_list")
        return uniqueList(strs.split(",")) 

    @except_trapper
    def getOsUser(self):
        return self.get("global", "os_user") 
    

    @except_trapper
    def getOsPassword(self):
        return self.get("global", "os_pwd")
    

    @except_trapper
    def getSvnUser(self):
        return self.get("global", "svn_user") 
    

    @except_trapper
    def getSvnPassword(self):
        return self.get("global", "svn_pwd")
    

    @except_trapper
    def getMailsList(self):
        strs = self.get("global", "mails_list") 
        return uniqueList(strs.split(","))
    

    @except_trapper
    def getExtendLib(self):
        strs = self.get("extend_lib", "extend_lib_path")
        strsList = strs.split(':')
        baseDir = os.path.dirname(os.path.abspath(__file__))
        strsList = [os.path.join(baseDir, f) for f in strsList]
        strsList = [os.path.abspath(f) for f in strsList]
        strs = ':'.join(strsList)
        return uniqueList(strs.split(':'))

    @except_trapper
    def getExtendParam(self):
        strs = self.get("extend_lib", "extend_param_path")
        strs = strs.strip()
        baseDir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(baseDir, strs)

    '''
    @provider for user to get key/value in conf file that is not in prj_conf or grp_conf 
    '''
    def setUserConfigFile(self, userConfigFilePath):
        self.userConfigFile = userConfigFilePath
        self.userConfigParser = config_parser.MyConfigParser()
        self.userConfigParser.read(self.userConfigFile)
        
        
    '''
    @provider for user to get conf value for conf file not in prj_conf or grp_conf
    '''
    @except_trapper
    def getUserConfValue(self, section, option):
        return self.userConfigParser.get(section, option)

    '''
    @support user getting value in different-level profiles
    '''

    def setGroupPath(self, path):
        self.groupPath = path

    def __getGroupProfile(self):
        self.groupProfile.append(self.getATestProfile())
        pathsToCheck = [
                        os.path.join(os.path.dirname(self.groupPath), \
                                common_define.PROJECT_IDENTIFIER \
                                + common_define.CONFFILE_IDENTIFIER),
                        os.path.join(self.groupPath, \
                                common_define.GROUP_IDENTIFIER \
                                + common_define.CONFFILE_IDENTIFIER)
                       ]
        # call file_util to fetch profile in prj_conf and grp_conf
        fileUtil = file_util.FileUtils()
        for path in pathsToCheck:
            if os.path.exists(path):
                self.groupProfile.extend(fileUtil.listFileName(path, '*.profile'))
            
    
    def getValueInProfile(self, section, key):
        # if its first time user get value from profile,
        # get profile list in group level and initialize the parser and read content
        if self.groupProfileParser == None:
            self.__getGroupProfile()
            self.groupProfileParser = config_parser.MyConfigParser()
            self.groupProfileParser.read(self.groupProfile)
        # return the value
        return self.groupProfileParser.get(section, key).strip()

