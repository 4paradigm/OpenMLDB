import os
import sys
sys.dont_write_bytecode = True
import types
import inspect

from common_utils.small_toolkit import *
import framework.atest_base as atest_base
import framework.assertions as assertions
import framework.test_result as test_result
import framework.common_define as common_define
import framework.result_store.result_common_define as result_common_define
import atest.log as log

class TestSuite(atest_base.ATestBase):
    result = test_result.TestResult()
    
    @classmethod
    def setTestResult(cls, testResult):
        TestSuite.result = testResult
        
    @classmethod
    def getTestResult(self):
        return TestSuite.result
            
    def __init__(self):
        atest_base.ATestBase.__init__(self)
        self.projectName = ""
        self.groupName = ""
        self.suiteName = ""
        self.sutSetUpFlag = False
        self.sutTearDownFlag = False
        self.runTestCasesFlag = False
        self.caseRunningList = []
        self.prjFixture = None
        self.grpFixture = None
        self.perfMetricsMap = {}
        self.caseInfoMap = {} 
        self.workConfigDir = ""
        
    '''
    @provide for user to override via subclasses
    '''
    def suiteSetup(self):
        pass

    
    '''
    @provide for user to override via subclasses
    '''
    def suiteTeardown(self):
        pass
    
    
    '''
    @provide for user to override via subclasses
    '''
    def caseSetup(self):
        pass
    
    
    '''
    @provide for user to override via subclasses
    '''
    def caseTeardown(self):
        pass
    
     
    '''
    @provide for user
    '''
    def getProjectName(self):
        return self.projectName
    
    
    '''
    @provide for user
    '''
    def getGroupName(self):
        return self.groupName
    
    
    '''
    @provide for user
    '''
    def getSuiteName(self):
        return self.suiteName
        
    
    '''
    @provide for user
    '''
    def getProjectFixture(self):
        return self.prjFixture
    

    '''
    @provide for user
    '''
    def getGroupFixture(self):
        return self.grpFixture
    
        
    '''
    @provide for user to set perf metrics for all cases in the suite
    '''
    def setPerfMetricsMap(self, metricsValueMap):
        '''
        sample metricsValueMap:
        {
            caseName1:{
                        result_common_define.PERF_IMG_URL:imgURL_for_this_case,
                        result_common_define.PERF_METRICS:{
                                    metricsKey1:{
                                                result_common_define.PERF_METRICS_VALUE: metricsValue1, 
                                                result_common_define.PERF_IMG_URL:imgURL_for_this_metrics
                                                },
                                    metricsKey2:{
                                                 result_common_define.PERF_METRICS_VALUE: metricsValue2, 
                                                 result_common_define.PERF_IMG_URL:imgURL_for_this_metrics
                                                },
                                    ...
                                  }
                     },
            ...
        }
        Note:import framework.result_store.result_common_define as result_common_define
        '''
        for caseName, metrics in metricsValueMap.items():
            try:
                self.__checkPerfMetricsSetting(caseName, metrics)
            except Exception, e:
                log.warn("!!check perf metrics setting for case(%s)" \
                         "catched exception(%s), ignore it" % (caseName, e))
            else:
                caseName = self.__getCompleteCaseName(caseName)
                self.perfMetricsMap[caseName] = metrics
        log.info("perfMetricsMap=%s" % self.perfMetricsMap)
         
        
    '''
    @provide for user to set perf metrics for a case
    '''
    def setPerfMetrics(self, metrics, caseName=None):
        '''
           assume the caller of this method is test case
           sample metrics:
           {
                result_common_define.PERF_IMG_URL:imgURL_for_this_case,
                result_common_define.PERF_METRICS:{
                          metricsKey1:{
                                      result_common_define.PERF_METRICS_VALUE: metricsValue1, 
                                      result_common_define.PERF_IMG_URL:imgURL_for_this_metrics
                                      },
                          metricsKey2:{
                                      result_common_define.PERF_METRICS_VALUE: metricsValue2, 
                                      result_common_define.PERF_IMG_URL:imgURL_for_this_metrics
                                      },
                          ...
                         }
           }
           Note:import framework.result_store.result_common_define as result_common_define
        '''
        if not caseName:
            caseName = sys._getframe(1).f_code.co_name
        try:
            self.assertTrue(caseName in self.getCaseRunningList(), \
                            'non-existed test case name(%s)' % caseName)
            self.__checkPerfMetricsSetting(caseName, metrics)
        except Exception, e:
            log.warn("!!check perf metrics setting for case(%s)" \
                     "catched exception(%s), ignore it" % (caseName, e))
        else:
            caseName = self.__getCompleteCaseName(caseName)
            self.perfMetricsMap[caseName] = metrics
            log.debug("perfMetricsMap=%s" % self.perfMetricsMap)
         
    '''
    @provide for user to get perf baseline metrics value for the specified metricskey
    '''
    def getPerfBaselineMetrics(self, metricsKey, caseName=None):
        if not caseName:
            #assume caller of this method is test case
            caseName = sys._getframe(1).f_code.co_name
        if caseName not in self.getCaseRunningList():
            log.warn('non-existed test case name(%s)' % caseName)
            testResult, assertionMsg, metricsValue = None, None, None
            return testResult, assertionMsg, metricsValue
        else:
            return atest_base.ATestBase.getPerfBaseline(self.projectName, self.groupName,
                                                        self.suiteName, caseName, metricsKey)
        
    '''
    @provide for user to get all baseline metrics for a case
    '''
    def getPerfBaselineAllMetrics(self, caseName=None):
        if not caseName:
            #assume caller of this method is test case
            caseName = sys._getframe(1).f_code.co_name    
        if caseName not in self.getCaseRunningList():
            log.warn('non-existed test case name(%s)' % caseName)
            return {}
        else:
            log.info("projectName=%s groupName=%s suiteName=%s caseName=%s"\
                                 % (self.projectName, self.groupName, self.suiteName, caseName))
            return atest_base.ATestBase.getPerfBaseline(self.projectName, self.groupName,
                                                        self.suiteName, caseName)
         
    def getPerfMetricsMap(self):
        return self.perfMetricsMap
        

    def __checkPerfMetricsSetting(self, caseName, perfMetrics): 
        self.assertTrue(hasattr(self, caseName), \
                        'specified case(%s) not in test suite(%s)' % (caseName, self.suiteName))
        
        self.assertTrue(type(perfMetrics) == types.DictType, \
                        'perf metrics of test suite(%s) is not dict type' % self.suiteName)
        
        self.assertTrue(perfMetrics.has_key(result_common_define.PERF_IMG_URL), \
                        'not found key(%s) in perf metrics of test suite(%s)'\
                        % (result_common_define.PERF_IMG_URL, self.suiteName))

        self.assertTrue(perfMetrics.has_key(result_common_define.PERF_METRICS), \
                       'not found key(%s) in perf metrics of test suite(%s)'\
                       % (result_common_define.PERF_METRICS, self.suiteName))

        metrics = perfMetrics[result_common_define.PERF_METRICS]
        for metricsKey, metricsValue in metrics.items():
            self.assertTrue(metricsKey, 'metricsKey(%s) is empty' % metricsKey)
            self.assertTrue(type(metricsValue) == types.DictType, \
                            'perf metrics value is not dict type')
            self.assertTrue(metricsValue.has_key(result_common_define.PERF_METRICS_VALUE) or \
                            metricsValue.has_key(result_common_define.PERF_IMG_URL), \
                            'not found metrics value and imgURL for metrics(%s)' % metricsKey)
            
    
    def __getCompleteCaseName(self, caseName):
        return '::'.join([self.projectName, self.groupName, self.suiteName, caseName])
         
        
    def __extractCaseInfo(self, case):
        caseName = case.im_func.func_name
        sourceLineNo = self.__getCaseCodeObjectAttr(caseName, 'co_firstlineno')
        caseFile = self.__getCaseCodeObjectAttr(caseName, 'co_filename')
        caseFileRelativePath = self.__getCaseFileRelativePath(caseFile)
         
        completeCaseName = self.__getCompleteCaseName(caseName) 
        self.caseInfoMap[completeCaseName] = {}
        testDes = inspect.getdoc(case)
        self.caseInfoMap[completeCaseName] = (testDes, caseFileRelativePath, str(sourceLineNo))
         
        
    def __getCaseFileRelativePath(self, filePath):
        #get case file path relative to group path
        items = filePath.split('/')
        items.reverse()
        j = 0
        for item in items:
            if item.startswith(common_define.GROUP_IDENTIFIER):
                break
            else:
                j -= 1
        ret = filePath.split('/')
        return '/'.join(ret[j:])


    def getCaseInfoMap(self):
        return self.caseInfoMap 
         
        
    def setProjectName(self, projectName):
        self.projectName = projectName
    

    def setGroupName(self, groupName):
        self.groupName = groupName
    

    def setSuiteName(self, suiteName):
        self.suiteName = suiteName
        

    def setProjectFixture(self, prjFixture):
        self.prjFixture = prjFixture
    

    def setGroupFixture(self, grpFixture):
        self.grpFixture = grpFixture
    

    def setSuiteSetUpFlag(self, sutSetUpFlag):
        self.sutSetUpFlag = sutSetUpFlag
    

    def setSuiteTearDownFlag(self, sutTearDownFlag):
        self.sutTearDownFlag = sutTearDownFlag
    

    def setRunTestCasesFlag(self, runTestCasesFlag):
        self.runTestCasesFlag = runTestCasesFlag
    
    def run(self, prjSetupStatus, grpSetupStatus, caseNames=[]):
        suiteSetupStatus = False
        caseSetupStatus = False
        try:
            cases = self.getCases(caseNames)
            if self.sutSetUpFlag:
                log.debug("BEGIN %s::%s:suiteSetup" % (self.groupName, self.suiteName))
                suiteSetupStatus = self.__callSuiteSetup(prjSetupStatus, grpSetupStatus)
                log.debug("END %s::%s:suiteSetup" % (self.groupName, self.suiteName))
            else:
                if self.runTestCasesFlag:
                    suiteSetupStatus = True
                else:
                    pass
            if self.runTestCasesFlag:
                for case, caseName in cases:
                    try:
                        log.debug("BEGIN %s::%s:caseSetup" % (self.groupName, self.suiteName))
                        caseSetupStatus = self.__callCaseSetup(suiteSetupStatus)
                        log.debug("END %s::%s:caseSetup" % (self.groupName, self.suiteName))

                        log.debug("BEGIN %s::%s:%s" % (self.groupName, self.suiteName, caseName))
                        self.__callTestCase(case, caseName, prjSetupStatus, grpSetupStatus, suiteSetupStatus, caseSetupStatus)
                        log.debug("END %s::%s:%s" % (self.groupName, self.suiteName, caseName))
                    except KeyboardInterrupt:
                        raise
                    finally:
                        log.debug("BEGIN %s::%s:caseTeardown" % (self.groupName, self.suiteName))
                        self.__callCaseTeardown(prjSetupStatus, grpSetupStatus, suiteSetupStatus)
                        log.debug("END %s::%s:caseTeardown" % (self.groupName, self.suiteName))
        except KeyboardInterrupt:
            raise
        finally:
            if self.sutTearDownFlag:
                log.debug("BEGIN %s::%s:suiteTeardown" % (self.groupName, self.suiteName))
                self.__callSuiteTeardown(prjSetupStatus, grpSetupStatus)
                log.debug("END %s::%s:suiteTeardown" % (self.groupName, self.suiteName))
    
    def getCases(self, caseNames):
        return self.__getCases(caseNames)

    def __getCases(self, caseNames):
        if caseNames == []:
            testCaseNames = self.__getCaseNames()
        else:
            testCaseNames = caseNames[:]
        self.caseRunningList = self.__sortCasesBySourceLineNo(testCaseNames)
        cases = []
        for caseName in self.caseRunningList:
            case = getattr(self, caseName)
            cases.append((case, caseName))
            self.__extractCaseInfo(case)
        return cases
        
    
    def getCaseRunningList(self):
        return self.caseRunningList
    

    def __callSuiteSetup(self, prjSetupStatus, grpSetupStatus):
        ret = True
        try:
            if prjSetupStatus and grpSetupStatus:
                self.suiteSetup()
            else:
                ret = False
        except KeyboardInterrupt:
            raise
        except Exception, errinfo:
            logException(errinfo)
            ret = False
        return ret
    

    def __callSuiteTeardown(self, prjSetupStatus, grpSetupStatus):
        try:
            if prjSetupStatus and grpSetupStatus:
                self.suiteTeardown()
            else:
                pass
        except Exception, e:
            logException(e)
    

    def __callCaseSetup(self, suiteSetupStatus):
        ret = True
        try:
            if suiteSetupStatus:
                self.caseSetup()
            else:
                ret = False
        except KeyboardInterrupt:
            raise
        except Exception, e:
            logException(e)
            ret = False
        return ret
    

    def __callCaseTeardown(self, prjSetupStatus, grpSetupStatus, suiteSetupStatus):
        try:
            if prjSetupStatus and grpSetupStatus and suiteSetupStatus:
                self.caseTeardown()
            else:
                pass
        except Exception, e:
            logException(e)
    

    def callTestCase(self, test_case, caseName,
                       prjSetupStatus, grpSetupStatus,
                       suiteSetupStatus, caseSetupStatus):
        test_case()    

    def __callTestCase(self, test_case, caseName,
                       prjSetupStatus, grpSetupStatus,
                       suiteSetupStatus, caseSetupStatus):
        className = self.__class__.__name__
        try:
            startTime = time.time()
            TestSuite.result.startTest()
            if False == prjSetupStatus:
                raise assertions.ProjectSetupFailException(className + "::" + caseName, self.projectName)
            if False == grpSetupStatus:
                raise assertions.GroupSetupFailException(className + "::" + caseName, self.projectName, self.groupName)
            if False == suiteSetupStatus:
                raise assertions.SuiteSetupFailException(className + "::" + caseName, self.projectName, self.groupName, self.suiteName)
            if False == caseSetupStatus:
                raise assertions.CaseSetupFailException(className + "::" + caseName, self.projectName, self.groupName, self.suiteName)
            self.callTestCase(test_case, caseName, prjSetupStatus, grpSetupStatus, suiteSetupStatus, caseSetupStatus)


            self.__updateTestResult(caseName, common_define.RESULT_PASS)
        except KeyboardInterrupt:
            raise
        except assertions.ProjectSetupFailException, e:
            self.__updateTestResult(caseName, common_define.RESULT_FAILED, str(e), envSetupSuccess=False)
            logException(e)
        except assertions.GroupSetupFailException, e:
            self.__updateTestResult(caseName, common_define.RESULT_FAILED, str(e), envSetupSuccess=False)
            logException(e)
        except assertions.SuiteSetupFailException, e:
            self.__updateTestResult(caseName, common_define.RESULT_FAILED, str(e), envSetupSuccess=False)
            logException(e)
        except assertions.CaseSetupFailException, e:
            self.__updateTestResult(caseName, common_define.RESULT_FAILED, str(e), envSetupSuccess=False)
            logException(e)
        except assertions.AssertionError, e:
            self.__updateTestResult(caseName, common_define.RESULT_FAILED, str(e))
            logException(e)
        except Exception, e:
            self.__updateTestResult(caseName, common_define.RESULT_ERROR, str(e))
            logException(e)
        endTime = time.time()
        self.__setTestResultDuration(caseName, float("{0:.3f}".format(endTime - startTime)))


    def __updateTestResult(self, caseName, result, assertionMsg=None, envSetupSuccess=True):
        completeCaseName = self.__getCompleteCaseName(caseName)
        if envSetupSuccess:
            if result == common_define.RESULT_PASS:
                TestSuite.result.addSuccess(completeCaseName, None)
                detailResult = self.__identifyDetailPass(caseName)
                TestSuite.result.updateCaseResultMap(completeCaseName, (detailResult, assertionMsg))
                if detailResult == result_common_define.UNEXPECTED_PASS_RESULT:
                    TestSuite.result.addUnexpectedPass(completeCaseName, None)
            elif result == common_define.RESULT_FAILED:                       
                TestSuite.result.addFailure(completeCaseName, assertionMsg)
                detailResult = self.__identifyDetailFailed(caseName)
                TestSuite.result.updateCaseResultMap(completeCaseName, (detailResult, assertionMsg))
                if detailResult == result_common_define.EXPECTED_FAILED_RESULT:
                    TestSuite.result.addExpectedFailed(completeCaseName, assertionMsg)
                else:
                    TestSuite.result.addUnexpectedFailed(completeCaseName, assertionMsg)
            else:
                assertionPrefix = '/'.join([self.groupName, self.suiteName]) + ':' + caseName 
                assertionMsg = "%s() pop error:%s" % (assertionPrefix, assertionMsg)
                TestSuite.result.addError(completeCaseName, assertionMsg)
                TestSuite.result.addUnexpectedFailed(completeCaseName, assertionMsg)
                TestSuite.result.updateCaseResultMap(completeCaseName,
                                                     (result_common_define.UNEXPECTED_FAILED_RESULT, assertionMsg))
        else:
            TestSuite.result.addFailure(completeCaseName, assertionMsg)
            TestSuite.result.addUnexpectedFailed(completeCaseName, assertionMsg)
            TestSuite.result.updateCaseResultMap(completeCaseName,
                                                 (result_common_define.UNEXPECTED_FAILED_RESULT, assertionMsg))

    def __setTestResultDuration(self, caseName, value):
        completeCaseName = self.__getCompleteCaseName(caseName)
        TestSuite.result.setDuration(completeCaseName, value)

    
    def __identifyDetailPass(self, caseName):
        result = result_common_define.EXPECTED_PASS_RESULT
        if caseName.endswith(common_define.SHOULD_NOT_PASS):
            result = result_common_define.UNEXPECTED_PASS_RESULT
        return result
        

    def __identifyDetailFailed(self, caseName, envSetupSuccess=True):
        result = result_common_define.UNEXPECTED_FAILED_RESULT
        if envSetupSuccess:
            if caseName.endswith(common_define.SHOULD_NOT_PASS):
                result = result_common_define.EXPECTED_FAILED_RESULT
            else:
                pass
        else:
            pass
        return result
        

    def __getCaseNames(self): 
        testSuiteClass = self.__class__   
        testCaseNames = []
        for attrName in dir(testSuiteClass):
            if (attrName.startswith(common_define.TESTCASE_IDENTIFIER)) and \
               (attrName not in testCaseNames):                
                if "method" in str(getattr(self, attrName)):
                    testCaseNames.append(attrName)
                else:
                    pass
            else:
                continue
        return testCaseNames
              
            
    def __sortCasesBySourceLineNo(self, testCaseNames):
        moduleCasesDict = self.__partitionCasesByModule(testCaseNames)
        
        bases = self.__getBases(self.__class__)
        modules = [base.__module__ for base in bases]
        modules.append(self.__class__.__module__)
        caseModules = []
        for module in modules:
            if module in moduleCasesDict.keys() and module not in caseModules:
                caseModules.append(module)
        log.debug("sortCasesBySourceLineNo case modules:%s" % caseModules)
        sortedCases = []
        for module in caseModules:
            casesInModule = moduleCasesDict[module]
            sourceLineNos = []
            sortedSourceLineNos = []
            tempSortedCases = [None for i in range(len(casesInModule))]
            for caseName in casesInModule:
                sourceLineNo = self.__getCaseCodeObjectAttr(caseName, 'co_firstlineno')  

                # add for dd
                caseId = int(caseName.rsplit("_dd_", 1)[1]) if "_dd_" in caseName else 0
                sourceLineNo = sourceLineNo*10**6 + caseId

                sourceLineNos.append(sourceLineNo)
                sortedSourceLineNos.append(sourceLineNo)
            sortedSourceLineNos.sort()
            for id, sourceLineNo in enumerate(sourceLineNos):
                loadId = sortedSourceLineNos.index(sourceLineNo)
                tempSortedCases[loadId] = casesInModule[id]
            sortedCases.extend(tempSortedCases)
        return sortedCases
        

    @except_trapper
    def __getCaseCodeObjectAttr(self, caseName, attrName):
        caseObj = getattr(self, caseName)
        caseCodeObj = getattr(caseObj, 'func_code')
        return getattr(caseCodeObj, attrName)
        
        
    def __partitionCasesByModule(self, testCaseNames):
        moduleCasesDict = {}
        for caseName in testCaseNames:
            caseObj = None
            try:
                caseObj = getattr(self, caseName)
            except Exception, e:
                log.warn("ignore invalid test case name:%s" % caseName)
                logException(e)
                continue
            if caseObj:
                module = caseObj.__module__
                if module not in moduleCasesDict.keys():
                    moduleCasesDict[module] = []
                moduleCasesDict[module].append(caseName)
        return moduleCasesDict
    
    
    def __getBases(self, cls):
        retBases = []
        bases = cls.__bases__
        if not bases:
            return []
        else:
            for base in bases:
                retBases.append(base)
                bBases = self.__getBases(base)
                if bBases:
                    id = retBases.index(base)
                    tempBases = []
                    tempBases.extend(retBases[0:id])
                    tempBases.extend(bBases)
                    tempBases.extend(retBases[id:])
                    retBases = tempBases
            return retBases


    def __del__(self):
        if self.workConfigDir.strip():
            print "delete back-up config dir_name:%s " % self.workConfigDir
            cmd = "rm -rf " + self.workConfigDir
            print cmd
            os.system(cmd)

    def getDupConfig(self, config_dir, class_name):
        #case_name = os.path.split(os.path.realpath(__file__))[-1][:-3]
        #caseName = sys._getframe(1).f_code.co_name
        if config_dir.endswith("/"): 
            self.workConfigDir = config_dir[:-1] + "_" + class_name
        else:
            self.workConfigDir = config_dir + "_" + class_name
        print "Debug_husu self.workConfigDir:%s " % self.workConfigDir
        cmd = "cp -r " + config_dir  
        cmd += " "  
        cmd += self.workConfigDir
        print cmd
        os.system(cmd)
        return self.workConfigDir

