#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
import sys
import types
import glob
import os.path
import string
import os.path
import traceback
import fixture_base
import test_suite
import common_utils.process as process
import atest.log as log
import common_utils.file_util as file_util
import framework.assertions as assertions
import framework.common_define as common_define
from common_utils.small_toolkit import *


class TestLoader:
    classCaseDirMap = {} 
    projectPath = ""

    def __init__(self):
        self.proc = process.Process()
    

    @classmethod
    def setProjectPath(self, pojectPath):
        self.projectPath = pojectPath
    
    def loadFixture(self, fixtureType, fixturePath):
        #fixture pattern: [prj|grp]_*fixture.py
        retFixture = None
        fixturePattern = fixtureType + '*' + common_define.FIXTURE_IDENTIFIER + '.py'
        fixtureFilePath = os.path.join(fixturePath, fixturePattern)
        list = glob.glob(fixtureFilePath)
        #TODO:zhangf-mode-20170401
        #log.info("load fixture:%s" % list)
        if len(list) == 0:
            retFixture = []
        else:
            retFixture = self.__loadModule(list)
        return retFixture
        

    def loadSuite(self, list):
        return self.__loadModule(list, common_define.SUITE_IDENTIFIER)
    

    def __loadModule(self, list, module_type=common_define.FIXTURE_IDENTIFIER):
        # sys.path.append(self.projectPath)
        module_obj_list = []
        for file in list:
            file = os.path.abspath(str(file))
            short_file = file[len(self.projectPath) + 1:]
            short_file = short_file.replace('/', '.')
            file_name = os.path.basename(file)
            if file_name[-3:] == '.py':
                module_name = short_file[:-3]
            else:
                (data_suite, data_loader) = file_name.split('.')[-2:]
                module_name = short_file[:-len(file_name)] + data_loader
            try:
                try:
                    __import__(module_name)
                except ImportError, e:
                    log.warn("Failed to import file %s : %s" % (file, e))
                    continue
                module = sys.modules[module_name]
                for name in dir(module):
                    obj = getattr(module, name)
                    if common_define.FIXTURE_IDENTIFIER == module_type:
                        if type(obj) == types.TypeType:
                            if issubclass(obj, fixture_base.ProjectFixtureBase) \
                                and obj.__module__ == module.__name__:
                                projectConf = self.__getFixtureConf(file, common_define.PROJECT_IDENTIFIER)
                                fixture = obj(projectConf)
                                # set group/project path
                                fixture.setGroupPath(os.path.join(os.path.dirname(file), 'notinuse'))
                                module_obj_list.append(fixture)
                                break
                            elif issubclass(obj, fixture_base.GroupFixtureBase) \
                                and obj.__module__ == module.__name__:
                                groupConf = self.__getFixtureConf(file, common_define.GROUP_IDENTIFIER)
                                fixture = obj(groupConf)
                                # set group path
                                fixture.setGroupPath(os.path.dirname(file))
                                module_obj_list.append(fixture)
                                break
                            else:
                                continue
                        else:
                            continue
                    elif common_define.SUITE_IDENTIFIER == module_type:
                        if type(obj) == types.TypeType:
                            if issubclass(obj, test_suite.TestSuite) \
                                and obj.__module__ == module.__name__:
                                suiteDirPath = os.path.dirname(file)
                                self.classCaseDirMap[obj] = suiteDirPath
                                if  file[-3:] == '.py':
                                    suite = obj()
                                else:
                                    suite = obj(file)
                                # set group path
                                suite.setGroupPath(suiteDirPath)
                                module_obj_list.append(suite)
                            else:
                                continue
                        else:
                            continue
                    else:
                        log.info("undefined module_type:%s in atest:test_loader::__loadModule" % module_type)
            except Exception, e:
                logException(e)
                continue
        return module_obj_list

    
    @classmethod
    def get_classCaseDirMap(self):
        return self.classCaseDirMap
     
    
    def __getModuleName(self, module_full):
        basename = os.path.basename(module_full)
        basename = basename[0:len(basename) - 3]
        return basename
    

    def __append2SysPath(self, module_full):
        dirname = os.path.dirname(module_full)        
        if dirname not in sys.path:
            sys.path.append(dirname)
    

    def __getFixtureConf(self, full_fixture_name, type=common_define.PROJECT_IDENTIFIER):
        #fixture conf file pattern:[prj_|grp_]*.conf
        if type not in [common_define.PROJECT_IDENTIFIER, common_define.GROUP_IDENTIFIER]:
            raise assertions.UnSupportedConfType(type)
        else:
            confs = []
            dir_name = os.path.dirname(full_fixture_name)
            conf_dir = os.path.join(dir_name, type + common_define.CONFFILE_IDENTIFIER) + "/"
            conf_pattern = type + '*.' + common_define.CONFFILE_IDENTIFIER
            conf_dir = os.path.abspath(conf_dir)
            fileUtil = file_util.FileUtils()
            confs = fileUtil.listFileName(conf_dir, conf_pattern)
            if len(confs) >= 1:
                log.info("test_loader::__getFixtureConf confs=%s" % confs)
                return confs[0]
            else:
                return None
         
    

if __name__ == "__main__":
    prj_name = "examples/ha3/prj_search_basics"
    loader = TestLoader()
    obj = loader.loadFixtureFromProject(prj_name)
    print obj

