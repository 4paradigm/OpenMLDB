#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re
import sys
import time
import types
import traceback
import types
import common_utils.process as process
import atest.log as log

class AssertionError(Exception):
    def __init__(self, msg=None):
        date = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        self.__msg = str(date) + " " + str(msg)
        self.proc = process.Process()
        
    def covert_to_unicode(self, msg):  
        '''''将转入的编码转换为unicode，只接受utf-8和unicode编码'''  
        __re_str = None  
        if isinstance(msg, unicode):  
            __re_str = msg  
        elif isinstance(msg, str):  
            try:  
                __re_str = msg.decode('utf-8')  
            except Exception, errinfo:  
               raise Exception, '%s,%s' % (errinfo, str(msg))  
        else:  
            raise Exception, '%s 必须为str或unicode类型' % msg  
        return __re_str  

    
    def __str__(self):
        return self.covert_to_unicode(self.__msg)

    
    def getFormattedError(self, expected='', actual='', checkpoint_desc=''):
        if not checkpoint_desc:
            checkpoint_desc = ''
        defaultDepth = 3
        depth = 0
        try:
            while True:
                co = sys._getframe(depth)
                caller = co.f_code.co_name
                if caller in [ 'callSetUp', 
                               'callTearDown', 
                               '__callSuiteSetup', 
                               '__callSuiteTeardown',
                               '__callCaseSetup', 
                               '__callCaseTeardown', 
                               '__callTestCase',
                               'callTestCase']:
                    break
                else:
                    depth += 1
            depth -= 1
        except ValueError, e:
            log.info("Exception happens:%s, use default stack depth" % str(e))
            depth = defaultDepth
        co = sys._getframe(depth)
        filename = '/'.join((co.f_code.co_filename).split('/')[-2:])
        if expected != '' and actual != '':
            error = "%s:%s():%s|Expect:%s,Actual:%s %s" %(filename, co.f_code.co_name, co.f_lineno, str(expected), str(actual), str(checkpoint_desc))
        elif expected != '' and actual == '':
            error = "%s:%s():%s|Expect:%s %s" %(filename, co.f_code.co_name, co.f_lineno, str(expected), str(checkpoint_desc))
        else:
            error = "%s:%s():%s|%s" %(filename, co.f_code.co_name, co.f_lineno, str(checkpoint_desc))
        return error
         
        
    def failIfDicNotEqual(self, expected_dict, actual_dic):
        if cmp(expected_dict, actual_dic) != 0:
            raise AssertionError(self.getFormattedError(expected_dict, actual_dic))
         
    
    def failIfListNotEqual(self, expected_list, actual_list):
        if cmp(expected_list, actual_list) != 0:
            raise AssertionError(self.getFormattedError(expected_list, actual_list))
        
    def failIfMatch(self, pattern, actual, msg=''):
        if re.search(pattern, actual):
            expected = "%s Actual value (%s) should not match the regular expression pattern (%s)."%(msg, str(actual), str(pattern))
            raise AssertionError(self.getFormattedError(expected))
        
    def failIfNotMatch(self, pattern, actual, msg=''):
        if not re.search(pattern, actual):
            expected = "%s Actual value (%s) should match the regular expression pattern (%s)."%(msg, str(actual), str(pattern))
            raise AssertionError(self.getFormattedError(expected))
    
    def failIfMatchFile(self, pattern, file):
        data, error, code = self.proc.run("grep \"" + pattern + "\" " + file)
        if code == 0:
            expected = "File (%s) should not match the regular expression pattern (%s)."%(str(file), str(pattern))
            raise AssertionError(self.getFormattedError(expected))
    
    def failIfNotMatchFile(self, pattern, file):
        data, error, code = self.proc.run("grep \"" + pattern + "\" " + file)
        if code != 0:
            expected = "File (%s) should match the regular expression pattern (%s)."%(str(file), str(pattern))
            raise AssertionError(self.getFormattedError(expected))
        
    def failIfNone(self, actual):
        if actual == None:
            expected = "Actual value (%s) should not be None."%str(actual)
            raise AssertionError(self.getFormattedError(expected))
    
    def failIfNotNone(self, actual):
        if actual != None:
            expected = "Actual value (%s) should be None."%str(actual)
            raise AssertionError(self.getFormattedError(expected))

    def failIfTrue(self, actual, checkpoint_desc=''):
        if bool(actual) == True:
            expected = "Actual value (%s) should not be True."%str(actual)
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc)) 
     
    def failIfNotTrue(self, actual, checkpoint_desc=''):
        if bool(actual) != True:
            expected = "Actual value (%s) should be True."%str(actual) 
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc)) 
        
    def __getType(self, variable):
        #return value: eg: 'int', 'str'
        if type(variable) is types.UnicodeType:
            variable = variable.encode('utf-8')
        variable_type = str(type(variable))
        variable_type = variable_type[(variable_type.index("'") + 1) : variable_type.rindex("'")]
        return variable_type

    def failIfNotEqual(self, expected, actual, checkpoint_desc=''):
        expected_type = self.__getType(expected)
        actual_type   = self.__getType(actual)
        if expected_type == actual_type:
            if expected_type == 'float':
                self.assertEqualDelta(expected, actual)
            else:
                if actual != expected:
                    raise AssertionError(self.getFormattedError(expected, actual, checkpoint_desc))
        else:
            raise AssertionError(self.getFormattedError("type (%s) value(%s)"%(expected_type, expected), "type (%s) value(%s)"%(actual_type, actual), checkpoint_desc))
         
    
    def failIfEqual(self, actual, unexpected, checkpoint_desc=''):
        if actual == unexpected:
            expected = "Actual value (%s) should not equal to unexpected value (%s)."%(str(actual), str(unexpected))
            raise AssertionError(self.getFormattedError(expected, '', str(checkpoint_desc)))

    def failIfGreater(self, actual, value, checkpoint_desc=''):
        if actual > value:
            expected = "Actual value (%s) should not be greater than value (%s)."%(str(actual), str(value))
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc))
    

    def failIfGreaterEquals(self, actual, value, checkpoint_desc=''):
        if actual >= value:
            expected = "Actual value (%s) should not be greater or equal to value (%s)."%(str(actual), str(value))
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc))
        
        
    def failIfLess(self, actual, value, checkpoint_desc=''):
        if actual < value:
            expected = "Actual value (%s) should be greater or equal to value (%s)."%(str(actual), str(value))
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc))
    

    def failIfLessEquals(self, actual, value, checkpoint_desc=''):
        if actual <= value:
            expected = "Actual value (%s) should be greater than value (%s)."%(str(actual), str(value))
            raise AssertionError(self.getFormattedError(expected, '', checkpoint_desc))

    #============================================================
    # alias interfaces are listed as following:
    #============================================================
    def assertDicEqual(self, expectedDict, actualDict):
        self.failIfDicNotEqual(expectedDict, actualDict)

    def assertListEqual(self, expectedList, actualList):
        self.failIfListNotEqual(expectedList, actualList)
    
    def assertMatch(self, expectedPattern, actualData, msg=''):
        self.failIfNotMatch(expectedPattern, actualData, msg)

    def assertNotMatch(self, expectedPattern, actualData, msg=''):
        self.failIfMatch(expectedPattern, actualData, msg)

    def assertMatchFile(self, pattern, file):
        self.failIfNotMatchFile(pattern, file)

    def assertNotMatchFile(self, pattern, file):
        self.failIfMatchFile(pattern, file)

    def assertNone(self, actual):
        self.failIfNotNone(actual)

    def assertNotNone(self, actual):
        self.failIfNone(actual)

    def assertTrue(self, actual, msg=''):
        self.failIfNotTrue(actual, msg)
    
    def assertFalse(self, actual, msg=''):
        self.failIfTrue(actual, msg)

    def assertNotTrue(self, actual, msg=''):
        self.failIfTrue(actual, msg)
    
    def asserts(self, actual, msg=''):
        self.failIfNotTrue(actual, msg)

    def assertEqual(self, expected, actual, msg=''):
        self.failIfNotEqual(expected, actual, msg)

    def assertEquals(self, expected, actual, msg=''):
        self.failIfNotEqual(expected, actual, msg)

    def assertNotEqual(self, actual, unexpected, msg=''):
        self.failIfEqual(actual, unexpected, msg)
    
    def assertNotEquals(self, actual, unexpected, msg=''):
        self.failIfEqual(actual, unexpected, msg)

    def assertGreater(self, actual, expected, msg=''):
        self.failIfLessEquals(actual, expected, msg)

    def assertGreaterEquals(self, actual, expected, msg=''):
        self.failIfLess(actual, expected, msg)

    def assertLess(self, actual, expected, msg=''):
        self.failIfGreaterEquals(actual, expected, msg)

    def assertLessEquals(self, actual, expected, msg=''):
        self.failIfGreater(actual, expected, msg)

    def assertLessDelta(self, left, right, delta, msg=''):
        sub = float(left) - float(right)
        if sub >= float(delta):
            expected = """The subtraction between left value (%s) and right value (%s) is less than delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))
        

    def assertLessEqualsDelta(self, left, right, delta, msg=''):
        sub = float(left) - float(right)
        if sub > float(delta):
            expected = """The subtraction between left value (%s) and right value (%s) is less or equal to delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))

    def assertAbsLessEqualsDelta(self, left, right, delta, msg=''):
        sub = abs(float(left) - float(right))
        if sub > float(delta):
            expected = """The abs(subtraction) between right value (%s) and left value (%s) is less or equal to delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))
    

    def assertGreaterDelta(self, left, right, delta, msg=''):
        sub = float(left) - float(right)
        if sub <= float(delta):
            expected = """The subtraction between left value (%s) and right value (%s) is greater than delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))
    

    def assertGreaterEqualsDelta(self, left, right, delta, msg=''):
        sub = float(left) - float(right)
        if sub < float(delta):
            expected = """The subtraction between left value (%s) and right value (%s) is greater or equal to delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))
    
    def assertEqualDelta(self, left, right, delta=1.1920929e-07, msg=''):
        if left == right:
            return
        dinominator = abs(left) > abs(right) and left or right
        sub = abs(left - right) / dinominator
        if sub > delta:
            expected = """The subtraction between left value (%s) and right value (%s) is greater than delta (%s)""" \
                        %(str(left), str(right), str(delta))
            raise AssertionError(self.getFormattedError(expected, '', msg))

    def fail(self, msg):
        raise AssertionError(self.getFormattedError('', '', msg))
    
    def assertFailure(self, msg):
        raise AssertionError(self.getFormattedError('', '', msg))
    
    def assertError(self, checkpoint_desc):
        raise AssertionError(self.getFormattedError('', '', checkpoint_desc))
    

#exception class
class ATestException(Exception):
    def __init__(self, msg=''):
        date = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))
        self.__msg = str(date) + " " + str(msg)
        
    def __repr__(self):
        return self.__msg
    
    __str__ = __repr__
    

class ProjectSetupFailException(ATestException):
    def __init__(self, caseName, projectName):
        ATestException.__init__(self, '%s failed due to %s project set up failed'\
                               %(caseName, projectName))

    
class GroupSetupFailException(ATestException):
    def __init__(self, caseName, projectName, groupName):
        ATestException.__init__(self, '%s failed due to %s::%s group setup failed'\
                               %(caseName, projectName, groupName))
    
    
class SuiteSetupFailException(ATestException):
    def __init__(self, caseName, projectName, groupName, suiteName):
        ATestException.__init__(self, '%s failed due to %s::%s::%s suite setup failed'\
                                      %(caseName, projectName, groupName, suiteName))
    
    
class CaseSetupFailException(ATestException):
    def __init__(self, caseName, projectName, groupName, suiteName):
        ATestException.__init__(self, '%s failed due to %s::%s::%s case setup failed'\
                                      %(caseName, projectName, groupName,suiteName))


class UnSupportedConfType(ATestException):
    def __init__(self, confType):
        ATestException.__init__(self, 'unsupported conf type:%s'%confType)


