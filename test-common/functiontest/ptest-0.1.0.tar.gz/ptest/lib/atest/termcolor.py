# -*- coding: utf8 -*-
#
# $$$
# Author:                  Haowei Yao
# Email:                   haowei.yao@aliyun-inc.com 
# Create Time:             Mon Mar  5 16:06:42 CST 2012
# File:                    lib/atest/termcolor.py
# Module Path:             lib
# Module Name:             atest.termcolor
# $$$
#
# Description:             Provides convinient methods to print colorful string
#                          on the terminal. For the atest terminal color format,
#                          see wiki: ATest_X.X/lib/atest/termcolor
#

# System module
import os
import re
import sys

# atest module
from atest.exception import ATestException

# error for terminal color
class TermColorError(ATestException):
    pass


# color format map
# map a color token to an actual terminal color code
# 0: reset code
# +, -, _: style code
# d, r, g, y, b, m, c, w: foreground color code
# D, R, G, Y, B, M, C, W: background color code
_color_format_map = {
    '0':0,            # reset all attributes to their defaults
    '+':1,            # set bold
    '-':2,            # set half-bright (simulated with color on a color display)
    '_':4,            # set underscore (simulated with color on a color display)
    'd':30,           # set dark/black foreground
    'r':31,           # set red foreground
    'g':32,           # set green foreground
    'y':33,           # set yellow/brown foreground
    'b':34,           # set blue foreground
    'm':35,           # set magenta foreground
    'c':36,           # set cyan foreground
    'w':37,           # set white foreground
    'D':40,           # set dark/black background
    'R':41,           # set red background
    'G':42,           # set green background
    'Y':43,           # set yellow/brown background
    'B':44,           # set blue background
    'M':45,           # set magenta background
    'C':46,           # set cyan background
    'W':47,           # set white background
}

# document format map
_doc_format_map = {
    'space' : '\*(\d+)',             # Spaces
    'left_align' : '\^(\d+)',        # Left align
    'right_align' : '\$(\d+)',       # Right align
}

def _string_to_obj(string):
    # parse the formatted string into atest terminal formatted object
    obj = {
        'seq' : []
    }

    index = 0
    level = 0
    tmp = string
    buf = ""

    fullfix = re.compile(r"^((.*?)<\s*C\s*=\s*(\S+?)\s*\/>)(.*)", re.DOTALL)
    prefix = re.compile(r"^((.*?)<\s*C\s*=\s*(\S+?)\s*>)(.*)", re.DOTALL)
    postfix = re.compile(r"^((.*?)<\s*\/C\s*>)(.*)", re.DOTALL)

    while tmp:

        matches = [fullfix.match(tmp), prefix.match(tmp), postfix.match(tmp)]
        
        def purge(i, j):
            if matches[i] and matches[j]:
                if len(matches[i].group(2)) < len(matches[j].group(2)):
                    matches[j] = None
                elif len(matches[i].group(2)) == len(matches[j].group(2)):
                    if len(matches[i].group(1)) <= len(matches[j].group(1)):
                        matches[j] = None
                    else:
                        matches[i] = None
                else:
                    matches[i] = None

        purge(0, 1)
        purge(0, 2)
        purge(1, 2)

        (fullfix_match, prefix_match, postfix_match) = matches

        if fullfix_match:
            (tag, bef, mid, aft) = fullfix_match.groups()
            if level == 0:
                obj['seq'].append(['string', bef])
                obj['seq'].append(['format', str(index), mid])
                obj[str(index)] = _string_to_obj("")
                index += 1
            else:
                buf += tag
            tmp = aft

        elif prefix_match:
            (tag, bef, mid, aft) = prefix_match.groups()
            if level == 0:
                obj['seq'].append(['string', bef])
                obj['seq'].append(['format', str(index), mid])
            else:
                buf += tag
            tmp = aft
            level += 1

        elif postfix_match:
            (tag, bef, aft) = postfix_match.groups()
            if level == 0:
                raise TermColorError("Unexpected </C> tag: %s" % string)
            level -= 1
            if level == 0:
                buf += bef
                obj[str(index)] = _string_to_obj(buf)
                index += 1
                buf = ""
            else:
                buf += tag
            tmp = aft

        # Plain text
        elif tmp != "":
            obj['seq'].append(['string', tmp])
            break
        else:
            break

    if level != 0:
        raise TermColorError("Uncompleted tags: %s" % string)

    return obj


def _parse_style(style):
    # parse the style and then return the color code and format code
    color = ""
    doc_format = {}
    
    while style:
        match = None
        for name, pattern in _doc_format_map.iteritems():
            match = re.match("^%s(\S*)" % pattern, style)
            if match:
                doc_format[name] = match.groups()[:-1]
                style = match.groups()[-1]
                break
        if match:
            continue
        color += style[0]
        style = style[1:]

    return color, doc_format

def _get_doc_len(obj):
    # get the actual length of a formatted string
    # i.e. remove the format tag and then count
    ret = 0
    for item in obj['seq']:
        if item[0] == 'string':
            ret += len(item[1])
        elif item[0] == 'format':
            ret += _get_doc_len(obj[item[1]])
    return ret

def _doc_func_space(obj, number):
    # "<C=*5/>" => "     "
    number = int(number)
    obj['seq'] = [['string', " " * number]] + obj['seq']

def _doc_func_left_align(obj, number):
    # "<C=^6>hi</C>" => "hi    "
    number = int(number)
    doc_length = _get_doc_len(obj)
    if doc_length < number:
        obj['seq'].append(['string', " " * (number - doc_length)])

def _doc_func_right_align(obj, number):
    # "<C=$^>hi</C>" => "    hi"
    number = int(number)
    doc_length = _get_doc_len(obj)
    if doc_length < number:
        obj['seq'] = [['string', " " * (number - doc_length)]] + obj['seq']


_doc_format_func = {
    # handlers of different style format
    'space' : _doc_func_space,
    'left_align' : _doc_func_left_align,
    'right_align' : _doc_func_right_align,
}
    
def _obj_to_term(obj, colorful, ps1, style="0"):
    # translate atest terminal formatted object into
    # linux/unix terminal print format
    ret = ""
    color, doc_format = _parse_style(style)

    for k, v in doc_format.iteritems():
        _doc_format_func[k](obj, *v)

    termcolor = ""
    if colorful:
        termcolor = ";".join([str(_color_format_map[x]) for x in color])
        termcolor = "\033[" + termcolor + "m"
        if ps1:
            termcolor = "\\[" + termcolor + "\\]"

    for item in obj['seq']:
        if item[0] == 'string':
            ret += item[1]
        elif item[0] == 'format':
            ret += _obj_to_term(obj[item[1]], colorful, ps1, style = color + item[2])
            ret += termcolor

    return termcolor + ret + termcolor

def cstring(string, colorful=False, ps1=False):
    # translate atest terminal formatted string 
    # into linux/unix terminal print format
    obj = _string_to_obj(string)
    return _obj_to_term(obj, colorful, ps1)
    
def cprint(string, colorful=True):
    # translate atest terminal formatted string, and print it
    colorful = colorful and sys.stdout.isatty()
    sys.stdout.write(cstring(string, colorful=colorful))


