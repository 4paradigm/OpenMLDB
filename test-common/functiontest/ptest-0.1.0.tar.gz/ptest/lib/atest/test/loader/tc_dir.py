# -*- coding: utf8 -*-
from atest.test.loader import BaseTestCaseLoader
from atest.test.case import DirTestCase

class SingleDataTCLoader(BaseTestCaseLoader):

    def load(self):

        self.tc = DirTestCase(
            self.addr,
            self,
            self.runner,
            self.path
        )

