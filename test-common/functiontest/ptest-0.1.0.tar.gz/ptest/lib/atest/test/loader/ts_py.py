# -*- coding: utf8 -*-
import imp
import types
import sys
import inspect

import atest.modld
from atest.modld import ModuleLoaderError
from atest.test.fixture import BaseTestFixture
from atest.test.loader import BaseTestSuiteLoader
from atest.test.case import SimplePyDefTestCase


class SimplePyDefTSLoader(BaseTestSuiteLoader):

    def load(self):

        if self.module_name in sys.modules:
            self.module = sys.modules[self.module_name]

        else:
            self.init_test_env()
            self.module = imp.load_source(self.module_name, self.path)
            sys.modules[self.module_name] = self.module
            self.destroy_test_env()

        # load test fixture
        try:
            fixture_class = atest.modld.load_class(
                self.module_name, BaseTestFixture
            )
            self.fixture = fixture_class(self.addr)
        except ModuleLoaderError:
            # no fixture defined in this ts_**.py
            pass

        # load test cases

        for name, obj in inspect.getmembers(self.module):
            # for each obj in this module
            if name.startswith('tc_') and isinstance(obj, types.FunctionType):
                # is a fucntion starts with tc_
                if obj.__module__ == self.module.__name__:
                    # not an imported method
                    func = getattr(self.module, name)
                    case_name = name[3:]

                    self.children[case_name] = SimplePyDefTestCase(
                        self.addr + '.' + case_name,
                        self,
                        self.runner,
                        self.path,
                        func
                    )
                    

