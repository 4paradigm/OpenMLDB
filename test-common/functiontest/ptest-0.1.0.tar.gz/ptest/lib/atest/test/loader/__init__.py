# -*- coding: utf8 -*-
import sys
import imp
import inspect
import types
import json
from collections import OrderedDict

import atest.conf as conf
import atest.modld
from atest.exception import ATestException
from atest.addr import ATestAddrContainer
from atest.test.case import *
from atest.test.runner import *
from atest.test.fixture import DummyTestFixture

sys.modules['atestloads'] = imp.new_module('atestloads')

param_requires = OrderedDict()

class TestLoaderError(ATestException):
    pass


class TestLoaderNotMatched(TestLoaderError):
    pass


class BaseTestLoader:

    param_require = {}
    
    def __init__(self, path, conf, addr):
        self.path = path
        self.conf = self._init_conf(conf)

        if not self.match():
            raise TestLoaderNotMatched()

        self.parent = None
        self.children = OrderedDict()

        self.name = self._get_name()
        if addr != "":
            self.addr = addr + '.' + self.name
        else:
            self.addr = self.name

        self.module_name = 'atestloads._loads_' + self.addr.replace('.', '_')
       
        self.runner = None
        if self.conf['runner']:
            self.init_test_env()
            runner_class = atest.modld.load_class(
                self.conf['runner'], 
                BaseTestRunner
            )
            self.runner = runner_class()
            self.destroy_test_env()

        self.loaded = False

        # append parameter requirements to let the caller know
        for k, v in self.__class__.param_require.iteritems():
            globals()['param_requires'][k] = v

    def add_parent(self, parent):
        self.parent = parent
        if parent != None:
            self.parent.children[self.name] = self
    
    def _get_name(self):
        basename = self.path.basename()
        filename = basename.split('.')[0]
        
        if self.conf['prefix']:
            prefix = self.conf['prefix']
            filename = filename[len(prefix):]

        return filename

    def _init_conf(self, conf):
        ret = {
            'level' : 'ts'
        }

        ret.update(conf)

        if ret['level'] == 'ts':
            ret = {
                'level' : 'ts',
                'prefix' : 'ts_',
                'except' : None,
                'type' : 'file',
                'extension' : None,
                'subdir_prefix' : None,
                'subdir_except' : None,
                'runner' : None,
                'conf_dir' : 'conf',
                'res_dir' : 'res',
                'lib_dir' : 'lib',
            }
        else:
            ret = {
                'level' : 'tc',
                'prefix' : 'tc_',
                'except' : None,
                'type' : 'file',
                'extension' : None,
                'subdir_prefix' : None,
                'subdir_except' : None,
                'runner' : None,
            }

        ret.update(conf)

        if ret['prefix'] == 'None':
            ret['prefix'] = None
        return ret

    def match(self):

        # check prefix
        if self.conf['prefix']:
            if not self.path.basename().startswith(self.conf['prefix']):
                return False
                
        # check prefix
        if self.conf['except']:
            if self.path.basename() in self.conf['except']:
                return False

        # check file
        if self.conf['type'] == 'file':
            file_path = self.path

            if self.conf['extension']:
                extension = ".".join(file_path.basename().split('.')[1:])
                if extension != self.conf['extension']:
                    return False
            if not file_path.isfile():
                return False

        # check directory
        if self.conf['type'] == 'dir':
            if not self.path.isdir():
                return False

        # check sub dir prefix
        if self.conf['subdir_prefix']:
            find_subdir = False
            for subdir in self.path:
                if subdir.isdir():
                    if subdir.basename().startswith(self.conf['subdir_prefix']):
                        if not self.conf['subdir_except'] or not subdir.basename() in self.conf['subdir_except']:
                            find_subdir = True
                            break
            if not find_subdir:
                return False

        # all matched
        return True

    def load(self):
        # to override
        pass

    def xload(self):
        if not self.loaded:
            self.load()
            self.loaded = True

    def init_test_env(self):
       
        if self.parent != None:
            self.parent.init_test_env()

        # load extend lib
        extend_lib = str(conf.get('test.extendlib.install'))
        if extend_lib not in sys.path:
            sys.path.append(extend_lib)

    def destroy_test_env(self):
        for child in self.children.values():
            if isinstance(child, BaseTestLoader):
                child.destroy_test_env()
            else:
                # it can be a TestCase !
                pass

    def find_root(self):
        root = self
        while root.parent != None:
            root = root.parent
        return root


class BaseTestSuiteLoader(BaseTestLoader, dict):

    def __init__(self, path, conf, addr):
        self.children = OrderedDict()
        BaseTestLoader.__init__(self, path, conf, addr)
        self.fixture = DummyTestFixture(self.addr)     # fixture instance for this test suite

    def __getitem__(self, key):
        return self.get_child(key)

    def get_child(self, key):
        self.xload()

        if key in self.children:
            return self.children[key]
        else:
            raise TestLoaderError(
                "Failed to get tc or ts '%s' in ts '%s'."
                % (key, self.addr)
            )

    def keys(self):
        return self.list()

    def values(self):
        ret = []
        for key in self.keys():
            ret.append(self[key])
        return ret

    def iteritems(self):
        ret = []
        for key in self.keys():
            ret.append((key, self[key]))
        return ret

    def items(self):
        return self.iteritems()

    def list(self):
        self.xload()

        return self.children.keys()

    def init_test_env(self):
        BaseTestLoader.init_test_env(self)
        if self.conf['type'] == 'dir':
            conf_dir = self.path / self.conf['conf_dir']
            res_dir = self.path / self.conf['res_dir']
            lib_dir = self.path / self.conf['lib_dir']

            if lib_dir.isdir():
                if lib_dir not in sys.path:
                    sys.path.append(lib_dir)

            if conf_dir.isdir():
                conf.append_conf_dir(conf_dir)

            if res_dir.isdir():
                atest.resource.append_res_dir(res_dir)

    def destroy_test_env(self):
        BaseTestLoader.destroy_test_env(self)

        if self.conf['type'] == 'dir':
            conf_dir = self.path / self.conf['conf_dir']
            res_dir = self.path / self.conf['res_dir']
            lib_dir = self.path / self.conf['lib_dir']

            if lib_dir in sys.path:
                sys.path.remove(lib_dir)

            conf.reset_conf()
            atest.resource.reset_res()

    def generate_test_case(self, name):
        # it's supposed to called in self.load() for user
        return TestCase(
            self.addr + '.' + name,
            self,
            self.runner,
            self.path,
        )


class BaseTestCaseLoader(BaseTestLoader):

    def __init__(self, path, conf, addr):
        BaseTestLoader.__init__(self, path, conf, addr)
        self.fixture = DummyTestFixture(self.addr)     # fixture instance for this test suite

    def get_case(self):
        self.xload()
        return self.tc
        
    def init_test_env(self):
        BaseTestLoader.init_test_env(self)

    def destroy_test_env(self):
        BaseTestLoader.destroy_test_env(self)

    def generate_test_case(self):
        # it's supposed to be called in self.load() for the user

        return TestCase(
            self.addr,
            self,
            self.runner,
            self.path
        )


def get_test_loader_by_path(path, base_addr, parent=None):
    loader = None

    if parent != None:
        parent.init_test_env()

    for name in conf.get('test.loader.##keys'):
        loader_module = conf.get('test.loader.%s.module' % name)
        loader_class = atest.modld.load_class(loader_module, BaseTestLoader)
        try:
            loader = loader_class(
                path, 
                conf.get('test.loader.%s' % name), 
                base_addr,
            )

            if parent != None:
                loader.add_parent(parent)

        except TestLoaderNotMatched:
            pass


    if parent != None:
        parent.destroy_test_env()
        
    return loader


def _load_local_path(path):

    paths = []

    while path != "/":
        paths.append(path)
        path = path.dirname()

    paths.reverse()

    loader = None
    root = None
    base_addr = ""

    for path in paths:
        loader = get_test_loader_by_path(
            path, base_addr.rstrip("."),
            parent=loader
        )
        if loader != None:
            base_addr += loader.name + "."
            if root == None:
                root = loader
        else:
            # no loader found for that level
            base_addr = ""
            root = None
        
    return (root, base_addr)


def load_local_path(path):

    (root, base_addr) = _load_local_path(path.abspath())

    if root != None:
        cntr = ATestAddrContainer({root.name : root})
        return (cntr, base_addr)
    else:
        raise TestLoaderError("Failed to find loader for test path '%s'. Maybe it's not a valid test path, or the loader is not defined." % path)


def list_local_path(path):

    cntr, prefix = load_local_path(path)
    cases = []

    for addr, tc_loader in cntr.get('%s##tree' % prefix):
        cases.append((prefix + addr).strip("."))

    return cases

