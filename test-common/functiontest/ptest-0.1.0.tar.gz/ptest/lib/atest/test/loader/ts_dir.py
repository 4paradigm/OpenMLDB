# -*- coding: utf8 -*-

import atest.test.loader
from atest.test.fixture import BaseTestFixture
from atest.test.loader import BaseTestSuiteLoader

class DirTSLoader(BaseTestSuiteLoader):

    fixture_name = 'fixture.py'

    def _load_fixture(self):
        # load test fixture
        fixture_file = self.path / self.fixture_name
        if fixture_file.isfile():
            self.init_test_env()

            fixture_class = atest.modld.load_class_from_source(
                fixture_file, BaseTestFixture
            )
            self.fixture = fixture_class(self.addr)
            self.destroy_test_env()

    def _load_children(self):
        # load test suites and test cases
    
        for item in self.path.listdir():

            basename = item.basename()
            if basename == self.conf['conf_dir']:
                continue
            if basename == self.conf['res_dir']:
                continue
            if basename == self.conf['lib_dir']:
                continue

            self.init_test_env()
            loader = atest.test.loader.get_test_loader_by_path(
                item, self.addr, self
            )
            self.destroy_test_env()

            if loader != None:
                loader.add_parent(self)

    def load(self):
        self._load_fixture()
        self._load_children()

