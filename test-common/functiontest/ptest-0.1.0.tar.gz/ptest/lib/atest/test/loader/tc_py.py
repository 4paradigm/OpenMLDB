# -*- coding: utf8 -*-
from atest.test.case import SinglePythonTestCase
from atest.test.loader import BaseTestCaseLoader

class SinglePythonTCLoader(BaseTestCaseLoader):

    def load(self):

        self.tc = SinglePythonTestCase(
            self.addr,
            self,
            self.runner,
            self.path,
            self.module_name,
        )

