# -*- coding: utf8 -*-
tc = None
case = None  # case == tc, for backward compatible

build = None
plan = None
result = None

build_path = None

runtime_build_uuid = None
runtime_case_uuid = None

fixtures = []

# compatible mode
sut = None
grp = None
prj = None
