import traceback

import atest.log as log
import atest.resource as res
from atest.resource import ATestBaseResource, ATestResourceError

class TestFixtureError(ATestResourceError):
    pass

# a fixture map to store fixtures by its name
# for user to retreive fixture by name
fixtures = {}

# used by test runner to know current fixture scope
scopes = set()

class BaseTestFixture(ATestBaseResource):

    name = "<None>"

    def __init__(self, fixture_addr):
        global fixtures

        self.fixture_addr = fixture_addr
        res_addr = res.set_res('fixtures.' + self.fixture_addr, self)
        ATestBaseResource.__init__(self, res_addr)

        parent_addr = ".".join(self.addr.split('.')[:-1])
        if parent_addr == "__dynamic__.fixtures":
            # we reach the top
            self.parent = None
            pass
        else:
            parent = res._res_cache[parent_addr]
            res.set_dependency(self, parent)
            self.parent = parent

        if self.name == "<None>":
            self.name = self.fixture_addr

        fixtures[self.name] = self
        
        # execute flags
        self.lazy_mode = True
        self.setup_only = False
        self.teardown_only = False
        self._fixture_tag = self.path / 'fixture.tag'
        self.skipped_flag = False

    def _do_build(self):
        if self.teardown_only:
            return

        if self._fixture_tag.isfile() and self.lazy_mode:
            self.skipped_flag = True

        if self.skipped_flag:
            return

        log.info("Setup fixture '%s' ..." % self.fixture_addr)

        try:
            self.setup()
            self._fixture_tag.touch()
        except BaseException as e:
            self.build_failed = True
            log.warn(
                "test fixture '%s' setup failed: \n%s"
                % (self.fixture_addr, traceback.format_exc())
            )
            raise TestFixtureError(
                "test fixture '%s' setup failed: %s: %s"
                % (self.fixture_addr, e.__class__.__name__, str(e))
            )

    def _do_destroy(self):
        if self.setup_only:
            return

        if self.skipped_flag:
            return

        log.info("Teardown fixture '%s' ..." % self.fixture_addr)
        try:
            self.teardown()
        except BaseException as e:
            self.destroy_failed = True
            log.warn(
                "test fixture '%s' teardown failed: \n%s"
                % (self.fixture_addr, traceback.format_exc())
            )
        self._fixture_tag.remove()

    def do_case_setup(self, case):
        if self.parent != None:
            self.parent.do_case_setup(case)

        try:
            self.case_setup(case)
        except Exception as e:
            log.warn(
                "test fixture '%s' case setup failed at case %s: \n%s"
                % (self.fixture_addr, case.addr, traceback.format_exc())
            )
            raise TestFixtureError(
                "test fixture '%s' case setup failed at case %s: %s: %s"
                % (self.fixture_addr, case.addr, e.__class__.__name__, str(e))
            )

    def do_case_teardown(self, case):
        try:
            self.case_teardown(case)
        except Exception as e:
            log.warn(
                "test fixture '%s' case teardown failed at case %s: \n%s"
                % (self.fixture_addr, case.addr, traceback.format_exc())
            )

        if self.parent != None:
            self.parent.do_case_teardown(case)

    def case_setup(self, case):
        # to override
        pass

    def case_teardown(self, case):
        # to override
        pass
        
    def setup(self):
        # to override
        pass

    def teardown(self):
        # to override
        pass



class DummyTestFixture(BaseTestFixture):

    # used when no fixture class is actually defined

    def _do_build(self):
        pass

    def _do_destroy(self):
        pass


class StrictTestFixture(BaseTestFixture):

    skip_destroy_if_build_failed = False

    def _do_build(self):
        global scopes
        if self.fixture_addr not in scopes:
            scopes.add(self.fixture_addr)
        BaseTestFixture._do_build(self)

    def _do_destroy(self):
        global scopes
        if self.fixture_addr in scopes:
            scopes.remove(self.fixture_addr)
        BaseTestFixture._do_destroy(self)


def rotate_scope():
    # make the test fixture to enter the next scope

    global scopes

    if len(scopes) == 0:
        return

    target_scope = ""

    for scope in scopes:
        
        if len(scope) > len(target_scope):
            target_scope = scope

    try:
        # make sure destroy will be run even when build failed
        fixture = res.get_dynamic_res("__dynamic__.fixtures." + target_scope, build=False)
        fixture.destroy()
    except ATestResourceError:
        log.warn("Fixture %s destroy failed:\n%s" 
                 % (target_scope, traceback.format_exc()))


