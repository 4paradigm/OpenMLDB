# -*- coding: utf8 -*-

try:
    import json
except ImportError:
    import simplejson as json

from atest.exception import ATestException
from atest.path import Path

class TestPlanError(ATestException):
    pass


class TestPlan:
    pass


class NoneTestPlan(TestPlan):

    def __init__(self):
        self.name = "no_plan"


class LocalTestPlan(TestPlan):

    def __init__(self, plan_file):

        # FIXME plan_file should be called 'build_file'
        # due to BUG: http://bugfree.corp.taobao.com/bug/218079

        json_obj = json.loads(plan_file.read())

        for key in ["local_path", "purpose", "people", "case_list", "executor"]:
            if not key in json_obj:
                raise TestPlanError(
                    "Test plan %s: no %s specified."
                    % (plan_file, key)
                )

        if 'plan_name' in json_obj:
            self.name = json_obj['plan_name']

        elif 'name' in json_obj:
            # we use a new 'plan_name' now
            # keep it for backward compatibility
            self.name = json_obj['name']
        else:
            raise TestPlanError(
                "Test plan %s: plan_name not specified."
                % plan_file
            )
            
        self.purpose = json_obj['purpose']
        self.people = json_obj['people']

        self.case_list = json_obj['case_list']

        self.executor = json_obj['executor']


