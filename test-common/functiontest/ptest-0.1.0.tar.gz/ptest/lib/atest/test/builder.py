# -*- coding: utf8 -*-
import sys
import time
from collections import OrderedDict
import logging
import json

import atest.auto as auto
import atest.log as log
import atest.path
import atest.auto
import atest.resource
import atest.last

import atest.test.param
import atest.test.env as env
import atest.test.fixture as fixture
from atest.test.plan import *
from atest.test.build import *
from atest.test.result import *

from atest.exception import ATestException
# TODO reimpl this code as a plugin
#from galaxy.pangu.path import PanguPath

class TestBuilderError(ATestException):
    pass


class BaseTestBuilder:

    def __init__(self):
        self.result = TestResult()

    def _set_last_values(self):
        atest.last.reset()
        atest.last.set('atest_log', self.log_file)
        atest.last.set('test_plan', self.plan.name)
        atest.last.set('test_build', self.build.name)
        atest.last.set('test_build_path', self.path)
    
    def run(self):
        self._set_last_values()

        log.prio("Starting test build %s.%s ..." % (self.plan.name, self.build.name))
        log.prio("with case list:\n%s" % "\n".join(
            [addr for addr, case in self.cases]
        ))
        log.prio("with parameters:\n%s" % "\n".join(
            ["%s = %s" % (k, v) for k, v in self.params.iteritems()]
        ))

        self.result.add_start_time(time.time())
        atest.last.set('test_build_begin_time', 
                       time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))

        runners = OrderedDict() 

        for addr, case in self.cases:
            runner_name = case.runner.__class__.__name__
            if not runner_name in runners:
                case.runner.set_builder(self)
                runners[runner_name] = case.runner
            case.result = self.result.get_case_result_handler(case.addr)
            runners[runner_name].add_case(case)
        
        kb_int_flag = False
        all_finished = False

        while not all_finished: 

            all_finished = True

            for name, runner in runners.iteritems():
                if kb_int_flag:
                    # canceling all test cases
                    runner.cancel_all()
                    continue

                try:
                    runner.run()
                except KeyboardInterrupt:
                    kb_int_flag = True

                if not runner.finished:
                    all_finished = False

            fixture.rotate_scope()

        atest.resource.destroy_all()
        atest.auto.kill_daemons()
        self.result.add_stop_time(time.time())
        atest.last.set('test_build_end_time', 
                       time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
        self.result.add_params(atest.test.param._params)
        self.result.store()
        return self.result


class BaseLocalTestBuilder(BaseTestBuilder):

    def __init__(self, build, result_cls):
        BaseTestBuilder.__init__(self)
        self.build = build 
        self.plan = self.build.plan

        self._init_path()
        self._init_link()
        self._init_logger()
        self._set_params() # from command line

        self.result = result_cls(self.path)
        self.result.set_plan(self.plan)
        self.result.set_build(self.build)

        self.params = self.build.get_params()
        self._set_params() # from build file
        self.build.load()

        self.cases = self.build.get_cases()
        self.params = self.build.get_params()
        self._set_params() # from build loading
        self._init_test_env()
        
    def _set_params(self):
        for k, v in self.params.iteritems():
            atest.test.param.append(k, v)

    def _init_logger(self):
        self.log_file = self.path / 'atest.log'
        log.root.addHandler(log.StandardFileLogHandler(self.log_file, level=logging.INFO))
        self.log_file_detailed = self.path / 'atest.log.detailed'
        log.root.addHandler(log.StandardFileLogHandler(self.log_file_detailed, level=logging.TRACE))

    def _init_test_env(self):
        env.build_path = self.path
        env.result = self.result
        env.build = self.build
        env.plan = self.plan

    def _init_path(self):
        self.build_path = atest.path.home_path() / "builds"
        self.path = self.build_path / self.build.plan.name / self.build.name
        self.path.mkdir()

    def _init_link(self):
        # create symbol link
        auto.run("rm -f %s/last_build" % self.build_path)
        auto.run("ln -sf '%s' '%s/last_build'" % (self.path.abspath(), self.build_path))
        auto.run("rm -f %s/atest.log" % atest.path.home_path())
        auto.run("ln -sf %s/last_build/atest.log %s/atest.log" % 
                 (self.build_path, atest.path.home_path()))


class LocalTestBuilder(BaseLocalTestBuilder):

    def __init__(self, local_path, case_list=None, params={}):
        self.params = params
        build = LocalTestBuild(local_path, case_list=case_list, params=params)
        BaseLocalTestBuilder.__init__(self, build, LocalTestResult)


class LocalPlannedTestBuilder(LocalTestBuilder):

    def __init__(self, build_file):
        self.params = {}
        self.build_file = build_file
        self.build = LocalPlannedTestBuild(build_file)
        BaseLocalTestBuilder.__init__(self, self.build, LocalPlannedTestResult)


class LocalThreadedTestBuilder(LocalPlannedTestBuilder):

    def __init__(self, build_file):
        self.params = {}
        self.build = LocalThreadedTestBuild(build_file)
        BaseLocalTestBuilder.__init__(self, self.build, LocalPlannedTestResult)
        for thread in self.build.threads:
            thread_id = thread['thread_id']
            thread_path = self.path / ('T%d' % thread_id)
            thread_build_file = thread_path / 'build.json'

            # generate test build file
            thread.update({
                'parent_path' : self.path,
                'thread_path' : thread_path,
                'thread_build_file' : thread_build_file,
            })
            
            thread_build_file.write(json.dumps(thread, indent=4))

    def run(self):
        builds = []
        self.result.add_start_time(time.time())

        log.prio("Starting test threads ...")

        atest_bin_path = sys.argv[0]

        for thread in self.build.threads:
            thread_build_file = Path(thread['thread_build_file'])
            daemon = auto.daemon(
                'nohup %s rtp -E %s' 
                % (atest_bin_path, thread_build_file),
                raise_on_failure=False,
            )
            builds.append(daemon)

        log.prio("Waiting for test threads to finish ...")

        for build in builds:
            build.wait()

        log.prio("All threads finished, merging test results ...")

        for thread in self.build.threads:
            thread_path = Path(thread['thread_path'])
            result_file = thread_path / 'result.json'
            if result_file.isfile():
                self.result.merge_by_file(result_file)
            else:
                log.warn("Result file %s not found. Test thread failed." % result_file)

        self.result.add_stop_time(time.time())
        self.result.store()
        return self.result


class SubLocalThreadedTestBuilder(LocalPlannedTestBuilder):

    def _init_link(self):
        # do not create any links
        pass

    def _init_path(self):
        self.path = Path(json.loads(self.build_file.read())['thread_path'])

def generate_builder_by_local_build_file(test_build_file):

    if not test_build_file.isfile():
        raise TestBuilderError("Test build file %s doesn't exist.", test_build_file)
    try:
        build_obj = json.loads(test_build_file.read())
    except ValueError as e:
        raise TestBuilderError(
            "Failed to read test build file %s: %s"
            % (test_build_file, e)
        )

    if 'type' not in build_obj:
        build_type = 'local'
    else:
        build_type = build_obj['type']

    if build_type == 'local':
        builder = LocalPlannedTestBuilder(test_build_file)
    elif build_type == 'threaded':
        builder = LocalThreadedTestBuilder(test_build_file)
    elif build_type == 'sub_threaded':
        builder = SubLocalThreadedTestBuilder(test_build_file)
    else:
        raise TestBuilderError(
            "Unexpected test build type %s in test build file %s."
            % (build_type, test_build_file)
        )

    return builder

