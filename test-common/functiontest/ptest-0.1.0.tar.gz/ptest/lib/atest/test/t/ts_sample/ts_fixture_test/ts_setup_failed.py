from atest.test.fixture import BaseTestFixture

class MyFixture(BaseTestFixture):

    def setup(self):
        
        raise Exception("Setup failed.")

def tc_hello(tc):
    pass
