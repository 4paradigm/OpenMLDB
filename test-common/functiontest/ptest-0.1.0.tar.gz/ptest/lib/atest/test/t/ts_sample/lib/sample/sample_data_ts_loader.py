# -*- coding: utf8 -*-
import re

import atest.log as log
from atest.test.loader import BaseTestSuiteLoader
from atest.test.runner import BaseTestRunner
from atest.test.case import TestCase

class SampleDataTestCase(TestCase):

    def __init__(self, addr, loader, runner, path, args):
        TestCase.__init__(self, addr, loader, runner, path)
        self.args = args


class SampleDataTSRunner(BaseTestRunner):

    def __init__(self):
        BaseTestRunner.__init__(self)

    def run_case(self, case):
        log.info("arg_1=%s, arg_2=%s" % (case.args[0], case.args[1]))


class SampleDataTSLoader(BaseTestSuiteLoader):

    def load(self):

        for line in self.path.readlines():
            match = re.match("(\S+)\s+(\S+)\s+(\S+)", line)
            if match:
                case_name = match.group(1)
                arg_1 = match.group(2)
                arg_2 = match.group(3)
                self.children[case_name] = SampleDataTestCase(
                    self.addr + '.' + case_name,
                    self,
                    self.runner,
                    self.path,
                    [arg_1, arg_2],
                )

