# -*- coding: utf8 -*-
import sys
import atest.log as log
from atest.test.loader import DirTSLoader
from atest.uri import ATestURIContainer
import atest.path

cntr = ATestURIContainer(DirTSLoader(atest.path.Path(sys.argv[1]), uri='galaxy'))

print cntr.get('##tree')
for uri, case in cntr.get('##tree'):
    log.info("Running %s" % case.uri)
    atest.test.path.init_test_env(case.path)
    case.run()
    atest.test.path.destroy_test_env(case.path)
