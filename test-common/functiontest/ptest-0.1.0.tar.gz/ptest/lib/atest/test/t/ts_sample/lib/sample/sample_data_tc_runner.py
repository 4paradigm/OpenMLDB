# -*- coding: utf8 -*-
import atest.log as log
from atest.test.runner import BaseTestRunner

class SampleDataTCRunner(BaseTestRunner):

    def run_case(self, case):
        log.info("Running data file %s ..." % case.path)
