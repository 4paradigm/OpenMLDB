# -*- coding: utf8 -*-
import sample.sample_lib
import atest.conf as conf
import atest.resource as res

from atest.test.fixture import BaseTestFixture
import atest.test.fixture as fixture

class InsideTestFixture(BaseTestFixture):

    def case_setup(self, case):
        print "inside case setup"

    def case_teardown(self, case):
        print "inside case teardown"


def tc_simple_case_1(tc):
    import sample.sample_lib
    assert conf.get('sample_conf.sample_key') == 'sample_value'
    res.get("sample_res")
    big_fixture = fixture.fixtures['big_fixture']
    print big_fixture.value

def tc_simple_case_2(tc):
    import sample.sample_lib

    pass
