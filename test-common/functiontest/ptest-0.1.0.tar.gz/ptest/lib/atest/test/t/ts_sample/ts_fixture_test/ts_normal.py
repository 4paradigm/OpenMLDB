from atest.test.fixture import StrictTestFixture
import atest.test.param as param

class MyFixture(StrictTestFixture):

    def setup(self):
        pass

    def teardown(self):
        pass

    def case_setup(self, case):
        pass
        print "case setup"

    def case_teardown(self, case):
        pass

def tc_case_1(tc):
    pass

def tc_case_2(tc):
    pass
