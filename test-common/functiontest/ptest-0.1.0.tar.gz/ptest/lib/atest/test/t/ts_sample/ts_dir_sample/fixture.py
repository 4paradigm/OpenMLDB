from atest.test.fixture import BaseTestFixture

class NCVFixture(BaseTestFixture):
    pass
