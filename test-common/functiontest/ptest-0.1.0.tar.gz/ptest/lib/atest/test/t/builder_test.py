# -*- coding: utf8 -*-
import atest.log as log
from atest.test.builder import LocalTestBuilder
import atest.path

ts_sample = atest.path.my_path() / 'ts_sample'

def run_local_build(path):
    log.info("Building test path %s" % path)
    builder = LocalTestBuilder(path)
    result = builder.run()
    return result.json_obj
    

def test_tc_python_file():
    obj = run_local_build(ts_sample / 'tc_python_file_as_tc.py')
    assert obj['results']['sample.python_file_as_tc']['status'] == 'failed'
    assert obj['results']['sample.python_file_as_tc']['failed_reason'] == "AssertionError: This is an expected failure from a python file test case."

def test_tc_python_file_2():
    obj = run_local_build(ts_sample / 'tc_python_file_as_tc')
    assert obj['results']['sample.python_file_as_tc']['status'] == 'failed'
    assert obj['results']['sample.python_file_as_tc']['failed_reason'] == "AssertionError: This is an expected failure from a python file test case."

def test_ts_python_file():
    obj = run_local_build(ts_sample / 'ts_python_file_as_ts.py')
    assert obj['results']['sample.python_file_as_ts.simple_case_1']['status'] == 'passed'
    assert obj['results']['sample.python_file_as_ts.simple_case_2']['status'] == 'passed'

def test_tc_data_file():
    obj = run_local_build(ts_sample / 'tc_data_file_as_tc')
    assert obj['results']['sample.data_file_as_tc']['status'] == 'passed'

def test_ts_data_file():
    obj = run_local_build(ts_sample / 'ts_data_file_as_ts')
    assert obj['results']['sample.data_file_as_ts.sample_case_1']['status'] == 'passed'
    assert obj['results']['sample.data_file_as_ts.sample_case_2']['status'] == 'passed'

def test_ts_dir_sample():
    obj = run_local_build(ts_sample / 'ts_dir_sample')
    assert obj['results']['sample.dir_sample.dir_2_sample.def_case.hello_world']['status'] == 'passed'
    assert obj['results']['sample.dir_sample.dir_2_sample.def_case.must_be_failed']['status'] == 'failed'
    assert obj['results']['sample.dir_sample.dir_2_sample.def_case.must_be_failed']['failed_reason'] == "NameError: global name 'blah' is not defined"
    assert obj['results']['sample.dir_sample.dir_2_sample.def_case.ncv_online']['status'] == 'passed'

def test_tc_data_dir():
    obj = run_local_build(ts_sample / 'tc_data_dir_as_tc')
    pass

test_tc_python_file()
test_tc_python_file_2()
test_ts_python_file()
test_tc_data_file()
test_ts_data_file()
test_ts_dir_sample()
test_tc_data_dir()
