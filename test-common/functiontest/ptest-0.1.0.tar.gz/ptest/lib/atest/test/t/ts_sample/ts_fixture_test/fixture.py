from atest.test.fixture import BaseTestFixture

class TopFixture(BaseTestFixture):
    pass
