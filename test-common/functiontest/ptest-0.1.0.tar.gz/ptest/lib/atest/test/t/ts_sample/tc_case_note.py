import atest.test.env as env

case = env.case
case.result.add_case_note("sample case note line 1")
case.result.add_case_note("sample case note line 2")
