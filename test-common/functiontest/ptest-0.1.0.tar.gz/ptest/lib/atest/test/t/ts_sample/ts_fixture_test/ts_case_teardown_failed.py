from atest.test.fixture import BaseTestFixture

class MyFixture(BaseTestFixture):

    def case_teardown(self, case):
        
        raise Exception("case teardown failed.")

def tc_hello(tc):
    pass
