raise Exception("it's a test error across 2 lines ...\n it's the second line")
