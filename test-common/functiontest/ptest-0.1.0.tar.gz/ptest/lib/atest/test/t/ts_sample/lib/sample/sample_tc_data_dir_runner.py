# -*- coding: utf8 -*-
from atest.test.runner import BaseTestRunner

class SampleTCDataDirRunner(BaseTestRunner):

    def run_case(self, case):
        print case.sandbox.local
        print case.sandbox.pangu
        print (case.path / 'input_file').read()
        print (case.path / 'output_file').read()
