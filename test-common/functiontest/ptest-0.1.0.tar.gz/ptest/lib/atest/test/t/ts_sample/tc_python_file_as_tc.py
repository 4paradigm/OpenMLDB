# -*- coding: utf8 -*-
import sample.sample_lib

import atest.resource as res
import atest.conf as conf

from atest.test.env import result

res.get("sample_res")
conf.get("sample_conf.sample_key")

#result.add_note("this is a sample note")
#result.add_note("this is a sample note 2\nblah")

assert False, "This is an expected failure from a python file test case."

