from atest.test.fixture import StrictTestFixture


class MyFixture(StrictTestFixture):

    def setup(self):

        print "setup"

    def teardown(self):
        
        print "teardown"

    def case_setup(self, case):
        print "case setup"

    def case_teardown(self, case):
        print "case teardown"
