# -*- coding: utf8 -*-
import atest.log as log
from atest.resource import ATestBaseResource

class SampleResource(ATestBaseResource):

    def __init__(self, addr, conf):
        ATestBaseResource.__init__(self, addr, conf)
        log.info("Input file: %s" % conf['input'])
        log.info("Output file: %s" % conf['output'])

    def build(self):
        log.info("Building sample resource")

    def destroy(self):
        log.info("Destroying sample resource")
