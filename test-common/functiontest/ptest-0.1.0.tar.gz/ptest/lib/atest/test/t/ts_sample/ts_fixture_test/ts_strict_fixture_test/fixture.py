import traceback

from atest.test.fixture import StrictTestFixture

class SubFixture(StrictTestFixture):

    def setup(self):
        pass

    def teardown(self):
        traceback.print_stack()
        raise Exception("Teardown failed")
        
