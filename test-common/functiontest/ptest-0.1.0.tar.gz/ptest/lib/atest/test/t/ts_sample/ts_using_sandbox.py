def tc_print_sandbox(tc):

    print tc.sandbox.local
    print tc.sandbox.pangu
