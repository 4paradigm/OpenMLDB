from atest.test.fixture import BaseTestFixture

class MyFixture(BaseTestFixture):

    def case_setup(self, case):
        
        raise Exception("case setup failed.")

def tc_hello(tc):
    pass
