# -*- coding: utf8 -*-
def sample_lib_func():

    print "sample_lib_func called"
