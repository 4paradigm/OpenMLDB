from atest.test.fixture import BaseTestFixture

class MyFixture(BaseTestFixture):

    def teardown(self):
        
        raise Exception("teardown failed.")

def tc_hello(tc):
    pass
