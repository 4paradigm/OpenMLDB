from atest.test.fixture import StrictTestFixture

class NCVFixture(StrictTestFixture):
    pass
