from atest.test.fixture import StrictTestFixture
import atest.test.param as param
import atest.conf as conf

class MyFixture(StrictTestFixture):

    name = "big_fixture"

    def setup(self):
        self.value = "print this line means fixture names works"
        print "big fixture setup -----------------------"
        print conf.get('sample_conf.sample_key')
        pass

    def teardown(self):
        print "big fixture teardown -----------------------"
        pass

    def case_setup(self, case):
        print "case setup"

    def case_teardown(self, case):
        print "case teardown"
