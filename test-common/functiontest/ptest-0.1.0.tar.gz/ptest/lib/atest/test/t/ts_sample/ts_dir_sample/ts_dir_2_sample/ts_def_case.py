# -*- coding: utf8 -*-
#
# @ts_conf@
# @ts_type classic


import time
import sample.sample_lib
import atest.conf as conf

print "only once"

def tc_hello_world(tc):
    sample.sample_lib.sample_lib_func()

def tc_ncv_online(tc):
    assert conf.get('sample_conf.sample_key') == 'sample_value'

def tc_must_be_failed(tc):
    blah.blah()

