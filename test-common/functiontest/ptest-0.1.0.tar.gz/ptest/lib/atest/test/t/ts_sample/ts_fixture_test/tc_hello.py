from atest.test.fixture import fixtures

get = fixtures['big_fixture']

