# -*- coding: utf8 -*-
import traceback
import time
import logging

import atest.last
import atest.log as log
import atest.resource as res
from atest.resource import ATestResourceError
import atest.test.env as env
import atest.test.fixture as fixture


class BaseTestRunner:

    def __init__(self):
        self.cases = [] 
        self.finished = False
        self.executed = set()  # addr set for executed test cases

    def add_case(self, case):
        self.cases.append(case)

    def set_builder(self, builder):
        self.builder = builder

    def _init_case_logger(self, case, env):
        self._case_log_handlers = []
        for log_name, level in [['case.log', logging.INFO], ['case.log.detailed', logging.TRACE]]:
            log_file = env.build_path / case.addr / log_name
            handler = log.StandardFileLogHandler(log_file, level=level)
            log.root.addHandler(handler)
            self._case_log_handlers.append(handler)

    def _remove_case_logger(self):
        for handler in self._case_log_handlers:
            log.root.removeHandler(handler)

    def _run_one_case(self, case, env):
        self._init_case_logger(case, env)
        log.prio("Running test case %s" % case.addr)
        start_time = time.time()

        try:
            case.loader.fixture.do_case_setup(case)
            self.run_case(case)
            log.info("Test case %s passed." % case.addr)
            end_time = time.time()
            duration = end_time - start_time

            if case.expect_result == 'failed':
                log.warn("Test case %s passed, but we expect it failed." % case.addr)
                case.result.add_case_result(
                    'failed', 
                    duration=duration, reason="This test case passed, but we expected it failed."
                )
            else:
                case.result.add_case_result('passed', duration=duration)

        except KeyboardInterrupt:
            # handling ctrl + c
            log.warn("Test case %s canceled. StackTrace:\n%s" % 
                     (case.addr, traceback.format_exc()))
            case.result.add_case_result('canceled')
            log.warn("<C=y>Please press Ctrl+C again to interrupt the entire build, in 10 seconds</C>")
            try:
                time.sleep(10)
            except KeyboardInterrupt:
                # if the user pressed ctrl + c again in 10 seconds
                log.warn("Canceling all cases ...")
                self.kb_int_flag = True

        except ATestResourceError as e:
            # if any resource is failed to build, mark test case as aborted
            reason = e.__class__.__name__ + ': ' + str(e)
            log.warn("Test case %s aborted." % case.addr)
            end_time = time.time()
            duration = end_time - start_time
            case.result.add_case_result('aborted', reason=reason, duration=duration)

        except Exception as e:
            # if any other exception caught, mark test case as failed
            log.warn("Test case %s failed:\n%s"
                     % (case.addr, traceback.format_exc()))
            reason = e.__class__.__name__ + ': ' + str(e)
            end_time = time.time()
            duration = end_time - start_time

            if case.expect_result == 'failed':
                case.result.add_case_result('passed', duration=duration)
            else:
                case.result.add_case_result('failed', reason=reason, duration=duration)

        finally:

            try:
                case.loader.fixture.do_case_teardown(case)
            except Exception as e:
                log.warn("Test case %s teardown failed:\n%s"
                         % (case.addr, traceback.format_exc()))

        self._remove_case_logger()
    
    def run(self):
        self.kb_int_flag = False

        self.finished = True
        
        for case in self.cases:

            # make sure this case is not executed in the last circle
            if case.addr in self.executed:
                continue

            # make sure this case is in the right fixture scope 
            skip_flag = False
            for scope in fixture.scopes:
                if not case.addr.startswith(scope):
                    # we got one case not in the right scope
                    # we will run it in the next round
                    skip_flag = True
                    self.finished = False
                    break

            if skip_flag:
                continue

            case.result.add_case_result('canceled')
            if self.kb_int_flag:
                continue

            env.tc = case
            env.case = case

            run_case_flag = True

            case.loader.init_test_env()

            try:
                # building test fixture
                res.get("__dynamic__.fixtures." + case.loader.addr)
            except Exception as e:
                reason = e.__class__.__name__ + ':' + str(e)
                log.warn("Test case %s skipped:\n%s" % (case.addr, reason))
                run_case_flag = False
                case.result.add_case_result('aborted', reason=reason)

            if run_case_flag:
                # OK, confirm to run this test case
                case._setup_case_sandbox() 
                self._run_one_case(case, env)

            env.tc = None
            env.case = None
            self.executed.add(case.addr)
            case.loader.destroy_test_env()

        if self.kb_int_flag:
            # continue canceling all the other test cases
            raise KeyboardInterrupt

    def run_case(self, case):
        # to be overwritten in different test runner
        pass

    def cancel_all(self):
        for case in self.cases:
            if case.addr not in self.executed:
                log.warn("Test case %s canceled." % case.addr)
                case.result.add_case_result('canceled')
        self.finished = True

