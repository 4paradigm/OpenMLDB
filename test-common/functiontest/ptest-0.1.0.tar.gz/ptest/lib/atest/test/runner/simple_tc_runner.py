# -*- coding: utf8 -*-
from atest.test.runner import BaseTestRunner

class SimpleTestRunner(BaseTestRunner):

    def run_case(self, case):
        case.run()

