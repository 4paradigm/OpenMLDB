import types

def assertTrue(actual, checkpoint_desc=''):
    if bool(actual) != True:
        expected = "Actual value (%s) should be True."%str(actual)
        raise AssertionError(expected, checkpoint_desc)

def assertFalse(self, actual, checkpoint_desc=''):
    if bool(actual) == True:
        expected = "Actual value (%s) should not be True."%str(actual)
        raise AssertionError(expected, checkpoint_desc)
     
def assertEqual(expected, actual, checkpoint_desc=''):
    expected_type = _getType(expected)
    actual_type   = _getType(actual)
    if expected_type == actual_type:
        if expected_type == 'float':
            _assertEqualDelta(expected, actual)
        else:
            if actual != expected:
                raise AssertionError(expected, actual, checkpoint_desc)
    else:
        raise AssertionError("type (%s) value(%s)"%(expected_type, expected), "type (%s) value(%s)"%(actual_type, actual), checkpoint_desc)

def fail(msg):
    raise AssertionError(msg)


def _getType(variable):
    #return value: eg: 'int', 'str'
    if type(variable) is types.UnicodeType:
        variable = variable.encode('utf-8')
    variable_type = str(type(variable))
    variable_type = variable_type[(variable_type.index("'") + 1) : variable_type.rindex("'")]
    return variable_type

def _assertEqualDelta(left, right, delta=1.1920929e-07, msg=''):
    if left == right:
        return
    dinominator = abs(left) > abs(right) and left or right
    sub = abs(left - right) / dinominator
    if sub > delta:
        expected = """The subtraction between left value (%s) and right value (%s) is greater than delta (%s)""" \
                    %(str(left), str(right), str(delta))
        raise AssertionError(expected, '', msg)

