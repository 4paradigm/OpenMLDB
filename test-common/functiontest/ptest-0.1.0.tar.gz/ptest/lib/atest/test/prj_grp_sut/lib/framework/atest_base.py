# -*- coding: utf8 -*-
import sys
from ConfigParser import SafeConfigParser

import atest.log as log
from atest.path import Path
import atest.conf as conf
import atest.test.param as param
from atest.exception import ATestException

from framework.assertions import AssertionError
from common_utils.small_toolkit import *
import common_utils.log_util as log_util

class ATestBase(AssertionError):

    LOGGER = log_util.LOGGER

    def __init__(self):
        self.currentPath = Path(sys.modules[self.__class__.__module__].__file__).dirname()
        self.port_list = conf.get('atest_profile.global.ports_list')
        #    self.portList = self.parsePorts(self.port_list)
        self.portList = []
        self.testType = None
        AssertionError.__init__(self)

    def _init_port_lists_as_port_list(self):
        out = self.parsePorts(self.port_list)
        if out:
            self.portList = out
            
    def _init_port_list(self):
        out = self.parsePorts(self.port_list)
        if out:
            thread_id = param.get('test_build_thread_id')
            thread_num = param.get('test_build_thread_num')
            if thread_num:
                if len(out) < thread_num:
                    raise ATestException(
                        "Size of ports list %d is smaller than thread number %d"
                        % (len(out), thread_num)
                    )
            if not thread_id:
                thread_id = 0
            self.portList = out[thread_id]
            log.debug("Assign port list for thread %d: %s", thread_id, self.portList)

    def getCurrentPath(self):
        return self.currentPath

    def getPortList(self):
        return self.portList
        
    def getPortsList(self):
        return self._uniq_list(self.port_list.split(","))

    def setPortList(self, portList):
        self.portList = portList

    @classmethod
    def parsePorts(self, portList):
        # bad design, try not to use it

        """portList support the following: 
           1. portM1,portM2,portM3;portN1,portN2,...,portNn
           2. portM1:portMn;portN1:portNn
        """
        ret = []
        try:
            portLists = portList.strip().split(';')
            portLists = [p.strip() for p in portLists if p.strip()]
            for portList in portLists:
                ports = [p.strip() for p in portList.split(':')]
                if len(ports) == 2:
                    start = int(ports[0])
                    end = int(ports[1])
                    if not isValidUserPort(start):
                        raise Exception("port(%d) is not in valid user port range(1025~65534)"%start)
                    if not isValidUserPort(end):
                        raise Exception("port(%d) is not in valid user port range(1025~65534)"%end)
                    if start > end:
                        raise Exception("start port(%d) should be less than end port(%d) in port range"%(start, end))
                    ret.append([str(p) for p in range(start, end+1)])
                else:
                    ports = [p.strip() for p in portList.split(',') if p.strip()]
                    for port in ports:
                        if not isValidUserPort(port):
                            raise Exception("port:%s is not in valid user port range(1025~65534)"%port)
                    ret.append(ports)
            ret = uniqueList(ret, needStrip=False)
        except Exception, e:
            logException(e) 
        return ret

    def get(self, section, key):
        return conf.get('atest_profile.%s.%s' % (section, key))

    def _uniq_list(self, items):
        return list(set([x.strip() for x in items]))

    def getHostsList(self):
        return self._uniq_list(
            conf.get('atest_profile.global.hosts_list').split(',')
        )
        
    def getPortsList(self):
        return self._uniq_list(
            conf.get('atest_profile.global.ports_list').split(',')
        )

    def getOsUser(self):
        return conf.get('atest_profile.global.os_user') 
    
    def getOsPassword(self):
        return conf.get('atest_profile.global.os_pwd')

    def getSvnUser(self):
        return conf.get('user.svn.username')

    def getSvnPassword(self):
        return conf.get('user.svn.password')

    def getMailsList(self):
        # we have built-in report mail
        return []

    def getExtendLib(self):
        # the user don't have to manage extend lib now
        return []

    def setUserConfigFile(self, userConfigFilePath):
        self.userConfigFile = userConfigFilePath
        self.userConfigParser = SafeConfigParser()
        self.userConfigParser.optionxform = str
        self.userConfigParser.read(self.userConfigFile)
        
    def getUserConfValue(self, section, option):
        return self.userConfigParser.get(section, option)

    def getValueInProfile(self, section, option):
        ret = None
        for key in conf.get('##keys'):
            if not key.endswith('_profile'):
                continue
            ret = conf.get('%s.##try.%s.%s' % (key, section, option))
            if ret:
                break
        return ret

