# -*- coding: utf8 -*-
from framework.atest_base import ATestBase

import atest.log as log
from atest.test.fixture import StrictTestFixture
import atest.test.param as param


class CompatTestSuiteFixture(StrictTestFixture):

    # to avoid class method polution
    # use a wrapper fixture class and set 'sut' as a member, not just inherit it

    def __init__(self, addr, sut):
        StrictTestFixture.__init__(self, addr)
        self.sut = sut

    def setup(self):
        # override the base setup

        if param.get('run_suite_setup') != False:
            self.sut.suiteSetup()
        else:
            log.info("Skiping suite setup %s ..." % self.fixture_addr)

    def teardown(self):
        # override the base teardown 

        if param.get('run_suite_teardown') != False:
            self.sut.suiteTeardown()
        else:
            log.info("Skiping suite teardown %s ..." % self.fixture_addr)

    def case_setup(self, case):
        # override the base case setup
        
        if param.get('run_test_case') != False:
            self.sut.caseSetup()
        else:
            log.info("Skiping test case setup %s ..." % case.addr)

    def case_teardown(self, case):
        # override the base case teardown 
        
        if param.get('run_test_case') != False:
            self.sut.caseTeardown()
        else:
            log.info("Skiping test case teardown %s ..." % case.addr)




class TestSuite(ATestBase, StrictTestFixture):

    def __init__(self):
        ATestBase.__init__(self)
        self.suiteName = None
        self.prjFixture = None
        self.grpFixture = None
        
    def _init_fixture(self, addr):
        self._compat_ts_fixture = CompatTestSuiteFixture(addr, self)
        return self._compat_ts_fixture

    def suiteSetup(self):
        pass

    def suiteTeardown(self):
        pass

    def caseSetup(self):
        pass

    def caseTeardown(self):
        pass

    def getGroupName(self):
        return self.groupName

    def getProjectFixture(self):
        return self.prjFixture

    def getGroupFixture(self):
        return self.grpFixture

