import re

import atest.modld
import atest.log as log
import atest.conf as conf
from atest.test.runner import BaseTestRunner
from atest.test.loader import TestLoaderError
from atest.test.loader.ts_dir import DirTSLoader


class PrjGrpLoaderBase(DirTSLoader):

    tag = '<none>'   # project / group
    prefix = '<none>' # prj / grp
    param_list = []
    
    def _load_fixture(self):
        # load test fixture
        self.init_test_env()
        from framework.fixture_base import FixtureBase, FixtureBaseCompatWrapper
       
        fixture_conf = None
        conf_dir = self.path / self.conf['conf_dir']
        if conf_dir.isdir():
            confs = conf_dir.listdir("%s\S*\.conf" % self.prefix)
            if confs:
                fixture_conf = confs[0]


        # find a fixture file
        fixture_files = self.path.listdir(self.prefix + '\S*' + 'fixture\.py')

        if len(fixture_files) > 1:
            fixture_file = fixture_files[0]
            log.warn(
                "More than one fixture file found in %s, using first one %s."
                % (self.path, fixture_file)
            )
        elif len(fixture_files) == 1:
            fixture_file = fixture_files[0]
        else:
            fixture_file = None

        if fixture_file != None:
            fixture_class = atest.modld.load_class_from_source(
                fixture_file, FixtureBase 
            )

            raw_fixture = fixture_class(fixture_conf)

            if self.tag == 'project':
                raw_fixture._init_port_lists_as_port_list()
            elif self.tag == 'group':
                raw_fixture._init_port_list()

            self.fixture = FixtureBaseCompatWrapper(
                self.addr, 
                self.tag, 
                raw_fixture
            )

        else:
            # make a empty fixture
            self.fixture = FixtureBaseCompatWrapper(
                self.addr,
                self.tag,
                FixtureBase(fixture_conf)
            )

        self.destroy_test_env()
            

    def _replace_single_conf_file(self, path):
        target = path.dirname() / ".".join(path.basename().split('.')[:-1])
        log.debug("Replacing config template %s to %s ..." % (path, target))
        content = path.read()

        # find all the profile confs
        profiles = [x for x in conf.get('##keys') if x.endswith('_profile')]

        for profile in profiles:
            for section in conf.get(profile):
                for key in conf.get(profile + '.' + section):
                    value = conf.get(profile + '.' + section + '.' + key)

                    # replace %{key}% -> value
                    content = content.replace('%%{%s}%%' % key, value)

                    # replace %{key[x]}% -> value[x], where x can an index, or an interval
                    self.__value_list = value.split(',')
                    content = re.sub('%%{%s\[(\S+?)\]}%%' % key, self.__list_replace, content)

        match = re.search("%\{(\S+)\}%", content)
        if match:
            raise TestLoaderError(
                "Failed to replace conf template %s, missing key '%s' in atest.profile"
                % (path, match.group(1))
            )
        target.write(content)

    def __list_replace(self, matchobj):
        # this is a workaround to pass value list to the eval func
        value_list = self.__value_list
        ret = eval("value_list[%s]" % matchobj.group(1))
        if isinstance(ret, str) or isinstance(ret, unicode):
            return ret
        return ",".join(ret)

    def _replace_conf_template(self, conf_path):
        if not conf_path.isdir():
            return

        # for each conf dir, replace the *.profile templates first
        for profile_temp in conf_path.treefile():
            if profile_temp.endswith('.profile.template') or profile_temp.endswith('.profile.tpl'):
                self._replace_single_conf_file(profile_temp)

        # apply the conf
        self.init_test_env()

        # replace other templates

        for temp_file in conf_path.treefile():
            if temp_file.endswith('.profile.template') or temp_file.endswith('.profile.tpl'):
                continue
            if temp_file.endswith('.template') or temp_file.endswith('.tpl'):
                self._replace_single_conf_file(temp_file)

    def _load_children(self):
        load_flag = False

        for param in self.param_list:
            if atest.test.param.get(param) != False:
                load_flag = True
                break

        if load_flag:
            # do the real load thing
            DirTSLoader._load_children(self)
        else:
            # make a fake case to invoke fixture
            fake_case_name = '__%s_fixture___' % self.tag
            self.runner = BaseTestRunner()
            fake_case = self.generate_test_case(fake_case_name)
            self.children[fake_case_name] = fake_case 

