# -*- coding: utf8 -*-
import sys
import re
import imp
import json
import types
import inspect

import atest.path
import atest.auto as auto
import atest.conf as conf
import atest.log as log
from atest.auto import AutoCmdRetcodeError
from atest.path import Path

from atest.test.fixture import BaseTestFixture
from atest.test.loader import TestLoaderError
from atest.test.runner import BaseTestRunner
from atest.test.prj_grp_sut.loader.prj_grp_base import PrjGrpLoaderBase
import atest.test.param


class PrjTSLoader(PrjGrpLoaderBase):

    compatible_path = (
        atest.path.atest_path() / 
        "lib/atest/test/prj_grp_sut/lib"
    )
    
    param_require = {
        "run_project_setup" : True,
        "run_project_teardown" : True,
    }

    tag = 'project'
    prefix = 'prj_'
    
    # skip load group/suite/case when the user specified not to run them
    param_list = [
        'run_group_setup',
        'run_group_teardown',
        'run_suite_setup',
        'run_suite_teardown',
        'run_test_case',
    ]

    def __init__(self, path, conf, addr):
        conf['lib_dir'] = '.'
        #TODO:zhangf-mod-20170401
        #conf['conf_dir'] = 'prj_conf'

        PrjGrpLoaderBase.__init__(self, path, conf, addr)
        
        # alias simplejson module as json
        # because they don't work together
        sys.modules['simplejson'] = sys.modules['json']

        self._add_site_packages('2.6')
        self._add_site_packages('2.5')
        self._add_site_packages('2.4')
        self._init_log_util()
        self._add_extend_lib()

        self.init_test_env()
        self._replace_conf_template(self.path / 'prj_conf')
        self.destroy_test_env()

    def _add_site_packages(self, version):
        try:
            # <prefix>/bin/python2.x -> <prefix>/lib/python2.x/site-packages
            python_25_path = Path(auto.run('which python%s' % version)[0])
            prefix = python_25_path.dirname().dirname()
            site_packages = prefix / 'lib' / ('python' + version) / 'site-packages'
            if site_packages not in sys.path:
                sys.path.append(site_packages)
        except AutoCmdRetcodeError:
            # no python2.x found
            pass

    def _init_log_util(self):
        if self.compatible_path not in sys.path:
            sys.path.insert(0, self.compatible_path)
        import common_utils.log_util as log_util
        log_util.LOGGER = log.root
        if self.compatible_path in sys.path:
            sys.path.remove(self.compatible_path)

    def _add_extend_lib(self):
        extend_lib = conf.get('atest_profile.extend_lib.extend_lib_path')
        log.info("extend lib = %s", extend_lib)
        if extend_lib != "None":
            for lib in extend_lib.split(':'):
                if lib not in sys.path:
                    sys.path.append(lib)

    def init_test_env(self):
        PrjGrpLoaderBase.init_test_env(self)
        if self.compatible_path not in sys.path:
            sys.path.insert(0, self.compatible_path)

    def destroy_test_env(self):
        if self.compatible_path in sys.path:
            sys.path.remove(self.compatible_path)
        PrjGrpLoaderBase.destroy_test_env(self)

