# -*- coding: utf8 -*-
import traceback

import atest.log as log
import common_utils.log_util as log_util


from framework.fixture_base import FixtureBase

class MyProjectFixture(FixtureBase):

    def __init__(self, conf_file):
        FixtureBase.__init__(self, conf_file)
        log.prio("Init project fixture ...")
        log_util.LOGGER.info("Init project fixture ...")

    def setUp(self):
        log.prio("Setting up project ...")
        log_util.LOGGER.info("Setting up project ...")

    def tearDown(self):
        log.prio("Tearing down project ...")
        log_util.LOGGER.info("Tearing down project ...")
