# -*- coding: utf8 -*-
#project dir structure related
PROJECT_IDENTIFIER = "prj_"
GROUP_IDENTIFIER = "grp_"
SUITE_IDENTIFIER = "sut_"
FIXTURE_IDENTIFIER  = "fixture"
TESTCASE_IDENTIFIER = "test"
CONFFILE_IDENTIFIER = "conf"
LIB_IDENTIFIER = "lib"

#extension lib related
DEFAULT_EXTENDLIB_SYSPATH = '/usr/local/lib/python/site-packages/'

#atest.profile
GLOBAL = "global"
ENABLE_PARALLEL = "enable_parallel"
PORTS_LIST = "ports_list"
PROCESS_NUMBER = "process_number"
PARALLEL_LEVEL = "parallel_level"
ENABLE_RESULT_STORE = 'enable_result_store'
RESULT_STORE_SERVICE_ADDRESS = 'result_store_service_address'
PRJ_RELEASE_VERSION = 'prj_release_version'
ENABLE_PERF_COMPARE = 'enable_perf_compare'
PERF_BASELINE_VERSION = 'perf_baseline_version'
PERF_BASELINE_STARTTIME = 'perf_baseline_starttime'

#parallel running related
GROUP_LEVEL_PARALLEL = "group"
SUITE_LEVEL_PARALLEL = "suite"
DEFAULT_PARALLEL_NUM = 4

#case attr
SHOULD_NOT_PASS = 'ShouldNotPass'

#case info
FUNC_TEST = 'Func'
PERF_TEST = 'Perf'

#result store related
RESULT_PASS = 'Passed'
RESULT_FAILED = 'Failed'
RESULT_ERROR = 'Error'
