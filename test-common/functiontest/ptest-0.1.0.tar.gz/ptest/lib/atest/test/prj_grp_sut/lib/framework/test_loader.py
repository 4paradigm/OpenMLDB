# -*- coding: utf8 -*-
class TestLoader:

    classCaseDirMap = {}

    @classmethod
    def get_classCaseDirMap(cls):
        return cls.classCaseDirMap
