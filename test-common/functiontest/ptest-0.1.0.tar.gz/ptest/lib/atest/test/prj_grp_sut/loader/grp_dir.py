# -*- coding: utf8 -*-
import sys

import atest.path
from atest.test.prj_grp_sut.loader.prj_grp_base import PrjGrpLoaderBase


class GrpTSLoader(PrjGrpLoaderBase):

    compatible_path = (
        atest.path.atest_path() / 
        "lib/atest/test/prj_grp_sut/lib"
    )

    param_require = {
        "run_group_setup" : True,
        "run_group_teardown" : True,
    }

    tag = 'group'
    prefix = 'grp_'
    
    param_list = [
        'run_suite_setup',
        'run_suite_teardown',
        'run_test_case',
    ]

    def __init__(self, path, conf, addr):
        conf['lib_dir'] = '.'
        conf['conf_dir'] = 'grp_conf'
        PrjGrpLoaderBase.__init__(self, path, conf, addr)

        self.init_test_env()
        self._replace_conf_template(self.path / 'grp_conf')
        self.destroy_test_env()

    def init_test_env(self):
        PrjGrpLoaderBase.init_test_env(self)
        sys.path.insert(0, self.compatible_path)

    def destroy_test_env(self):
        if self.compatible_path in sys.path:
            sys.path.remove(self.compatible_path)
        PrjGrpLoaderBase.destroy_test_env(self)

