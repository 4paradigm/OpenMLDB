# -*- coding: utf8 -*-
import sys
import re
import imp
import types
import inspect
import traceback

import atest.log as log
import atest.conf as conf
import atest.auto as auto
from atest.auto import AutoCmdRetcodeError
from atest.path import Path
import atest.resource
from atest.resource import ATestBaseResource

import atest.modld
from atest.modld import ModuleLoaderError
import atest.test.param
import atest.test.loader
from atest.test.loader import BaseTestSuiteLoader
from atest.test.loader import TestLoaderError
from atest.test.loader.ts_dir import DirTSLoader
from atest.test.case import TestCase
from atest.test.runner import BaseTestRunner


class SutDefTestCase(TestCase):

    def __init__(self, addr, loader, runner, path, func): 
        TestCase.__init__(self, addr, loader, runner, path)
        self.func = func

    def run(self):
        if atest.test.param.get('run_test_case') != False:
            self.func()


class SutDefTCRunner(BaseTestRunner):

    def run_case(self, case):
        case.run()


class SutTSLoader(BaseTestSuiteLoader):

    _res_cache = {}
    param_require = {
        "run_test_suite_setup" : True,
        "run_test_suite_teardown" : True,
        "run_test_case" : True,
    }

    def load(self):
        self.init_test_env()

        from framework.test_suite import TestSuite

        self.module = imp.load_source(self.module_name, self.path)
        sys.modules[self.module_name] = self.module

        # call the import here to make sure the module name is the same
        cls = atest.modld.load_class(self.module_name, TestSuite)

        # add this to framework.test_loader to mimic
        # it must be done before suite init
        from framework.test_loader import TestLoader
        TestLoader.classCaseDirMap[cls] = str(self.path.dirname())

        self.sut = cls()
        self.sut.suiteName = 'sut_' + self.name
        self.sut._init_port_list()

        # TestSuite is a sub class of BaseTestFixture
        self.fixture = self.sut._init_fixture(self.addr)

        self._init_compatible()
        self.destroy_test_env()
        
        for name, func in inspect.getmembers(self.sut):
            tc_name = None
            if name.startswith("test_") and type(func) == types.MethodType:
                tc_name = name[5:]

            elif name.startswith("test") and type(func) == types.MethodType:
                tc_name = name[4:]

            if tc_name:
                self.children[tc_name] = SutDefTestCase(
                    self.addr + "." + tc_name,
                    self,
                    SutDefTCRunner(),
                    self.path,
                    func,
                )

                if tc_name.endswith("_shouldNotPass"):
                    self.children[tc_name].expect_result = 'failed'


    def _init_compatible(self):
        
        groupName = self.path.dirname().basename()

        # set project fixture to group fixture
        grp_loader = self.parent
        prj_loader = self.parent.parent

        grp_loader.fixture.raw_fixture.projectFixture = prj_loader.fixture.raw_fixture
        self.sut.groupName = groupName
        self.sut.prjFixture = prj_loader.fixture.raw_fixture
        self.sut.grpFixture = grp_loader.fixture.raw_fixture


