# -*- coding: utf8 -*-
import sys
import traceback

import atest.log as log
import common_utils.log_util as log_util

# test code to import atest_lib
import galaxy.genconf

from framework.test_suite import TestSuite

import prj_lib.sample_lib

import atest.test.env as env

class SampleTestSuite(TestSuite):

    def __init__(self):
        TestSuite.__init__(self)
        log.prio("Suite init ...")

    def suiteSetup(self):
        log.prio("Suite setup ...")

    def suiteTeardown(self):

        log.prio("Suite teardown")

    def caseSetup(self):
        log.prio("Case setup ...")

    def caseTeardown(self):
        print "asdfajsdlfajskldjf------------------------------------------------------------------"
        log.prio("Case teardown ..")

    def test_hello_world(self):
        log_util.LOGGER.info("hello")
        assert True

    def test_hello_world_2(self):
        prj_lib.sample_lib.func()
        assert True

    def test_failed_on_failed_expect_shouldNotPass(self):
        raise Exception("This case should not pass, and it failed")

    def test_pass_on_failed_shouldNotPass(self):
        pass

