# -*- coding: utf8 -*-
from ConfigParser import SafeConfigParser

import atest.log as log
from atest.exception import ATestException
from atest.test.fixture import StrictTestFixture
import atest.test.param as param

from framework.atest_base import ATestBase


class FixtureBaseCompatWrapper(StrictTestFixture):

    # use a wrapper to avoid class member polution
    
    def __init__(self, addr, tag, raw_fixture):
        StrictTestFixture.__init__(self, addr)
        self._tag = tag
        self.raw_fixture = raw_fixture
        
    def setup(self):
        # override the base setup
        if param.get("run_%s_setup" % self._tag) != False:
            self.raw_fixture.setUp()
        else:
            log.info("Skipping %s setup %s ..." % (self._tag, self.fixture_addr))

    def teardown(self):
        # override the base teardown 
        if param.get("run_%s_teardown" % self._tag) != False:
            self.raw_fixture.tearDown()
        else:
            log.info("Skipping %s teardown %s ..." % (self._tag, self.fixture_addr))


class FixtureBase(ATestBase):

    def __init__(self, confFile=None):
        self.confFile = confFile
        if self.confFile:
            self.parser = SafeConfigParser()
            self.parser.optionxform = str
            self.parser.read(self.confFile)
        ATestBase.__init__(self)

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def getConfVal(self, section, key):
        if self.parser:
            return self.parser.get(section, key)
        else:
            raise ATestException('No conf file')


class ProjectFixtureBase(FixtureBase):

    def getProjectConfVal(self, section, key):
        return self.getConfVal(section, key)

    def getProjectPath(self):
        return self.getCurrentPath()


class GroupFixtureBase(FixtureBase):

    def getGroupName(self):
        # groupName will be set
        return self.groupName

    def getGroupConfVal(self, section, key):
        return self.getConfVal(section, key)

    def getProjectFixture(self):
        # projectFixture will be set
        return self.projectFixture

    def getProjectConfVal(self, section, key):
        return self.projectFixture.getProjectConfVal(section, key)

