def func():
    raise Exception("exception from lib")
