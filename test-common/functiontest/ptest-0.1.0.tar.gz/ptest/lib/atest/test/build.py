# -*- coding: utf8 -*-
import time
import json
import socket
import copy

from atest.path import Path
from atest.exception import ATestException
from atest.addr import ATestAddrContainer, ATestAddrError
import atest.test.loader
from atest.test.plan import NoneTestPlan, LocalTestPlan 

class TestBuildError(ATestException):
    pass

class TestBuild:
    pass


class LocalPlannedTestBuild(TestBuild):

    def __init__(self, build_file):
        self.plan = LocalTestPlan(build_file)

        json_obj = json.loads(build_file.read())
        for key in ['params', 'local_path']:
            if not key in json_obj:
                raise TestBuildError(
                    "Test build %s: %s not specified."
                    % (build_file, key)
                )

        self.params = json_obj['params']
        self.local_path = Path(json_obj['local_path']).abspath()

        if 'build_name' in json_obj:
            self.name = json_obj['build_name']
        else:
            self.name = 'tb_'
            self.name += time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
        self.hostname = socket.gethostname()
        self.hostip = socket.gethostbyname(self.hostname)

    def load(self):
        self.cntr, self.prefix = atest.test.loader.load_local_path(self.local_path)

    def get_cases(self):
        ret = []

        for case_addr in self.plan.case_list:
            if case_addr.endswith("*"):
                # to support case list auto expand
                expands = self.cntr.get(case_addr.replace('*', '##tree'))
                for key, case in expands:
                    case = case.get_case()
                    case.build = self
                    case.plan = self.plan
                    ret.append((case.addr, case))
            else:
                case = self.cntr.get(case_addr).get_case()
                case.build = self
                case.plan = self.plan
                ret.append((case_addr, case))
        return ret

    def get_params(self):
        return self.params


class LocalTestBuild(LocalPlannedTestBuild):

    def __init__(self, local_path, case_list=None, params={}):
        self.local_path = local_path
        self.case_list = case_list
        self.plan = NoneTestPlan()
        self.params = params
        path_tag = local_path.basename().split('.')[0]
        self.name = 'tb_' + path_tag + '_'
        self.name += time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))

    def get_cases(self):
        ret = []

        if self.case_list:
            for case_name in self.case_list:
                if not case_name.startswith(self.prefix):
                    case_name = self.prefix + case_name
                try:
                    tc_loader = self.cntr.get(case_name)
                    case = tc_loader.get_case()
                    case.build = self
                    case.plan = self.plan
                    ret.append((tc_loader.addr, case))
                except ATestAddrError:
                    raise TestBuildError("Failed to find test case %s" % case_name)

        else:
            for addr, tc_loader in self.cntr.get("%s##tree" % self.prefix):
                case = tc_loader.get_case()
                case.build = self
                case.plan = self.plan
                display_addr = (self.prefix + addr).rstrip('.')
                ret.append((display_addr, case))
        return ret

    def get_name(self):
        return self.name

    def get_params(self):
        return self.params


class LocalThreadedTestBuild(LocalPlannedTestBuild):

    def __init__(self, build_file):
        LocalPlannedTestBuild.__init__(self, build_file)
        
        json_obj = json.loads(build_file.read())
        if not 'threads' in json_obj:
            raise TestBuildError(
                "Test build %s: threads not specified." % build_file
            )

        threads = json_obj['threads']
        self.threads = []
        self.thread_num = len(threads)

        thread_id = 0
        for thread in threads:

            # init params for each thread 
            params = copy.deepcopy(self.get_params())
            if 'params' in thread:
                params.update(thread['params'])

            params['test_build_thread_id'] = thread_id
            params['test_build_thread_num'] = self.thread_num

            if 'case_list' not in thread:
                thread['case_list'] = []

            # generate thread meta 
            thread = {
                'plan_name' : self.plan.name,
                'people' : self.plan.people,
                'purpose' : self.plan.purpose,
                'case_list' : self.plan.case_list,
                'executor' : self.plan.executor,
                'build_name' : self.name + '_t%d' % thread_id,
                'local_path' : self.local_path,
                'params' : params,
                'case_list' : thread['case_list'],
                'type' : 'sub_threaded',
                'thread_id' : thread_id, 
            }

            self.threads.append(thread)
            thread_id += 1

