# -*- coding: utf8 -*-
import imp

import atest.conf as conf
import atest.modld as modld
import atest.test.env as env
from atest.exception import ATestException

class TestCaseError(ATestException):
    pass

class TestCaseSandbox:

    def __init__(self):
        self.local = None
        self.pangu = None

class TestCase:

    expect_result = 'passed'

    def __init__(self, addr, loader, runner, path):
        self.addr = addr
        self.path = path
        self.runner = runner
        self.loader = loader
        self.sandbox = TestCaseSandbox()

        if self.runner == None:
            raise TestCaseError(
                "Test runner not specified for test case '%s' in %s" 
                % (self.addr, self.path)
            )

    def get_case(self):
        return self

    def run(self):
        pass

    def _setup_case_sandbox(self):

        for var in conf.get("test.sandbox.##keys"):
            flag = conf.get("test.sandbox.%s.##try.active" % var)
            if flag == False:
                continue

            module_name = conf.get("test.sandbox.%s.module" % var)
            func_name = conf.get("test.sandbox.%s.func" % var)
            arg = conf.get("test.sandbox.%s.arg" % var) % {
                "path" : env.build_path / self.addr,
                "plan" : self.plan.name,
                "build" : self.build.name,
                "case" : self.addr,
            }
            func = modld.load_func(module_name, func_name)
            setattr(self.sandbox, var, func(arg))

    def init_test_env(self):
        self.loader.init_test_env()
        self._setup_case_sandbox()

    def destroy_test_env(self):
        self.loader.destroy_test_env()


class SimplePyDefTestCase(TestCase):

    def __init__(self, addr, loader, runner, path, func):
        TestCase.__init__(self, addr, loader, runner, path)
        self.func = func

    def run(self):
        self.func(self)


class SinglePythonTestCase(TestCase):

    def __init__(self, addr, loader, runner, path, module_name):
        TestCase.__init__(self, addr, loader, runner, path)
        self.module_name = module_name

    def run(self):
        self.module = imp.load_source(self.module_name, self.path)


class DirTestCase(TestCase):

    def __init__(self, addr, loader, runner, data_file):
        TestCase.__init__(self, addr, loader, runner, data_file)

class SimpleDataTestCase(TestCase):

    def __init__(self, addr, loader, runner, path, data):
        TestCase.__init__(self, addr, loader, runner, path)
        self.data = data
