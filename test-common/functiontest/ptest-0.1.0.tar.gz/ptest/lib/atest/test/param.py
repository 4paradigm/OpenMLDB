# -*- coding: utf8 -*-
_params = {}

def get(key):

    if key not in _params:
        return None
    return _params[key]


def set(params):

    for k, v in params.iteritems():
        if v == 'true' or v == 'True':
            v = True
        if v == 'false' or v == 'False':
            v = False
        append(k, v)


def append(key, value):
    global _params
    _params[key] = value
