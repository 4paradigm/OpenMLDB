# -*- coding: utf8 -*-
import re
import time
import json
import httplib
import urllib
import urllib2
from collections import OrderedDict

import atest.last
import atest.log as log
import atest.conf as conf
import atest.auto as auto
from atest.exception import ATestException
import atest.test.param
import framework.result_store.testresult_pb2 as proto

class TestResultError(ATestException):
    pass


class TestResult:
    status_list = ['passed', 'failed', 'aborted', 'canceled']


class LocalTestResult(TestResult):

    def __init__(self, store_path):
        self.result_file = store_path / 'result.json'
        self.results = OrderedDict()
        self.params = OrderedDict()
        self.notes = []

    def set_plan(self, plan):
        self.plan = plan

    def set_build(self, build):
        self.build = build

    def read_json(self, result_json_file):
        self.json_obj = json.loads(
            self.result_file.read(), 
            encoding=conf.get('user.encoding')
        )

    def add_case_note(self, case_addr, note):
        if not case_addr in self.results:
            self.results[case_addr] = {}
        if not 'note' in self.results[case_addr]:
            self.results[case_addr]['note'] = []
        self.results[case_addr]['note'].append(note)

    def add_case_result(self, case_addr, status, reason=None, duration=None):
        if not status in self.status_list:
            raise TestResultError(
                "Test case %s has an unexpected status %s"
                % (case_addr, status)
            )

        if not case_addr in self.results:
            self.results[case_addr] = {}

        self.results[case_addr]['status'] = status
        if not duration:
            duration = 0
        self.results[case_addr]['duration'] = duration

        if status == 'failed' or status == 'aborted':
            self.results[case_addr]['reason'] = str(reason)

    append = add_case_result

    def get_case_result_handler(self, case_addr):
        return TestCaseResult(case_addr, self)

    def add_note(self, note):
        self.notes.append(note)

    def add_start_time(self, start_time):
        self.start_time = start_time

    def add_stop_time(self, stop_time):
        self.stop_time = stop_time

    def add_params(self, params):
        self.params.update(params)

    def _gen_local_info(self):
        json_obj = {
            'build_name' : self.build.name,
            'local_path' : self.build.local_path,
            'start_time' : self.start_time,
            'stop_time' : self.stop_time,
            'param' : self.params,
            'results' : self.results,
            'plan_name' : self.plan.name,
            'note' : self.notes,
        }
        return json_obj

    def _gen_statics(self):
        statics = {
            'passed' : 0,
            'failed' : 0,
            'aborted' : 0,
            'canceled' : 0,
        }

        for case_addr, case_result in self.results.iteritems():
            status = case_result['status']
            statics[status] += 1

        return statics

    def _gen_status(self, statics):
        status = "passed"
        if statics['failed'] != 0:
            status = "failed"
        elif statics['aborted'] != 0:
            status = "aborted"
        elif statics['canceled'] != 0:
            status = "canceled"

        return status

    def _write_result_json(self, json_obj):
        json_str = json.dumps(json_obj, indent=4, 
                              encoding=conf.get('user.encoding'))
        self.result_file.write(json_str)
    
    def store(self):
        json_obj = self._gen_local_info()
        json_obj['type'] = 'local'
        json_obj['statics'] = self._gen_statics()
        json_obj['status'] = self._gen_status(json_obj['statics'])
        self._write_result_json(json_obj)
        self.json_obj = json_obj

        self.status = json_obj['status']

    def get_obj(self):
        return self.json_obj

    def _gen_build_str(self, result):
        return "<C=y^20>Test Build</C>%s\n" % result['build_name']

    def _gen_local_path_str(self, result):
        return "<C=y^20>Local Path</C>%s\n" % result['local_path']

    def _gen_time_str(self, result):
        ret = ""
        def time2str(timestamp):
            return time.strftime(
                "%Y-%m-%d %H:%M:%S", time.localtime(timestamp)
            )
        ret += "<C=y^20>Start Time</C>"
        ret += time2str(result['start_time']) + "\n"
        ret += "<C=y^20>Stop Time</C>"
        ret += time2str(result['stop_time']) + "\n"
        ret += "<C=y^20>Duration</C>"
        ret += "%.3f" % (result['stop_time'] - result['start_time']) + " seconds\n"
        return ret

    def _gen_param_str(self, result):
        param = result['param']
        ret = "<C=y>Test Parameters</C>\n"
        for k, v in param.iteritems():
            ret += "<C=*4^14>%s</C>  %s\n" % (k, v)
        return ret

    def _gen_static_str(self, result):
        statics = result['statics']
        ret = "<C=y>Statistics</C>\n<C=*4/>"
        ret += "<C=g>P</C>assed=%d " % statics['passed']
        ret += "<C=r>F</C>ailed=%d " % statics['failed']
        ret += "<C=y>C</C>anceled=%d " % statics['canceled']
        ret += "<C=y>A</C>borted=%d " % statics['aborted']
        ret += "\n"
        return ret

    def _gen_results_str(self, result):
        ret = "<C=y>Results</C>\n"
        results = result['results']
        case_list = sorted(results.keys())
        for case in case_list:
            case_data = results[case]
            ret += "<C=*4/>"
            status = case_data['status']
            if status == "passed":
                ret += "<C=g>P</C>"
            elif status == "failed":
                ret += "<C=r>F</C>"
            elif status == "canceled":
                ret += "<C=y>C</C>"
            elif status == "aborted":
                ret += "<C=y>A</C>"

            ret += " <C=g$10>%.3fs</C>" % case_data['duration']
            ret += " <C=g>%s</C>\n" % case

            if status == "failed" or status == 'aborted':
                # BUG 217303
                # it must be removed when the bug fixed
                # ret += "<C=*6y>%s</C>\n" % case_data['reason']
                ret += "".join(["<C=*17y>%s</C>\n" % line for line in case_data['reason'].split('\n')])
        return ret

    def _gen_note_str(self, result):
        if not result['note']:
            return ""

        ret = "<C=y>Note</C>\n"
        for note in result['note']:
            for split in note.split('\n'):
                ret += "<C=*4c>%s</C>\n" % split

        return ret

    def print_terminal(self):
        result = self.json_obj
        ret = "Printing test results ...\n"
        ret += self._gen_build_str(result)
        ret += self._gen_local_path_str(result)
        ret += self._gen_time_str(result)
        ret += self._gen_param_str(result)
        ret += self._gen_note_str(result)
        ret += self._gen_results_str(result)
        ret += self._gen_static_str(result)
        log.prio(ret)
       

    def _get_case_svn_info(self):
        svnurl, version = '', ''
        lines = auto.run("svn info %s" % self.json_obj["local_path"])
        for item in lines:
            if item and re.search('^URL:', item):
                svnurl = item[len('URL:'):].strip()
            elif item and re.search("^Revision:", item):
                version = item[len('Revision:'):].strip()
            else:
                continue
        return svnurl, version

    def send_areport(self):
        if self.json_obj['plan_name'] == 'no_plan':
            log.info('The plan name is: no_plan, the result will not send to areport server')
            return
        try:
            areport_addr = conf.get('atest_profile.global.result_store_service_address')
            ip, port = areport_addr.split(":")
        except Exception,e:
            log.warn('>_< There is no areport server ip and port info, please add...')
            return
        self._get_case_svn_info()
        log.info('start send result to areport...')       
        self.pb_result = proto.TestResult()
        try:
            #self._add_test_target()
            self._add_test_result_summary()
            self._add_test_case_result()
            serialized_result = self.pb_result.SerializeToString()
        except Exception, e:
            raise Exception(e)
        try:
            #response = urllib.urlopen('http://%s/areport/test_result/' % areport_addr.strip(), serialized_result)
            try_time = 0
            while try_time < 10:
                http_con = httplib.HTTPConnection(areport_addr)
                http_con.request('POST', '/areport/save_result/', serialized_result)
                response = http_con.getresponse() 
                http_con.close()
                if response == None:
                    try_time += 1
                    continue
                else:
                    log.info(response.read())
                    break 
                
            #log.info(response.read())
            resp = proto.SaveResultResponse()
            resp.ParseFromString(response.read())
        except Exception, e:
            raise Exception(e)

    def _add_test_target(self):
        pb_test_target = self.pb_result.testTarget.add()
        pb_test_target.module = self.json_obj['plan_name']
        if self.json_obj['param'].has_key('svn_url'):
            pb_test_target.moduleSvnURL = self.json_obj['param']['svn_url']
        else:
            pb_test_target.moduleSvnURL = 'Null'
        if self.json_obj['param'].has_key('svn_verion'):        
            pb_test_target.moduleSvnRevision = self.json_obj['param']['svn_verion'] 
        else:
            pb_test_target.moduleSvnRevision = 'Null'
        if self.json_obj['param'].has_key('rpm_url'):
            pb_test_target.moduleSvnURL = self.json_obj['param']['rpm_url']
        else:
            pb_test_target.moduleSvnURL = 'Null'
        if self.json_obj['param'].has_key('rpm_verion'):
            pb_test_target.moduleSvnRevision = self.json_obj['param']['rpm_verion']
        else:
            pb_test_target.moduleSvnRevision = 'Null'

    def _add_test_result_summary(self):
        result_summary = self.pb_result.resultSummary
        result_summary.projectName = self.json_obj['plan_name']
        result_summary.startTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.json_obj['start_time']))
        result_summary.endTime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.json_obj['stop_time']))
        statics = self.json_obj['statics'] 
        total_case = sum(statics.values()) 
        #if sum(statics.values()) == 0:
            #if there is no case runned then don't send report to areport
        #    return 
        result_summary.totalCases = total_case
        result_summary.totalFailed = statics['failed'] + statics['canceled']
        result_summary.totalPassed = statics['passed']
        result_summary.unexpectedFailed = 0
        result_summary.unexpectedPassed = 0
        #To do get svn info 
        result_summary.caseSvnURL, result_summary.caseSvnRevision = self._get_case_svn_info()
        result_summary.majorReleaseVersion = '0.1'
        result_summary.minorReleaseVersion = '1'
        result_summary.clusterEnv = 'None'
        result_summary.hardwareEnv = 'None'
        result_summary.systemEnv = 'None'

    def _add_test_case_result(self):
        # __initPBFuncResultDetails ...
        for key, value in self.json_obj["results"].iteritems():
            result_func_detail = self.pb_result.funcResultDetails.add()
            name_list = key.split('.')
            if value['status'] == 'passed':
                result_func_detail.testResult = 'ep'
            else:
                result_func_detail.testResult = 'uf'
            if value.has_key('reason'):
                result_func_detail.assertionMsg = value['reason']
            pb_testcase_info = result_func_detail.testCaseInfo
            pb_testcase_info.caseName = name_list[-1]
            pb_testcase_info.suiteName = name_list[-1]
            if len(name_list) > 1:
                pb_testcase_info.groupName = name_list[-2]
            if len(name_list) > 2:
                pb_testcase_info.projectName = name_list[-3]
            result_func_detail.caseFile = key
class LocalPlannedTestResult(LocalTestResult):

    def _gen_plan_info(self):
        return {
            'people' : self.plan.people,
            'executor' : self.plan.executor,
            'purpose' : self.plan.purpose,
        }
   
    def store(self):
        json_obj = self._gen_local_info()
        json_obj['type'] = 'local_planned'
        json_obj.update(self._gen_plan_info())
        json_obj['hostname'] = self.build.hostname
        json_obj['hostip'] = self.build.hostip
        json_obj['statics'] = self._gen_statics()
        json_obj['status'] = self._gen_status(json_obj['statics'])
        self._write_result_json(json_obj)
        self.json_obj = json_obj
        self.status = json_obj['status']
                                        
    def _gen_plan_str(self, result):
        return "<C=y^20>Test Plan</C>%s\n" % result['plan_name']

    def _gen_purpose_str(self, result):
        return "<C=y^20>Purpose</C>%s\n" % result['purpose']

    def _gen_people_str(self, result):
        ret = "<C=y>People</C>\n"
        for people in result['people']:
            ret += "<C=*4c>%s</C>\n" % people
        return ret

    def _gen_executor_str(self, result):
        return "<C=y^20>Test Executor</C>%s\n" % result['executor']

    def merge_by_file(self, result_file):
        result_obj = json.loads(
            result_file.read(),
            encoding=conf.get('user.encoding'),
        )
        self.results.update(result_obj['results'])
        self.params.update(result_obj['param'])
        del self.params['test_build_thread_id']

    def print_terminal(self):
        result = self.json_obj
        ret = "Printing test results ...\n"
        ret += self._gen_plan_str(result)
        ret += self._gen_purpose_str(result)
        ret += self._gen_build_str(result)
        ret += self._gen_people_str(result)
        ret += self._gen_executor_str(result)
        ret += self._gen_local_path_str(result)
        ret += self._gen_time_str(result)
        ret += self._gen_param_str(result)
        ret += self._gen_note_str(result)
        ret += self._gen_results_str(result)
        ret += self._gen_static_str(result)

        log.prio(ret)


class TestCaseResult:

    def __init__(self, case_addr, result):
        self.case_addr = case_addr
        self.result = result

    def add_case_note(self, note):
        self.result.add_case_note(self.case_addr, note)

    def add_note(self, note):
        self.result.add_note(self, note)

    def add_case_result(self, status, reason=None, duration=None):
        self.result.add_case_result(self.case_addr, status, 
                                    reason=reason, duration=duration)
