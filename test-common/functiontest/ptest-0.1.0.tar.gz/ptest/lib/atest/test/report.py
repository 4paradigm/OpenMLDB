# -*- coding: utf8 -*-
#! /usr/bin/python

import smtplib
import time

from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import email.utils

import atest.conf as conf
import atest.log as log
import atest.path

class TestReport:
    pass

class HTMLTestReport(TestReport):

    def __init__(self, result):
        obj = result.get_obj()
        self.title = obj['status'].upper() + " [" 
        self.title += obj['plan_name'] + "] " 
        self.title += "ATest Report" 

        self.sender = obj["executor"]
        self.receivers = obj['people']

        if self.sender not in self.receivers:
            self.receivers.append(self.sender)

        self.smtp_server = conf.get("test.report.smtp_server")
        self.html = self._gen_html_content(obj)

    def _read_temp(self, name):
        temp = atest.path.my_path() / 'template' / 'report' / name + '.temp.html'

        return temp.read()

    def _gen_mail_list(self, obj):
        ret = ""
        temp = self._read_temp('mail_list')
        for email in obj['people']:
            ret += temp % {'email' : email}
        return ret

    def _gen_statistics(self, obj):
        statics = obj['statics']
        return ((
            "Passed=%d&nbsp;&nbsp;"
            "Failed=%d&nbsp;&nbsp;"
            "Aborted=%d&nbsp;&nbsp;"
            "Canceled=%d&nbsp;&nbsp;"
        ) % (statics['passed'], statics['failed'], statics['aborted'], statics['canceled']))

    def _gen_test_params(self, obj):
        ret = ""
        temp = self._read_temp('test_param')
        for k, v in obj['param'].iteritems():
            ret += temp % {'key' : k, 'value' : v}
        return ret

    def _gen_test_results(self, obj):
        ret = ""
        passed_temp = self._read_temp('case_passed')
        failed_temp = self._read_temp('case_failed')
        aborted_temp = self._read_temp('case_aborted')
        canceled_temp = self._read_temp('case_canceled')

        for name, data in obj['results'].iteritems():
            status = data['status']
            if status == 'passed':
                ret += passed_temp % {'case_addr' : name, 'duration' : data['duration']}
            elif status == 'canceled':
                ret += canceled_temp % {'case_addr' : name}
            elif status == 'failed':
                ret += failed_temp % {'case_addr' : name, 'reason' : data['reason'], 'duration' : data['duration']}
            elif status == 'aborted':
                ret += aborted_temp % {'case_addr' : name, 'reason' : data['reason'], 'duration' : data['duration']}
                
            if 'note' in data:
                for note_line in data['note']:
                    case_note_temp = self._read_temp('case_note')
                    ret += case_note_temp % {'case_note' : note_line}

        return ret

    def _gen_note_content(self, obj):
        if not obj['note']:
            return ""

        note_temp = self._read_temp('note')
        
        content = ""
        for note in obj['note']:
            for split in note.split('\n'):
                content += split + "<br>"

        return note_temp % {'note_content' : content}

    def _gen_html_content(self, obj):
        
        def time2str(timestamp):
            return time.strftime(
                "%Y-%m-%d %H:%M:%S", time.localtime(timestamp)
            )

        report_dict = {
            'test_project' : 'Search & Ads Dept. Aliyun',
            'test_plan' : obj['plan_name'],
            'test_build' : obj['build_name'],
            'mail_list' : self._gen_mail_list(obj),
            'hostname' : obj['hostname'],
            'hostip' : obj['hostip'],
            'local_path' : obj['local_path'],
            'statistics' : self._gen_statistics(obj),
            'start_time' : time2str(obj['start_time']),
            'stop_time' : time2str(obj['stop_time']),
            'duration' : "%.3f" % (obj['stop_time'] - obj['start_time']),
            'test_params' : self._gen_test_params(obj),
            'test_results' : self._gen_test_results(obj),
            'note' : self._gen_note_content(obj),
        }

        return self._read_temp('test_report') % report_dict

    def send_by_email(self):
        log.info("Sending test report by email ...")
        msg = MIMEMultipart('alternative')
        msg['Subject'] = Header(self.title)
        msg['From'] = self.sender
        msg['To'] = ", ".join(self.receivers)
        msg['Date'] = email.utils.formatdate()
        msg.attach(MIMEText(self.html, 'html', 'utf-8'))
        server = smtplib.SMTP(self.smtp_server)
        server.sendmail(self.sender, self.receivers, msg.as_string())
        server.quit()

    def save_on_file(self, report_file):
        log.info("Saving html test report on file %s", report_file)
        report_file.write(self.html)

