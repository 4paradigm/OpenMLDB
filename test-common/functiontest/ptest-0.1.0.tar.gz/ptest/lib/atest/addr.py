# -*- coding: utf8 -*-
import re
import copy
from atest.exception import ATestException


class ATestAddrError(ATestException):
    pass


class ATestAddrContainer:

    def __init__(self, addr_data, name=None, split_char='.', writable=True):
        self.name = name
        self.addr_data = addr_data
        self.writable = writable
        
        self._method_map = {
            'tree' : self._method_tree,
            'keys' : self._method_keys,
            'values': self._method_values,
            '\tget_by_index': self._method_get_by_index,
            'list': self._method_list,
            'find': self._method_find,
        }
        self.split_char = split_char

    def _method_tree(self, trace, ptr):
        return self._get_addr_list(ptr)

    def _method_keys(self, trace, ptr):
        if not isinstance(ptr, dict):
            raise ATestAddrError("%s is not a dict" % trace)
        return ptr.keys()

    def _method_values(self, trace, ptr):
        if not isinstance(ptr, dict):
            raise ATestAddrError("%s is not a dict" % trace)
        return ptr.values()

    def _method_get_by_index(self, trace, ptr, index):
        if not isinstance(ptr, list):
            raise ATestAddrError("%s is not a list" % trace)
        if index < 0 or index > len(ptr) - 1:
            raise ATestAddrError("%s: Index %d is out of range" % index)
        return ptr[index]

    def _method_list(self, trace, ptr):
        if not isinstance(ptr, list):
            raise ATestAddrError("%s is not a list" % trace)
        return ptr

    def _method_find(self, trace, ptr, key):
        ret = []
        searches = [ptr]
        while searches:
            new_searches = []
            for search in searches:
                if isinstance(search, dict):
                    if key in search:
                        ret.append(search[key])
                    new_searches += search.values()
                if isinstance(search, list):
                    new_searches += search
            searches = new_searches
        return ret

    def _retrieve(self, root, addr_items):
        trace = "<root>"
        try_flag = False
        find_flag = False
        try:

            for key in addr_items:

                if find_flag:
                    return self._method_map['find'](trace, access_ptr, key)


                access_ptr = root
                del root

                match = re.match(r"##(\S+)", key)
                if match:
                    method = match.group(1)
                    index_match = re.match(r"(\d+)", method)
                    if index_match:
                        index = index_match.group(1)
                        root = self._method_map['\tget_by_index'](trace, 
                                                            access_ptr, 
                                                            int(index))
                    elif method == "try":
                        try_flag = True
                        root = access_ptr
                    elif method == "find":
                        find_flag = True
                    elif not method in self._method_map:
                        raise ATestAddrError("%s: '%s' is not a valid method" % 
                                             (trace, method))
                    else:
                        root = self._method_map[method](trace, access_ptr)
                else:
                    if (not isinstance(access_ptr, dict)) and (not isinstance(access_ptr, list)):
                        raise ATestAddrError("%s reaches leaf node" % trace)

                    if not isinstance(access_ptr, dict):
                        raise ATestAddrError("%s: '%s' is not a dict" % 
                                              (trace, key))

                    if not key in access_ptr.keys():
                        raise ATestAddrError("%s has no key '%s'" % (trace, key))
                    root = access_ptr[key]
                
                if trace != "<root>":
                    trace = trace + self.split_char + key
                else:
                    trace = key

            return root

            # skip checking 
            if (not isinstance(root, dict)) and (not isinstance(root, list)):
                return root
            else:
                raise ATestAddrError("%s is not a full path" % trace)

        except ATestAddrError, e:
            if try_flag:
                return None
            else:
                raise e

    def _split(self, addr):
        return addr.split(self.split_char)

    def _join(self, addr_items):
        return self.split_char.join(addr_items)

    def get(self, addr):
        addr_items = self._split(addr)
        ret = None
        try:
            ret = self._retrieve(self.addr_data, addr_items)
        except ATestAddrError, e:
            raise ATestAddrError(
                "Failed to get addr '%s'. Error: %s"
                % (addr, e)
            )
        return ret

    def set(self, addr, value):
        if not self.writable:
            raise ATestAddrError("%s is not a writable container.")

        addr_items = self._split(addr)
        ptr = self.addr_data
        last_key = None

        for key in addr_items:

            match = re.match("^##(\S+)$", key)
            if match:
                method = match.group(1)
                if match == re.match("\d+", method):
                    # TODO implement
                    pass
                else:
                    raise ATestAddrError("Invalid method: %s" % key)
            else:
                if last_key:
                    if not isinstance(ptr[last_key], dict):
                        ptr[last_key] = {}
                    if not key in ptr[last_key]:
                        ptr[last_key][key] = {}
                    ptr = ptr[last_key]
                    last_key = key
                else:
                    if not isinstance(ptr, dict):
                        ptr = {}
                    if not key in ptr:
                        ptr[key] = {}
                    last_key = key

        ptr[last_key] = value

    def _get_addr_list(self, addr_data):
        ret = []
        if not isinstance(addr_data, dict):
            return [(".", addr_data)]

        for k, v in addr_data.iteritems():
            if isinstance(v, dict):
                for ret_key, ret_value in self._get_addr_list(v):
                    ret.append((k + self.split_char + ret_key, ret_value))
            else:
                ret.append((k, v))
        return ret

    def append(self, addr_data):
        if not isinstance(addr_data, dict):
            raise ATestAddrError("Addr data must be a dict.")
        for k, v in self._get_addr_list(addr_data):
            self.set(k, v)

    def clone(self):
        return ATestAddrContainer(
            copy.deepcopy(self.addr_data),
            name=self.name,
            split_char=self.split_char,
            writable=self.writable
        )


def get(addr, data):
    ctnr = ATestAddrContainer(data)
    return ctnr.get(addr)

def set(addr, value, data):
    ctnr = ATestAddrContainer(data)
    ctnr.set(addr, value)
