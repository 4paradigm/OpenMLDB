#
# $$$
# Author:                  Haowei Yao
# Create Time:             Sun Apr  8 16:21:43 CST 2012
# File:                    lib/atest/path/__init__.py
# Module Path:             lib
# Module Name:             atest.path
# $$$
#
# Description:             File path manipulation and useful path functions,
#                          combined with basic file and directory operations.
#

import os
import re
import stat
import shutil
import os.path
import inspect

import atest.log as log
from atest.exception import ATestException
from framework.atest_base import ATestBase

class ATestPathError(ATestException):
    pass


class PathError(ATestPathError):
    pass

class _ATestPathFileObject(file):
    # inherit from python file object
    # Path.open return this object
    # and the user can operate this object just as python file object
    # the only difference: while closing it, a close callback will be called
    # to apply changes to certain path type, such as remote file path

    def __init__(self, filepath, mode, close_callback):
        file.__init__(self, str(filepath), mode)
        self.__close_cb = close_callback
        self.__file_path = filepath
        self.__mode = mode

    def close(self):
        file.close(self)
        self.__close_cb(self.__file_path, self.__mode)


class Path(str):

    def __init__(self, path):
        # TODO remote support
        self._path = os.path.normpath(str(path))
        self._protocol = "file"
        
    def __str__(self):
        # to string
        return self._path

    def __eq__(self, other):
        # overloading: self == other
        return str(self) == str(other)

    def __ne__(self, other):
        # overloading: self != other
        return not self.__eq__(other)

    def __hash__(self):
        # overloading: hash[self]
        return str(self).__hash__()

    def __contains__(self, subpath):
        # overloading: if subpath in self:
        return str(subpath) in self.listdir()

    def __iter__(self):
        # overloading: for x in self:
        return self.listdir().__iter__()

    def __div__(self, other):
        # overloading: self / other
        return self.join(other)

    def __add__(self, other):
        # overloading: self + other
        return self.append(other)
        
    def join(self, other):
        # return an instance of the original class
        return self.__class__(os.path.join(str(self), str(other)))

    def append(self, other):
        # return an instance of the original class
        return self.__class__(str(self) + str(other))

    def isfile(self):
        return os.path.isfile(str(self))

    def isdir(self):
        return os.path.isdir(str(self))

    def isemptydir(self):
        return self.isdir() and len(self.listdir()) == 0

    def islink(self):
        return os.path.islink(str(self))
        
    def exists(self):
        return self.isfile() or self.isdir() or self.islink()

    def _get_size(self):
        return os.path.getsize(str(self))

    def _check_is_file(self, tag):
        if not self.isfile():
            raise PathError("%s: %s is not a file." % (tag, self))

    def size(self):
        self._check_is_file('size')
        return self._get_size()

    def _get_stat(self):
        return os.stat(str(self))

    def _get_ctime(self):
        return self._get_stat()[stat.ST_CTIME]
        
    def ctime(self):
        # create time
        return self._get_ctime()

    def _get_mtime(self):
        return self._get_stat()[stat.ST_MTIME]

    def mtime(self):
        # modify time
        return self._get_mtime()

    def _get_atime(self):
        return self._get_stat()[stat.ST_ATIME]

    def atime(self):
        # access time
        return self._get_atime()

    def _check_oprand(self, src, dest, func):
        if func.startswith('copy'):
            tag = "Copying"
        else:
            tag = "Moving"

        log.trace("%s %s to %s" % (func, src, dest))
        
        if not isinstance(src, Path):
            raise PathError(
                "expect an instance of 'Path', not '%s'"
                % src.__class__.__name__
            )

        if not isinstance(dest, Path):
            raise PathError(
                "expect an instance of 'Path', not '%s'"
                % dest.__class__.__name__
            )
        
        if not src.exists():
            raise PathError("%s: %s does not exists." % (func, src))

        if dest.exists():
            dest.remove()
        dest.dirname().mkdir()

    def basename(self):
        return os.path.basename(str(self))

    def dirname(self):
        # return an instance of the original class
        return self.__class__(os.path.dirname(str(self)))

    def abspath(self):
        # return an instance of the original class
        return self.__class__(os.path.abspath(str(self)))

    def realpath(self):
        # return an instance of the original class
        return self.__class__(os.path.realpath(str(self)))
    
    def relpath(self, start=None):
        if start:
            return os.path.relpath(str(self), start)
        else:
            return os.path.relpath(str(self))

    def move_to(self, dest, _out=True):
        if _out:
            self._check_oprand(self, dest, 'move_to')

        if dest._protocol == 'file':
            shutil.move(str(self), str(dest))
        else:
            # make the other module to handle it
            dest.move_from(self, _out=False)

    def move_from(self, src, _out=True):
        if _out:
            self._check_oprand(src, self, 'move_from')
        src.move_to(self, _out=False)

    def copy_to(self, dest, _out=True):
        if _out:
            self._check_oprand(self, dest, 'copy_to')
        if dest._protocol == 'file':
            if self.isfile() or self.islink():
                # use copy2 to make sure file stat is copied as well
                shutil.copy2(str(self), str(dest))
            elif self.isdir():
                shutil.copytree(str(self), str(dest), ignore=shutil.ignore_patterns('.svn'))
        else:
            # make the other module to handle it
            dest.copy_from(self, _out=False)

    def copy_from(self, src, _out=True):
        if _out:
            self._check_oprand(src, self, 'copy_from')
        src.copy_to(self, _out=False)

    def _rm_file(self):
        os.remove(str(self))

    def _rm_dir(self):
        shutil.rmtree(str(self))
                           
    def remove(self, force=True, dir=True, _out=True):
        if _out:
            log.trace("Removing %s force=%s dir=%s" % (self, force, dir))

        # cache the results here
        isdir = self.isdir()
        isfile = self.isfile()
        islink = self.islink()
        exists = isdir or isfile or islink

        if not force and not exists:
            raise PathError("remove: %s not exist." % self)
        
        if not dir and isdir:
            raise PathError("remove: %s is a directory." % self)

        if isfile or islink:
            self._rm_file()
        elif isdir:
            self._rm_dir()
        # if none of these above? it's not existing, handled before

    def _mkdir(self):
        os.makedirs(str(self))

    def mkdir(self, _out=True):
        if _out:
            log.trace("Making dir %s" % self)
            if self.isfile():
                raise PathError("mkdir: %s is a file." % self)
            if self.isdir():
                return
        self._mkdir()

    def _get_local_file_for_write(self):
        # interface: for other path type: copy self to local
        return self
        
    def _get_local_file_for_read(self):
        # interface: for other path type: copy self to local
        return self

    def _apply_local_file_changes(self, local_file, mode):
        # for other path type: apply the local file changes to self 
        pass

    def _open(self, local_file, mode):
        fobj = _ATestPathFileObject(
            local_file, mode, self._apply_local_file_changes
        )
        return fobj

    def read(self, _out=True):
        if _out:
            log.trace("Reading file: %s" % self)

        self._check_is_file('read')
        local_file = self._get_local_file_for_read()
        fp = self._open(local_file, 'r')
        ret = None
        try:
            # TODO handle big file
            ret = fp.read()
        finally:
            fp.close()
        return ret
      
    def readlines(self, _out=True):
        if _out:
            log.trace("Reading file by lines: %s" % self)
            self._check_is_file('readlines')

        local_file = self._get_local_file_for_read()
        fp = self._open(local_file, 'r')
        ret = None
        try:
            # TODO handle big file
            ret = fp.readlines()
        finally:
            fp.close()
        return ret

    def write(self, content, _out=True):
        if _out:
            log.trace("Writing file: %s" % self)

        if self.isdir():
            raise PathError("write: %s is a directory." % self)
        if not self.dirname().isdir():
            self.dirname().mkdir()

        local_file = self._get_local_file_for_write()
        fp = self._open(local_file, 'w')
        try:
            fp.write(content)
            fp.flush()
        finally:
            fp.close()

    def touch(self, _out=True):
        if _out:
            log.trace("Touching file: %s" % self)
        if not self.exists():
            self.write("", _out=False)

    def _listdir(self):
        return os.listdir(str(self))

    def listdir(self, all=False, *patterns):
        if not self.isdir():
            raise PathError("listdir: %s is not a directory." % self)
        items = self._listdir()
        ret = []

        # workaroud to fix variable argument problem
        # FIXME
        patterns = list(patterns)
        if all != True and all != False:
            patterns.append(all)

        for x in items:
            if not all and x.startswith("."):
                continue

            if patterns:
                matched = False

                for pattern in patterns:

                    if re.match(r"^%s$" % pattern, x):
                        matched = True
                        break

                if matched:
                    ret.append(self / x)
            else:
                ret.append(self / x)

        return ret

    def tree(self, all=False, _filter=None):
        # return a list of all succeeding paths
        ret = []
        search = self.listdir(all=all)

        dirflag = _filter == None or _filter == 'dir'
        fileflag = _filter == None or _filter == 'file'

        while search:
            item = search.pop()
            if not all:
                if str(item.basename()).startswith("."):
                    # It's a hidden file or dir
                    continue

            if item.isdir() and not item.islink():
                if dirflag:
                    ret.append(item)
                search += item.listdir(all=all)
            elif fileflag and item.isfile():
                ret.append(item)

        return ret

    def treefile(self, all=False):
        # pick the files from self.tree()
        return self.tree(all=all, _filter='file')

    def treedir(self, all=False):
        # pick the dirs from self.tree()
        return self.tree(all=all, _filter='dir')


def tmp_path():
    return home_path() / 'tmp'


def my_path():
    return Path(os.path.dirname(os.path.abspath(inspect.stack()[1][1]))).abspath()


def curr_path():
    # the same with my_path
    return Path(os.path.dirname(os.path.abspath(inspect.stack()[1][1]))).abspath()

def curr_log():
    base = ATestBase()
    logsdir = base.get('global', 'logs_path')
    if logsdir == '':
        return os.path.join(curr_path, 'logs')
    else:
        if not os.path.exists(logsdir):
            os.makedirs(logsdir)
        return logsdir


_atest_path = None

def atest_path():
    global _atest_path
    if _atest_path:
        return _atest_path
    else:
        search_path = curr_path()
        while search_path != "/":
            if (search_path / ".atest.anchor").isfile():
                _atest_path = search_path
                return _atest_path
            search_path = search_path.dirname()
        raise ATestPathError("Failed to find atest path.")


_atest_home_path = None

def home_path(_mkdir=True):

    global _atest_home_path
    if _atest_home_path:
        return _atest_home_path

    env_home = 'ATEST_HOME_PATH'
    if env_home not in os.environ:
        home_path = Path(os.path.expanduser("~/atest_home"))
    else:
        home_path = Path(os.environ[env_home])
        if home_path != home_path.abspath():
            raise ATestPathError("ATEST_HOME_PATH='%s' should be an absolute path." % home_path)

    log.debug("ATEST_HOME_PATH %s" % home_path)

    if _mkdir:
        home_path.mkdir()
        (home_path / 'data').mkdir()
        (home_path / 'builds').mkdir()
        (home_path / 'tmp').mkdir()

    _atest_home_path = home_path
    return _atest_home_path


def home_data_path():
    return home_path() / 'data'


def __sandbox(arg):
    ret = Path(arg)
    ret.mkdir()
    return ret

