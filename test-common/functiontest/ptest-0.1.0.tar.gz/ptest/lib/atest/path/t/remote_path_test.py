# -*- coding: utf8 -*-
import time
import traceback

import atest.path
import atest.log as log
from atest.path.remote import RemotePath
from atest.path.t.path_test import *

def new_path(host='localhost'):
    path = RemotePath("%s:/tmp/atest_path_test" % host)
    path.mkdir()
    return path

def test_big_data():
    log.info("Testing big data ...")

    content = "-" * (1024 * 1024 * 1024) # 1G data

    file0 = new_path() / 'file0'
    log.debug("Testing remote write ..")
    file0.write(content)
    log.debug("Testing remote read ..")
    file0.read()

def new_path(host='localhost'):
    path = RemotePath("%s:/tmp/atest_path_test" % host)
    path.mkdir()
    return path

if __name__ == '__main__':

    start_time = time.time()
    test_dir = new_path()
    test_basic_usage(test_dir)
    test_directory_walk(test_dir)
    test_op_overload(test_dir)
    test_prepare(test_dir)
    test_cross_over(
        [
            ('rm0', 'fs'),
            ('fs', 'rm0'),
            ('rm0', 'rm0'),
            ('rm0', 'rm1')
        ],
        {
            "rm0" : new_path(),
            "rm1" : new_path(host='127.0.0.1'),
            "fs" : atest.path.tmp_path() / ("test_dir_%d" % time.time())
        }
    )
    #test_big_data()
    end_time = time.time()
    log.prio("PASSED Duration %.9f" % (end_time - start_time))

