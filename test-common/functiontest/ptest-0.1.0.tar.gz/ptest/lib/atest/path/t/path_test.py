# -*- coding: utf8 -*-
import time
import traceback

import atest.log as log
import atest.path

#log.set_logger(log.ATestLogger(terminal_level='trace'))

def assert_list(list_a, list_b):
    list_a = sorted([str(x) for x in list_a])
    list_b = sorted([str(x) for x in list_b])
    if list_a != list_b:
        log.info("\nlist a =\n%s\nlist b = \n%s\n" % (list_a, list_b))
    assert list_a == list_b

def test_basic_usage(test_dir, time_test=True):
    log.info("Testing basic usages ...")

    tmp_dir = "test_dir_%d" % time.time()
    dir_a = test_dir / tmp_dir

    assert dir_a.isdir() == False
    assert dir_a.isfile() == False
    assert dir_a.exists() == False
    assert dir_a.basename() == tmp_dir
    assert dir_a.dirname() == test_dir

    dir_a.mkdir()

    assert dir_a.isdir() == True
    assert dir_a.isfile() == False
    assert dir_a.exists() == True

    file_a = dir_a / "tmp_file"

    assert file_a.isdir() == False
    assert file_a.isfile() == False
    assert file_a.exists() == False

    file_a.remove()
    file_a.touch()

    assert file_a.isdir() == False
    assert file_a.isfile() == True
    assert file_a.exists() == True
    assert file_a.basename() == "tmp_file"
    assert file_a.dirname() == dir_a
    log.debug('file_a = %s, dir_a = %s' % (file_a, dir_a))
    assert file_a in dir_a
    assert dir_a / "blah" not in dir_a

    start = time.time()
    file_a.write("something")
    end = time.time()

    if time_test:
        assert start - 1 < file_a.atime() < end + 1
        assert start - 1 < file_a.ctime() < end + 1
        assert start - 1 < file_a.mtime() < end + 1
    assert file_a.read() == "something"
    assert file_a.size() == 9

    file_b = dir_a / "tmp_file_2"
    file_b.touch()
    assert_list(dir_a.listdir(), [file_a, file_b])

    file_a.remove()
    
    assert file_a.isdir() == False
    assert file_a.isfile() == False
    assert file_a.exists() == False

    dir_a.remove()

    assert dir_a.isdir() == False
    assert dir_a.isfile() == False
    assert dir_a.exists() == False


def test_directory_walk(test_dir):
    log.info("Testing directory walk ...")

    dir_a = test_dir
    tmp_dir = dir_a / ("test_dir_%d" % time.time())
    (tmp_dir / "dir_1").mkdir()
    (tmp_dir / "dir_2").mkdir()
    (tmp_dir / "dir_2" / "dir_3").mkdir()
    (tmp_dir / "file_1").touch()
    (tmp_dir / "file_2").touch()
    (tmp_dir / "dir_2" / "file_3").touch()
    (tmp_dir / ".hidden_dir").mkdir()
    (tmp_dir / ".hidden_file").touch()
    (tmp_dir / "dir_1" / ".hidden_file").touch()
    (tmp_dir / "dir_1" / ".hidden_dir").mkdir()
    (tmp_dir / "dir_1" / ".hidden_dir" / '.hidden_file').touch()
    (tmp_dir / "dir_1" / ".hidden_dir" / 'file_4').touch()

    assert_list(tmp_dir.listdir(), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "file_1",
        tmp_dir / "file_2"
    ])

    assert_list(tmp_dir.tree(), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "file_1",
        tmp_dir / "file_2",
        tmp_dir / "dir_2" / "dir_3",
        tmp_dir / "dir_2" / "file_3",
    ])
    
    assert_list(tmp_dir.treefile(), [
        tmp_dir / "file_1",
        tmp_dir / "file_2",
        tmp_dir / "dir_2" / "file_3",
    ])

    assert_list(tmp_dir.treedir(), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "dir_2" / "dir_3",
    ])

    # testing hiddeng files
    assert_list(tmp_dir.listdir(all=True), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "file_1",
        tmp_dir / "file_2",
        tmp_dir / ".hidden_dir",
        tmp_dir / ".hidden_file",
    ])

    assert_list(tmp_dir.tree(all=True), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "file_1",
        tmp_dir / "file_2",
        tmp_dir / "dir_2" / "dir_3",
        tmp_dir / "dir_2" / "file_3",
        tmp_dir / ".hidden_dir",
        tmp_dir / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_dir",
        tmp_dir / "dir_1" / ".hidden_dir" / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_dir" / "file_4",
    ])
    
    assert_list(tmp_dir.treefile(all=True), [
        tmp_dir / "file_1",
        tmp_dir / "file_2",
        tmp_dir / "dir_2" / "file_3",
        tmp_dir / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_dir" / ".hidden_file",
        tmp_dir / "dir_1" / ".hidden_dir" / "file_4",

    ])

    assert_list(tmp_dir.treedir(all=True), [
        tmp_dir / "dir_1",
        tmp_dir / "dir_2",
        tmp_dir / "dir_2" / "dir_3",
        tmp_dir / ".hidden_dir",
        tmp_dir / "dir_1" / ".hidden_dir",
    ])
    
    (tmp_dir / "pattern.1").touch()
    (tmp_dir / "pattern.2").mkdir()
    (tmp_dir / "blahpattern.3blah").touch()

    assert_list(tmp_dir.listdir("pattern\.\d"), [
        tmp_dir / "pattern.1",
        tmp_dir / "pattern.2"
    ])
    
    (tmp_dir / "ncv.1").touch()
    (tmp_dir / "ncv.32").mkdir()
    (tmp_dir / "blahncv.12").touch()

    assert_list(tmp_dir.listdir('pattern\.\d', 'ncv\..*'), [
        tmp_dir / "pattern.1",
        tmp_dir / "pattern.2",
        tmp_dir / "ncv.1",
        tmp_dir / "ncv.32",
    ])


def test_op_overload(test_dir):
    log.info("Testing operator overloading ...")

    root = test_dir
    
    # __eq__
    assert root / "ncv" == root / "ncv"
    assert not root / "ncv" != root / "ncv"
    assert root / "blah" != root / "ncv"

    # __hash__
    my_hash = {}
    my_hash[root / "ncv"] = "blah"
    assert my_hash[root / "ncv"] == "blah"
    
    tmp_dir = root / "path_test"/ ("test_dir_%d" % time.time())
    tmp_dir.remove()
    tmp_file = tmp_dir / "tmp_file"

    # __contains__
    tmp_dir.remove()
    tmp_dir.mkdir()
    if tmp_file in tmp_dir:
        assert 0
    tmp_file.touch()
    if tmp_file in tmp_dir:
        pass
    else:
        assert 0

    # __iter__
    for subpath in tmp_dir:
        assert subpath == tmp_file

def test_prepare(test_dir):

    tmp_dir = test_dir / ("test_dir_%d" % time.time())

    file_a = tmp_dir / 'dir_a' / 'file_a'
    file_a.write('blah')
    assert file_a.read() == 'blah'

    file_b = tmp_dir / 'dir_b' / 'file_b'
    file_c = tmp_dir / 'dir_c' / 'file_c'
    file_b.write('blah')
    file_b.move_to(file_c)
    assert file_c.read() == 'blah'

def copy_move_test(prot_a, type_a, prot_b, type_b, test_dirs):
    log.info("Testing %s %s vs %s %s" % (prot_a, type_a, prot_b, type_b))
    def _clean():
        for p in test_dirs.values():
            p.remove()

    def _reset():
        pass

    def _generate(tag, prot, type):
        root = test_dirs[prot]
        path = None
        if type == "dir":
            path = root / "dir_" + tag
            path.mkdir()
            (path / "ncv_" + tag).touch()
        elif type == "edir":
            path = root / "dir_" + tag
            path.mkdir()
        elif type == "file":
            path = root / "file_" + tag
            path.write("ncv_" + tag)
        else:
            path = root / "blah_" + tag
        return path

    def _post_check(path, type, tag):
        if type == "dir":
            assert path.isdir()
            assert path.listdir() == [path / "ncv_" + tag]
        elif type == 'edir':
            assert path.isemptydir()
        elif type == "file":
            assert path.isfile()
            assert path.read() == "ncv_" + tag
        else:
            assert not path.exists()

    # move
    log.debug("moving")
    _clean()
    _reset()
    path_a = _generate('a', prot_a, type_a)
    path_b = _generate('b', prot_b, type_b)
    try:
        path_a.move_to(path_b)
        if type_a == "ne":
            raise Exception("Expect an exception")
    except Exception, e:
        if type_a == "ne":
            pass
        else:
            traceback.print_exc()
            raise e
    if type_a == "ne":
        _post_check(path_a, "ne", 'a')
        _post_check(path_b, type_b, 'b')
    else:
        _post_check(path_a, "ne", 'a')
        _post_check(path_b, type_a, 'a')

    # copy
    log.debug("copying")
    _clean()
    _reset()
    path_a = _generate('a', prot_a, type_a)
    path_b = _generate('b', prot_b, type_b)
    try:
        path_a.copy_to(path_b)
        if type_a == "ne":
            raise Exception("Expect an exception")
    except Exception, e:
        if type_a == "ne":
            pass
        else:
            traceback.print_exc()
            raise e
    if type_a == "ne":
        _post_check(path_a, "ne", 'a')
        _post_check(path_b, type_b, 'b')
    else:
        _post_check(path_a, type_a, 'a')
        _post_check(path_b, type_a, 'a')

    # move back
    log.debug("moving back")
    _clean()
    _reset()
    path_a = _generate('a', prot_a, type_a)
    path_b = _generate('b', prot_b, type_b)
    try:
        path_a.move_from(path_b)
        if type_b == "ne":
            raise Exception("Expect an exception")
    except Exception, e:
        if type_b == "ne":
            pass
        else:
            traceback.print_exc()
            raise e
    if type_b == "ne":
        _post_check(path_a, type_a, 'a')
        _post_check(path_b, 'ne', 'b')
    else:
        _post_check(path_a, type_b, 'b')
        _post_check(path_b, 'ne', 'b')

    # copy back
    log.debug("copying back")
    _clean()
    _reset()
    path_a = _generate('a', prot_a, type_a)
    path_b = _generate('b', prot_b, type_b)
    try:
        path_a.copy_from(path_b)
        if type_b == "ne":
            raise Exception("Expect an exception")
    except Exception, e:
        if type_b == "ne":
            pass
        else:
            traceback.print_exc()
            raise e
    if type_b == "ne":
        _post_check(path_a, type_a, 'a')
        _post_check(path_b, 'ne', 'b')
    else:
        _post_check(path_a, type_b, 'b')
        _post_check(path_b, type_b, 'b')

    _clean()

        
def test_cross_over(protocols, test_dirs):
    log.info("Testing move and copy operations ...")

    start_time = time.time()
    for prot_a, prot_b in protocols:
        for type_a in ('dir', 'file', 'ne', 'edir'):
            for type_b in ('dir', 'file', 'ne', 'edir'):
                copy_move_test(prot_a, type_a, prot_b, type_b, test_dirs)
    end_time = time.time()
    log.prio("Cross over duration %.9f" % (end_time - start_time))


if __name__ == "__main__":
    test_dir = atest.path.tmp_path() / "path_test"
    test_basic_usage(test_dir)
    test_directory_walk(test_dir)
    test_op_overload(test_dir)
    test_prepare(test_dir)
    test_cross_over(
        [('fs', 'fs')],
        {'fs' : test_dir}
    )
    print "PASSED"

