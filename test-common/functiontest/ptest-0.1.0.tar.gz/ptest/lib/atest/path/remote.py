#
# $$$
# Author:                  Haowei Yao
# Create Time:             Thu Aug  9 20:18:35 CST 2012
# File:                    lib/atest/path/remote.py
# Module Path:             lib
# Module Name:             atest.path.remote
# $$$
#
# Description:             Remote file path manipulation
#
import re
import os.path
import socket
from xmlrpclib import Binary

import atest.log as log
import atest.conf as conf
from atest.path import Path, PathError
from atest.agent.client import get_client

class RemotePath(Path):

    default_port = 51352

    def __init__(self, path):

        if isinstance(path, RemotePath):
            self.path = path.path
            self.host = path.host
            self.port = path.port
        else:
            match = re.match("(\S+):(\d+):(.*$)", str(path))
            if match:
                self.host, port, self.path = match.groups()
                self.port = int(port)
            else:
                match = re.match("(\S+):(.*$)", str(path))
                if match:
                    self.host, self.path = match.groups()
                    self.port = 51352
                else:
                    raise PathError("Failed to parse '%s' as a remote path." % path)

        self._proxy = get_client(self.host, port=self.port)

        self._protocol = "remote_file"
        try:
            self.path = self._proxy.os.call("os.path.normpath", self.path)
        except Exception as e:
            if "Connection refused" in str(e):
                raise PathError(
                    "Failed to connect to atest agent at %s."
                    % self.host
                )

        self._oscall = lambda func: self._proxy.os.call(func, self.path)
        self._new = lambda path: self.__class__("%s:%d:%s" % (self.host, self.port, path))

    def __str__(self):
        return self.path

    def append(self, other):
        return RemotePath("%s:%d:%s" % (self.host, self.port, self.path) + str(other))

    def join(self, other):
        return RemotePath("%s:%d:%s" % (
            self.host, 
            self.port,
            os.path.join(self.path, str(other),
        )))
        
    def isfile(self):
        return self._oscall('os.path.isfile')

    def isdir(self):
        return self._oscall('os.path.isdir')

    def islink(self):
        return self._oscall('os.path.islink')
        
    def _get_size(self):
        return self._oscall('os.path.getsize')

    def _get_stat(self):
        return self._proxy.os.stat(self.path)

    def basename(self):
        return self._oscall('os.path.basename')

    def dirname(self):
        return self._new(self._oscall('os.path.dirname'))
        
    def abspath(self):
        return self._new(self._oscall('os.path.abspath'))

    def realpath(self):
        return self._new(self._oscall('os.path.realpath'))
    
    def relpath(self, start=None):
        if start:
            return self._new(
                self._proxy.os.call('os.path.relpath', self.path, start)
            )
        else:
            return self._new(self._oscall('os.path.relpath'))


    def _recursive_copy(self, src, dest, copycb):
        if src.isfile():
            # TODO handle big file
            copycb(src, dest)
        else:
            dest.mkdir()
            for item in src.listdir(all=True):
                base = item.basename()
                self._recursive_copy(item, dest / base, copycb)
 
    def _copy_to_local(self, src, dest):
        dest.write(src.read())
              
    def _copy_to_remote(self, src, dest):
        if dest.host == "localhost":
            # when dest host name is passed to remote, 'localhost' means localhost there
            # don't work
            # so, translate the hostname
            dest_host = socket.gethostname()
        else:
            dest_host = dest.host

        src._proxy.file.copy(
            src.path, 
            dest.path,
            dest_host,
            dest.port
        )

    def move_to(self, dest, _out=True):
        if _out:
            self._check_oprand(self, dest, 'move_to')

        if dest._protocol == 'file':
            self._recursive_copy(self, dest, self._copy_to_local)
            self.remove()

        elif dest._protocol == 'remote_file':
            if dest.host == self.host:
                self._proxy.os.call('shutil.move', self.path, dest.path)
            else:
                self._recursive_copy(self, dest, self._copy_to_remote)
                self.remove()
        else:
            # make the other module to handle it
            dest.move_from(self, _out=False)

    def move_from(self, src, _out=True):
        if _out:
            self._check_oprand(src, self, 'move_from')
        
        if src._protocol == 'file':
            self._recursive_copy(src, self, self._copy_to_local)
            src.remove()
        else:
            src.move_to(self, _out=False)

    def copy_to(self, dest, _out=True):
        if _out:
            self._check_oprand(self, dest, 'copy_to')

        if dest._protocol == 'file':
            self._recursive_copy(self, dest, self._copy_to_local)

        elif dest._protocol == 'remote_file':
            if dest.host == self.host:
                if self.isfile() or self.islink():
                    self._proxy.os.call('shutil.copy2', self.path, dest.path)
                elif self.isdir():
                    self._proxy.os.call('shutil.copytree', self.path, dest.path)
            else:
                self._recursive_copy(self, dest, self._copy_to_remote)
        else:
            # make the other module to handle it
            dest.copy_from(self, _out=False)

    def copy_from(self, src, _out=True):
        if _out:
            self._check_oprand(src, self, 'copy_from')
        
        if src._protocol == 'file':
            self._recursive_copy(src, self, self._copy_to_local)
        else:
            src.copy_to(self, _out=False)
            
    def _rm_file(self):
        self._oscall('os.remove')

    def _rm_dir(self):
        self._oscall('shutil.rmtree')

    def _mkdir(self):
        self._oscall('os.makedirs')

    def read(self, _out=True):
        if _out:
            log.trace("Reading file: %s" % self)
        self._check_is_file('read')
        return self._proxy.file.read(self.path).data

    def readlines(self, _out=True):
        if _out:
            log.trace("Reading file: %s" % self)
        self._check_is_file('read')
        return self.proxy.file.readlines(self.path)

    def write(self, content, _out=True):
        if _out:
            log.trace("Writing file: %s" % self)
            
        if self.isdir():
            raise PathError("write: %s is a directory." % self)
        if not self.dirname().isdir():
            self.dirname().mkdir()

        self._proxy.file.write(self.path, Binary(content))
    
    def _listdir(self):
        return self._oscall('os.listdir')


def remote_home_path(host, _mkdir=True):
    p = RemotePath('%s:/var/atest_home' % host) / conf.get('user.userid')
    if _mkdir:
        p.mkdir()
        (p / 'data').mkdir()
        (p / 'builds').mkdir()
        (p / 'tmp').mkdir()
    return p

def remote_tmp_path(host):
    return remote_home_path(host) / 'tmp'

def remote_home_data_path(host):
    return remote_home_path(host) / 'data'
