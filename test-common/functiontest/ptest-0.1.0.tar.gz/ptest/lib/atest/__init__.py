import sys
sys.dont_write_bytecode = True
__import__('pkg_resources').declare_namespace(__name__)
