import os
import sys
import os.path
import logging
import inspect
import socket

from atest.termcolor import cstring, cprint


# add costom log levels in logging
logging.PRIO = 25
logging.TRACE = 5


logging._levelNames.update({
    'PRIO' :        logging.PRIO,
    'TRACE' :       logging.TRACE,
    'WARN' :        logging.WARN,
    logging.PRIO :  'PRIO',
    logging.TRACE : 'TRACE',
    logging.WARN : 'WARN',
})


# atest logger which allow 'trace' & 'prio' log levels
class ATestLogger(logging.Logger):

    def findCaller(self):
        # override the base class to make sure find caller from this file
        srcfile = os.path.normcase(os.path.abspath(__file__))
        if srcfile.endswith('.pyc') or srcfile.endswith('.pyo'):
            srcfile = srcfile[:-4] + '.py'

        f = logging.currentframe()
        if f is not None:
            f = f.f_back
        rv = "(unknown file)", 0, "(unknown function)"
        while hasattr(f, "f_code"):
            co = f.f_code
            filename = os.path.normcase(os.path.abspath(co.co_filename))
            if filename == srcfile:
                f = f.f_back
                continue
            rv = (co.co_filename, f.f_lineno, co.co_name)
            break
        return rv

    def trace(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.TRACE):
            self._log(logging.TRACE, msg, args, **kwargs)

    def prio(self, msg, *args, **kwargs):
        if self.isEnabledFor(logging.PRIO):
            self._log(logging.PRIO, msg, args, **kwargs)


class BaseATestLogFormatter(logging.Formatter):

    def formatTime(self, record):
        return logging.Formatter.formatTime(
            self,
            record, 
            datefmt="%Y-%m-%d %H:%M:%S"
        )
   

class BaseATestLogHandler(logging.Handler):

    fmt_cls = BaseATestLogFormatter

    def __init__(self, level=None):
        logging.Handler.__init__(self, level=level)
        self.setFormatter(self.fmt_cls())

    def close(self):
        # override to avoid bug in python2.5
        if sys.version_info < (2, 6):
            logging._acquireLock()
            try:    
                if self in logging._handlers:
                    del logging._handlers[self]
            finally:
                logging._releaseLock()
        else:
            logging.Handler.close(self)


class StandardTerminalLogFormatter(BaseATestLogFormatter):

    colors = {
        logging.TRACE : 'c',
        logging.DEBUG : 'b',
        logging.INFO  : 'g',
        logging.PRIO  : 'Gd',
        logging.WARN  : 'Yd',
        logging.ERROR : 'Rd',
    }

    colorful = True
    
    def _get_msg_lines(self, msg, args):
        msg = str(msg)
        if args:
            msg = msg % args

        lines = msg.split("\n")
        for i in range(1, len(lines)):
            lines[i] = "<C=*4c>%s</C>" % lines[i]
        return lines

    def _get_level_str(self, level):
        color = 'g'
        if level in self.colors:
            color = self.colors[level]

        return "<C=^5><C=%s>%s</C></C>" % (
            color, 
            logging._levelNames[level]
        )

    def format(self, record):

        fmt = "<C=g>%s %s %s@%s %s:%d <C=c>%s</C></C> "
        colorful = self.colorful and sys.stdout.isatty() 
        
        # environment variable handling
        if 'ANSI_COLORS_DISABLED' in os.environ:
            if os.environ['ANSI_COLORS_DISABLED'] == '1':
                colorful = False
        
        if 'ATEST_LOG_COLORFUL' in os.environ:
            if os.environ['ATEST_LOG_COLORFUL'] == '0':
                colorful = False

        ret = cstring(fmt % (
            self.formatTime(record),
            self._get_level_str(record.levelno),
            record.name,
            socket.gethostname().rsplit('.')[0],
            record.filename,
            record.lineno,
            record.funcName,
        ), colorful=colorful)

        # to avoid termcolor performance problem, slice msg
        msg_lines = self._get_msg_lines(record.msg, record.args)
        ret += "\n".join([cstring(x, colorful=colorful) for x in msg_lines])
        return ret


class StandardTerminalLogHandler(BaseATestLogHandler, logging.StreamHandler):
    fmt_cls = StandardTerminalLogFormatter

    def __init__(self, level=logging.INFO, stream=sys.stdout):

        if sys.version_info < (2, 6):
            # python 2.5
            logging.StreamHandler.__init__(self, strm=stream)
        elif sys.version_info < (2, 7):
            # python 2.6
            logging.StreamHandler.__init__(self, stream)
        else:
            # python 2.7
            logging.StreamHandler.__init__(self, stream=stream)

        BaseATestLogHandler.__init__(self, level=level)

    def emit(self, record):
        logging.StreamHandler.emit(self, record)
        logging.StreamHandler.flush(self)


class StandardFileLogFormatter(StandardTerminalLogFormatter):
    colorful = False


class StandardFileLogHandler(StandardTerminalLogHandler):

    fmt_cls = StandardFileLogFormatter

    def __init__(self, filename, level=logging.TRACE):
        stream = open(filename, 'a')
        StandardTerminalLogHandler.__init__(self, level=level, stream=stream)


class MuteLogHandler(BaseATestLogHandler):
    
    def emit(self, record):
        pass


root = ATestLogger('ptest')


def _init_root():
    global root

    level = logging.INFO

    if 'ATEST_LOG_LEVEL' in os.environ:
        levelname = os.environ['ATEST_LOG_LEVEL'].upper()
        if levelname in logging._levelNames.keys():
            level = logging._levelNames[levelname]

    handler = StandardTerminalLogHandler(level=level)
    root.addHandler(handler)


_init_root()


def trace(msg, *args, **kwargs):
    root.trace(msg, *args, **kwargs)


def debug(msg, *args, **kwargs):
    root.debug(msg, *args, **kwargs)


def info(msg, *args, **kwargs):
    root.info(msg, *args, **kwargs)


def prio(msg, *args, **kwargs):
    root.prio(msg, *args, **kwargs)


def warn(msg, *args, **kwargs):
    root.warn(msg, *args, **kwargs)


def error(msg, *args, **kwargs):
    root.error(msg, *args, **kwargs)

