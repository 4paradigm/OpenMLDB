# -*- coding: utf8 -*-
import re
import json
from collections import OrderedDict

import atest.log as log
import atest.auto as auto
import atest.conf as conf

import atest.path
from atest.subcmd import SubCmd
from atest.path import Path
from atest.addr import ATestAddrContainer
import atest.test.loader

class NewLocalTestPlan(SubCmd):

    def _get_user_input(self, tmp_file):
        auto.interact("%s %s" % (conf.get('user.editor'), tmp_file))
        ret = []
        for line in tmp_file.readlines():
            if re.match("^\s*#.*$", line):
                continue
            if re.match("^\s*$", line):
                continue
            match = re.match("^\s*(\S+(.*\S+)?)\s*$", line)
            ret.append(match.group(1))
        tmp_file.remove()
        return ret

    def _get_mail_list(self):
        log.info("Fetching mail list ...")
        tmp = atest.path.tmp_path() / 'email.list.' + self.opts.test_plan_name
        tmp.write(
            "\n"
            "\n"
            "# ------------ this line and the blow will be ignored -------------\n"
            "# please put the mail list in the above, one per line\n"
            "# the email report will be sent to this mail list\n"
            "# please quit the editor after you've done\n"
        )
        return self._get_user_input(tmp)

    def _get_case_list(self, case_list):
        log.info("Fetching case list ...")
        tmp = atest.path.tmp_path() / 'case.list.' + self.opts.test_plan_name
        tmp.write((
            "# please edit the case list in the blow.\n"
            "# and quit the editor after you've done\n"
            "# PLUS: you can use '*' to match all the cases in a test suite.\n"
            "# ------------ this line and the above will be ignored -------------\n"
            "\n"
            "%s"
        ) % ("".join([x + "\n" for x in case_list])))
        return self._get_user_input(tmp)
        
    def _get_test_param(self, requires):
        log.info("Fetching test parameters ...")
        tmp = atest.path.tmp_path() / 'param.list.' + self.opts.test_plan_name

        req_str = ""

        for k, v in requires.iteritems():
            req_str += "%s = %s\n" % (k, v)

        tmp_str = "# test parameters\n" + req_str + (
            "\n"
            "\n"
            "# ------------ this line and the blow will be ignored -------------\n"
            "# please input the test parameters in the above, in 'key=value' pairs, one per line\n"
            "# Example: \n"
            "#\n"
            "# key1 = value1\n"
            "# build_mode = svn\n"
            "#\n"
            "# please quit the editor after you've done\n"
            "# this parameter can be achieved by atest.test.param.get(key)\n"
        )
            
        tmp.write(tmp_str)

        lines = self._get_user_input(tmp)

        params = OrderedDict()
        for line in lines:
            match = re.match("^(\S+)\s*=\s*(\S+)$", line)
            if not match:
                log.warn("Invalid test param '%s': not in 'key=value' format.")
                continue
            key = match.group(1)
            value = match.group(2)

            if value == 'true' or value == 'True':
                value = True

            if value == 'false' or value == 'False':
                value = False

            params[key] = value

        return params


    def do(self):
        
        path = self.opts.path
        if not path:
            path = "."
        local_path = Path(path).abspath()
        cases = atest.test.loader.list_local_path(local_path)

        plan_json = OrderedDict()
        plan_json['name'] = self.opts.test_plan_name
        plan_json['purpose'] = "Unknow purpose"
        plan_json['local_path'] = local_path
        plan_json['executor'] = conf.get('user.email')
        plan_json['people'] = self._get_mail_list()
        plan_json['case_list'] = self._get_case_list(cases)
        plan_json['params'] = self._get_test_param(atest.test.loader.param_requires)

        output = self.opts.output
        if not output:
            output = "%s.plan.json" % self.opts.test_plan_name
        output_file = Path(output).abspath()

        log.info("Creating new test plan %s ..." % output_file)
        output_file.write(json.dumps(plan_json, indent=4))


