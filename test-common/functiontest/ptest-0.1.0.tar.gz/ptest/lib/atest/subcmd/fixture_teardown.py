import atest.log as log
from atest.subcmd import SubCmd
from atest.subcmd.run_test_fixture import RunTestFixture

class FixtureTeardown(RunTestFixture):

    def do(self):

        self.opts.recursive = True
        self.opts.setup_only = False
        self.opts.teardown_only = True
        self.opts.force = True
        self.opts.params = []

        RunTestFixture.do(self)

