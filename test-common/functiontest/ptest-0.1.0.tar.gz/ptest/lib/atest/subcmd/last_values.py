import anydbm
from atest.termcolor import cprint

import atest.path
from atest.subcmd import SubCmd

class PrintLastValues(SubCmd):

    def do(self):

        dbfile = atest.path.home_data_path() / 'last.db'
        db = anydbm.open(dbfile, 'c')

        keys = sorted(db.keys())

        if keys:
            max_len = len(max(keys, key=len))

            for key in keys:
                value = db[key]
                cprint("<C=y^%d>%s</C>  <C=c>%s</C>\n" % (max_len, key, value))

