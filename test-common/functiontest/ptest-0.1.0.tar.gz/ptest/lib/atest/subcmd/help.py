# -*- coding: utf8 -*-
import atest.log as log
import atest.subcmd
from atest.subcmd import SubCmd
from atest.conf import get as conf
from atest.termcolor import cprint
import atest.addr

from atest.subcmd import SubCmdError

class SubCmdHelp(SubCmd):

    def _help_subcmd(self):

        subcmd = self.opts.subcmd
        sector = atest.subcmd.find(subcmd)
        cprint("<C=^6><C=c>%s</C>:</C> <C=g>%s</C>\n" % (
            subcmd,
            conf("subcmd.%s.%s.info" % (sector, subcmd))
        ))
        cprint("<C=g>%s</C>\n" % conf("subcmd.%s.%s.help" % (sector, subcmd)))
        subcmd_inst = atest.subcmd.load(sector, subcmd)
        cprint("\n")
        cprint(subcmd_inst.format_help())
        cprint("\n")
        

    def _help_all(self):
        log.debug("Printing help information ...")
        # Print version info
        version = (atest.path.atest_path() / 'VERSION').read().strip()

        cprint(
            "<C=c>%s<C=*4r>%s</C></C>\n" % (
                'ATest', version
            )
        )
        cprint("<C=c>Command Line Interface</C>\n")
        cprint("\n")
        # Print usage
        cprint("Usage: <C=c>atest2 <subcmd> [args...]</C>\n")
        cprint("Please use '<C=c>%s</C>' for usage of subcmd\n"
               % "atest2 help <subcmd>")
        cprint("\n")
        # Print sub commands
        cprint("Sub commands:\n\n")

        for sector in sorted(conf("subcmd.##keys")):
            cprint("<C=*4/>Sector <C=c>%s</C>:\n" % sector)
            for subcmd in sorted(conf("subcmd.%s.##keys" % sector)):
                info = conf("subcmd.%s.%s.info" % (sector, subcmd))
                more = conf("subcmd.%s.%s.help" % (sector, subcmd))
                cprint("<C=*8$5c>%s</C><C=*4^25>%s</C><C=*4g>%s</C>\n" %
                       (subcmd, info, more))
            cprint("\n")

    def do(self):
        if self.opts.subcmd:
            self._help_subcmd()
        else:
            self._help_all()

