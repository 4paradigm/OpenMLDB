import os

import atest.log as log
import atest.auto as auto
import atest.conf as conf
import atest.path

from atest.subcmd import SubCmd
from atest.path.remote import RemotePath

class ReleaseATest(SubCmd):

    def do(self):

        log.info("Releasing ATest svn %s at revision %s ..." % (self.opts.svn, self.opts.rev))

        workspace = atest.path.tmp_path() / 'atest_release_workspace'
        workspace.remove()
        workspace.mkdir()

        revstr = ""
        if self.opts.rev == None:
            pass
        else:
            revstr = " -r" + self.opts.rev

        log.info("Export svn ...")
        auto.run("cd %s; svn export %s %s atest --non-interactive --username=%s --password=%s" % (
            workspace, revstr, self.opts.svn, conf.get('user.svn.username'), conf.get('user.svn.password')
        ))

        version = (workspace / 'atest' / 'VERSION').read().strip()

        log.info("ATest Version = %s" % version)

        log.info("Making tar file ...")
        auto.run("cd %s; cp -r atest atest-%s" % (workspace, version))
        auto.run("cd %s; tar czvf atest-%s.tar.gz atest-%s" % (workspace, version, version))

        log.info("Upload tar file ...")
        tar_file = workspace / ('atest-%s.tar.gz' % version)
        target_file = RemotePath('dev3.dev.sd.aliyun.com:/var/www/html/packages/%s' % tar_file.basename())
        tar_file.copy_to(target_file)

        log.info("Making RPM file ...")
        (workspace / 'rpmbuild').mkdir()
        (workspace / 'rpmbuild' / 'BUILD').mkdir()
        (workspace / 'rpmbuild' / 'RPMS').mkdir()
        (workspace / 'rpmbuild' / 'SRPMS').mkdir()
        (workspace / 'rpmbuild' / 'SOURCES').mkdir()

        # preparing spec file
        spec_file = workspace / 'atest/lib/atest/subcmd/atest.spec'
        spec_file.copy_to(workspace / 'atest.spec')
        spec_file.write(spec_file.read().replace('%(version)s', version))

        tar_file.copy_to(workspace / 'rpmbuild' / 'SOURCES' / tar_file.basename())
        auto.run("cd %s; rpmbuild -ba %s" % (workspace, spec_file))
        rpm_file = workspace / "rpmbuild/RPMS/x86_64/atest-" + version + "-1.0.x86_64.rpm"

        log.info("Upload RPM file ...")
        userid = conf.get('user.userid')
        log.prio("<C=y>Invoking repotool. Please input your domain password for '%s' ...</C>" % userid)
        ret = os.system("repotool upload %s -u %s" % (rpm_file, conf.get('user.userid')))

        assert ret == 0, "repotool failed, unable to upload rpm file."

        log.prio("Release successfully complete!")
        log.prio("Your tar file is: http://dev3.dev.sd.aliyun.com/packages/atest-%s.tar.gz" % version)

