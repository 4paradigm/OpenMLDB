import re
from collections import OrderedDict

from atest.exception import ATestException
import atest.log as log
from atest.log import StandardFileLogHandler
from atest.subcmd import SubCmd
from atest.path import Path
import atest.path
import atest.test.loader
import atest.resource as res

class RunTestFixture(SubCmd):

    def _init_params(self):
        params = OrderedDict()
        if self.opts.params:
            for param_str in self.opts.params:
                match = re.match("(\S+)=(\S+)", param_str)
                if not match:
                    raise ATestException("Invalid test param '%s': not in 'key=value' pattern." % param_str)
                params[match.group(1)] = match.group(2)
        atest.test.param.set(params)

    def _load_fixture(self, path):

        log.prio("Loading test fixture ...")
        
        # FIXME: assume single fixture file ends with 'fixture.py'
        if path.endswith('fixture.py'):
            ts_path = path.dirname()
        else:
            ts_path = path

        (cntr, base_addr) = atest.test.loader.load_local_path(ts_path)
        base_addr = base_addr.rstrip('.')
        ts_loader = cntr.get(base_addr)
        ts_loader.load()
        ts_loader.init_test_env()

        return ts_loader.fixture

    def do(self):

        # option init
        if self.opts.path == None:
            self.opts.path = "."
        self.opts.path = Path(self.opts.path).abspath()
        if self.opts.recursive == None:
            self.opts.recursive = True
        if self.opts.setup_only == None:
            self.opts.setup_only = False
        if self.opts.teardown_only == None:
            self.opts.teardown_only = False

        if self.opts.setup_only and self.opts.teardown_only:
            log.warn("Nothing to do ...")
            return

        # test param init
        self._init_params()

        # find fixture
        fixture = self._load_fixture(Path(self.opts.path))

        # init logger
        log_file = fixture.path / 'fixture.log'
        log.info("log file: %s", log_file)
        log.root.addHandler(StandardFileLogHandler(log_file))

        # apply options 
        if not self.opts.recursive:
            # clean up the dependee, so the fixture has no parent
            fixture.dependees = []
            fixture.dependers = []

        ptr = fixture
        while ptr != None:
            ptr.setup_only = self.opts.setup_only
            ptr.teardown_only = self.opts.teardown_only
            ptr.lazy_mode = not self.opts.force
            ptr = ptr.parent

        # fixture setup & teardown
        fixture.build()
        if self.opts.recursive:
            res.destroy_all()
        else:
            fixture.destroy()
            
