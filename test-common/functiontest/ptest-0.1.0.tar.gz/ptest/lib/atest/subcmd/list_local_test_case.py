# -*- coding: utf8 -*-
import sys
import traceback

from atest.exception import ATestException
import atest.log as log
from atest.subcmd import SubCmd
from atest.path import Path
import atest.test.loader
from atest.addr import ATestAddrContainer
from atest.termcolor import cstring


class ListLocalTestCase(SubCmd):

    def do(self):
        path = "."
        if self.opts.path:
            path = self.opts.path

        local_path = Path(path).abspath()
        cases = atest.test.loader.list_local_path(local_path)
    
        colorful = sys.stdout.isatty()

        print cstring("<C=y>=========== __LIST_OF_TEST_CASES__ ============</C>", colorful=colorful)
        for c in cases:
            print cstring("<C=c>%s</C>" % c, colorful=colorful)

