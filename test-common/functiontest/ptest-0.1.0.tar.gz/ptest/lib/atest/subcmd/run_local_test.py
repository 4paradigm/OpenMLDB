import re
from collections import OrderedDict

from atest.exception import ATestException
import atest.log as log
from atest.subcmd import SubCmd
from atest.path import Path
import atest.test.param
from atest.test.builder import LocalTestBuilder

class RunLocalTest(SubCmd):

    def _get_additional_params(self):
        return OrderedDict()

    def do(self):

        if not self.opts.path:
            path = "."
        else:
            path = self.opts.path

        path = Path(path).abspath()
        if not path.exists():
            raise Exception("Path %s does not exist." % path)

        log.prio("Running local test suite %s ..." % path)

        params = OrderedDict()
        if self.opts.params:
            for param_str in self.opts.params:
                match = re.match("(\S+)=(\S+)", param_str)
                if not match:
                    raise ATestException("Invalid test param '%s': not in 'key=value' pattern." % param_str)
                params[match.group(1)] = match.group(2)

        params.update(self._get_additional_params())

        builder = LocalTestBuilder(path, case_list=self.opts.case_list, params=params)
        result = builder.run()
        result.print_terminal()
        result.send_areport()

        if result.status != 'passed':
            self.retcode = 1
