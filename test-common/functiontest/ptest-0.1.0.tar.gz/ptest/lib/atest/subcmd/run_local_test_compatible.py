# -*- coding: utf8 -*-
import re
from collections import OrderedDict

from atest.exception import ATestException
import atest.log as log
from atest.subcmd.run_local_test import RunLocalTest
from atest.path import Path
from atest.test.builder import LocalTestBuilder

class RunLocalTestCompatible(RunLocalTest):

    def _get_additional_params(self):
        
        params = OrderedDict({
            'run_project_setup' : True,
            'run_project_teardown' : True,
            'run_group_setup' : True,
            'run_group_teardown' : True,
            'run_suite_setup' : True,
            'run_suite_teardown' : True,
            'run_test_case' : True,
        })

        if self.opts.project_setup_flag or self.opts.project_teardown_flag:
            params.update(OrderedDict({
                'run_project_setup' : False,
                'run_project_teardown' : False,
                'run_group_setup' : False,
                'run_group_teardown' : False,
                'run_suite_setup' : False,
                'run_suite_teardown' : False,
                'run_test_case' : False,
            }))

        if self.opts.run_test_flag:
            params.update({
                'run_project_setup' : False,
                'run_project_teardown' : False,
                'run_group_setup' : True,
                'run_group_teardown' : True,
                'run_suite_setup' : True,
                'run_suite_teardown' : True,
                'run_test_case' : True,
            })

        if (self.opts.group_setup_flag or 
            self.opts.group_teardown_flag or
            self.opts.suite_setup_flag or
            self.opts.suite_teardown_flag or
            self.opts.test_case_flag):

            params.update(OrderedDict({
                'run_project_setup' : False,
                'run_project_teardown' : False,
                'run_group_setup' : False,
                'run_group_teardown' : False,
                'run_suite_setup' : False,
                'run_suite_teardown' : False,
                'run_test_case' : False,
            }))


        if self.opts.project_setup_flag:
            params['run_project_setup'] = True

        if self.opts.project_teardown_flag:
            params['run_project_teardown'] = True


        if self.opts.group_setup_flag:
            params['run_group_setup'] = True

        if self.opts.group_teardown_flag:
            params['run_group_teardown'] = True

        if self.opts.suite_setup_flag:
            params['run_suite_setup'] = True

        if self.opts.suite_teardown_flag:
            params['run_suite_teardown'] = True

        if self.opts.test_case_flag:
            params['run_test_case'] = True

        return params

