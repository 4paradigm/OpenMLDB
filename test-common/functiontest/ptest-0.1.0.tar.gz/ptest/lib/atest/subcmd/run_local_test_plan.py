# -*- coding: utf8 -*-
import atest.log as log
from atest.exception import ATestException
from atest.subcmd import SubCmd
from atest.path import Path
import atest.test.builder
from atest.test.report import HTMLTestReport 

class RunLocalTestPlan(SubCmd):

    def do(self):

        plan_file = Path(self.opts.plan_file).abspath()
        if not plan_file.isfile():
            raise ATestException("Test build file %s does not exist." % plan_file)
        log.prio("Running local test plan by file %s ..." % plan_file)

        builder = atest.test.builder.generate_builder_by_local_build_file(plan_file)
        result = builder.run()
        result.print_terminal()
        result.send_areport()

        if self.opts.no_email:
            pass

        else:
            report = HTMLTestReport(result)
            report.send_by_email()

        if self.opts.output_report:
            report = HTMLTestReport(result)
            report.save_on_file(Path(self.opts.output_report).abspath())
            

        if result.status != "passed":
            self.retcode = 1
 
