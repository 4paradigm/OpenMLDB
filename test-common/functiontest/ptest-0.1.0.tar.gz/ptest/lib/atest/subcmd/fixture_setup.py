import atest.log as log
from atest.subcmd import SubCmd
from atest.subcmd.run_test_fixture import RunTestFixture

class FixtureSetup(RunTestFixture):

    def do(self):

        self.opts.recursive = True
        self.opts.setup_only = True
        self.opts.teardown_only = False
        self.opts.force = True
        self.opts.params = []

        RunTestFixture.do(self)

