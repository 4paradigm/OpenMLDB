import json
import urllib2
import socket

import atest.auto as auto
import atest.log as log
import atest.conf as conf
import atest.resource as res
import atest.path

from atest.resource.wget import WgetResource
from atest.subcmd import SubCmd
from atest.path import Path
from atest.exception import ATestException


job_xml_template = """
<?xml version='1.0' encoding='UTF-8'?>
<project>
  <actions/>
  <description>%(description)s</description>
  <keepDependencies>false</keepDependencies>
  <properties/>
  <scm class="hudson.scm.NullSCM"/>
  <assignedNode>%(node)s</assignedNode>
  <canRoam>false</canRoam>
  <disabled>false</disabled>
  <blockBuildWhenDownstreamBuilding>false</blockBuildWhenDownstreamBuilding>
  <blockBuildWhenUpstreamBuilding>false</blockBuildWhenUpstreamBuilding>
  <triggers class="vector">
    %(timer)s
  </triggers>
  <concurrentBuild>false</concurrentBuild>
  <builders>
    <hudson.tasks.Shell>
      <command>%(command)s</command>
    </hudson.tasks.Shell>
  </builders>
  <publishers>
    <htmlpublisher.HtmlPublisher plugin="htmlpublisher@1.2">
      <reportTargets>
        <htmlpublisher.HtmlPublisherTarget>
          <reportName>ATest HTML Report</reportName>
          <reportDir></reportDir>
          <reportFiles>atest2_report.html</reportFiles>
          <keepAll>true</keepAll>
          <wrapperName>htmlpublisher-wrapper.html</wrapperName>
        </htmlpublisher.HtmlPublisherTarget>
      </reportTargets>
    </htmlpublisher.HtmlPublisher>
  </publishers>
  <buildWrappers/>
</project>
"""

timer = """
    <hudson.triggers.TimerTrigger>
      <spec>%(schedule)s</spec>
    </hudson.triggers.TimerTrigger>

"""

class AddLocalTestPlanToJenkins(SubCmd):

    def _jenkins_cmd(self, cmd, stdin=[]):
        return auto.cmd(
            "java -jar %s -s %s %s" % 
            (self.jenkins_cli_tool, self.server_addr, cmd)
        ).run(stdin=stdin)[:-1]

    def _get_job_xml(self, plan_name):
        desc = "ATest Jenkins Job %s" % plan_name

        command = "export ATEST_HOME_PATH=\"%s\"\n" % atest.path.home_path()
        command += "atest2 rtp \"%s\" --no-email --output \"$WORKSPACE/atest2_report.html\"\n" % self.plan_file
        command += "ATEST_BUILD_DIR=`readlink -f \"$ATEST_HOME_PATH/builds/last_build\"`\n"
        command += "ln -sf \"$ATEST_BUILD_DIR\" \"$WORKSPACE/atest_build_dir\"\n"

        if self.opts.no_schedule:
            schedule = ""
        else:
            schedule = timer % {'schedule' : self.opts.schedule}

        return job_xml_template % {
            'description' : desc,
            'command' : command,
            'timer' : schedule,
            'node' : self.node,
        }
    
    def do(self):

        log.prio("Initializing ...")
        # read conf
        if not self.opts.schedule:
            self.opts.schedule = "@midnight"

        self.server_addr = conf.get('jenkins.server_addr')
        self.node = socket.gethostbyname(socket.gethostname())

        # read plan file
        self.plan_file = Path(self.opts.plan_file).abspath()
        try:
            plan_obj = json.loads(self.plan_file.read())
        except ValueError as e:
            raise ValueError(
                "Load plan json file %s failed: %s" % 
                (self.opts.plan_file, str(e))
            )

        if self.opts.view_name:
            view_name = self.opts.view_name
        else:
            view_name = conf.get('jenkins.view')
        plan_name = '[' + view_name + '] ' + plan_obj['name']

        # download jenkins cli tool
        inst = WgetResource('jenkins_cli_tool', conf={
            'url' : self.server_addr + '/jnlpJars/jenkins-cli.jar',
            'download' : False,
        })
        res_addr = res.set_res('jenkins_cli_tool', inst)
        self.jenkins_cli_tool = res.get(res_addr).path / 'jenkins-cli.jar'

        # checking for existing job
        log.prio("Checking for existing jobs ...")
        jobs = self._jenkins_cmd('list-jobs')
        if plan_name in jobs:
            if self.opts.force:
                log.info("Job %s already exists. Trying to delete it.", plan_name)
                self._jenkins_cmd('delete-job "%s"' % plan_name)
            else:
                log.error("Job %s already exists.", plan_name)
                self.retcode = 1
                return

        # composing job configure xml
        log.prio("Configuring job ...")
        xml = self._get_job_xml(plan_name)

        # add job
        log.prio("Creating job ...")
        self._jenkins_cmd('create-job "%s"' % plan_name, stdin=[xml])

        # sucess
        url = "%s/view/%s/job/%s" % (self.server_addr, view_name, plan_name)
        url = url.replace(' ', '%20')
        log.prio("Sucess. Please access the job at %s", url) 

