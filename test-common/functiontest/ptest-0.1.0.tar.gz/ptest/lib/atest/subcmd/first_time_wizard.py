import json
import re

import atest.conf as conf
import atest.log as log
import atest.subcmd
import atest.path
from atest.path import Path
from atest.subcmd import SubCmd
from atest.subcmd import SubCmdError
from atest.termcolor import cprint

class SubCmdFirstTimeWizard(SubCmd):

    def _get_user_id(self):
        cprint("<C=g>------------------------------------------------------</C>\n")
        cprint("<C=g>First, please input your user id, i.e. your email prefix.</C>")
        cprint("<C=g> Like 'huitian.tanght', or 'haihong.xiahh'</C>\n")

        default = conf.get('##try.user.userid')

        if default:
            cprint("<C=c>%s</C> " % default)
            input = raw_input("> ")
        else:
            input = raw_input("> ")
        
        while True:
            match_empty = re.match("^\s*$", input)
            if match_empty and default:
                ret = default
                break

            match = re.match("\s*(\S+)\s*", input)
            if not match:
                cprint("<C=g>Please input again.</C>\n")
                input = raw_input("> ")
            else:
                ret = match.group(1)
                break
        cprint("<C=g>Your user id is <C=c>%s</C></C>.\n" % ret)
        return ret

    def _get_email(self, user_id):
        cprint("<C=g>------------------------------------------------------</C>\n")

        default = conf.get('##try.user.email')
        if not default:
            default = user_id + '@aliyun-inc.com'

        cprint("<C=g>Second, your email address. "
                "Press enter to use default.</C>\n")
        cprint("<C=g>The test report will be sent FROM this address.</C>\n")
                                                                                    
        cprint("<C=c>%s</C> " % default)
        input = raw_input("> ")
        while True:
            match_empty = re.match("^\s*$", input)
            if match_empty:
                ret = default
                break
            match = re.match("\s*(\S+@(aliyun-inc|taobao|alibaba-inc)\.com)\s*", input)
            if not match:
                cprint("<C=g>Invalid email address. Please input again. *@aliyun-inc.com, *@taobao.com, *@alibaba-inc.com supported.</C>\n")
                input = raw_input("> ")
            else:
                ret = match.group(1)
                break
        cprint("<C=g>Your email address is <C=c>%s</C></C>.\n" % ret)
        return ret

    def _get_editor(self, default):
        cprint("<C=g>------------------------------------------------------</C>\n")
        cprint("<C=g>Third, your favorite editor to edit template files.</C>\n")
        cprint("<C=g>Press enter to use default.</C>\n")

        conf_editor = conf.get("##try.user.editor")
        if conf_editor:
            default = conf_editor

        cprint("<C=c>%s</C> " % default)
        input = raw_input("> ")
        
        while True:
            match_empty = re.match("^\s*$", input)
            if match_empty:
                ret = default
                break
            match = re.match("\s*(\S.*\S)\s*", input)
            if not match:
                cprint("<C=g>Please input again.</C>\n")
                input = raw_input("> ")
            else:
                ret = match.group(1)
                break
        cprint("<C=g>Your editor is <C=c>%s</C></C>.\n" % ret)
        return ret

    def _check_old_atest_path(self):
        # the previous version of ftw will generate atest_profile.conf, which will cloud atest.profile
        # remove it
        (atest.path.home_path() / 'conf' / 'atest_profile.conf').remove()

        cprint("<C=g>------------------------------------------------------</C>\n")
        cprint("<C=g>If you are using customized atest.profile in previous atest vesion, please input your <C=y>current atest path</C>.</C>\n")
        cprint("<C=g>Press enter to skip, if you are not using it.</C>\n")
        input = raw_input("> ")
        
        while True:
            match_empty = re.match("^\s*$", input)
            if match_empty:
                path = None
                break
            match = re.match("\s*(\S+)\s*", input)
            if not match:
                cprint("<C=g>Please input again.</C>\n")
                input = raw_input("> ")
            else:
                path = Path(match.group(1)).abspath()
                if not path.isdir():
                    cprint("<C=g>Invalid path, please input again.</C>\n")
                    cprint("<C=g>Please make sure it's <C=y>atest</C> path, not <C=y>atest.profile</C> path.</C>\n")
                    input = raw_input("> ")
                    continue
                if not (path / 'conf' / 'atest.profile').isfile():
                    cprint("<C=g>No conf/atest.profile found, please input again.</C>\n")
                    input = raw_input("> ")
                    continue
                else:
                    break

        if path:
            cprint("<C=g>Your current atest path is <C=c>%s</C></C>.\n" % path)
            new_atest_profile = atest.path.home_path() / 'conf' / 'atest.profile'
            old_atest_profile = path / 'conf' / 'atest.profile'
            cprint("<C=g>Copying <C=c>%s</C> to <C=c>%s</C> ...</C>\n"
                   % (old_atest_profile, new_atest_profile))
            old_atest_profile.copy_to(new_atest_profile)
        else:
            cprint("<C=c>Skpped.</C>\n")

    def _check_pangu_support(self):
        cprint("<C=g>------------------------------------------------------</C>\n")
        cprint("<C=g>ATest allow you to use pangu path as a test case sandbox.</C>\n")
        cprint("<C=g>Do you want to enable it? (<C=y>yes</C> or <C=y>no</C>)</C>\n")
        enable = 'no'
        
        while True:
            cprint("<C=c>%s</C> " % enable)
            input = raw_input("> ")
            match_empty = re.match("^\s*$", input)
            if match_empty:
                break
            match = re.match("\s*(\S+)\s*", input)
            if not match:
                cprint("<C=g>Please input again.</C>\n")
                continue
            else:
                ret = match.group(1)
                if ret == 'yes' or ret == 'no':
                    enable = ret
                    break
                else:
                    cprint("<C=g>Please input again.</C>\n")
                    continue

        cprint("<C=g>Your choice is <C=c>%s</C></C>.\n" % enable)
        return enable 

    def _check_jenkins(self):
        cprint("<C=g>------------------------------------------------------</C>\n")
        cprint("<C=g>ATest allow you to upload test reports to Jenkins.</C>\n")
        cprint("<C=g>Please enter your Jenkins service address.</C>\n")
        cprint("<C=g>Press enter to use the default.</C>\n")

        default_addr = conf.get('jenkins.server_addr')
        cprint("<C=c>%s</C> " % default_addr)
        addr = raw_input("> ")
        addr = addr.strip()
        if addr:
            pass
        else:
            addr = default_addr
        
        cprint("<C=g>Jenkins service address: <C=c>%s</C></C>.\n" % addr)

        cprint("<C=g>Which project are you working on? </C>\n")
        cprint("<C=g>If not sure, click <C=y>%s</C> for all available projects.</C>\n" % addr)

        default_view = conf.get('jenkins.view')
        cprint("<C=c>%s</C> " % default_view)
        view = raw_input("> ")
        view = view.strip()
        if view:
            pass
        else:
            view = default_view
        cprint("<C=g>Jenkins Project View: <C=c>%s</C></C>\n" % view)

        jenkins_conf = atest.path.home_path() / 'conf' / 'jenkins.conf.json'
        obj = {
            'server_addr' : addr,
            'view' : view,
        }
        jenkins_conf.write(json.dumps(obj, indent=4))

    def do(self):
        cprint("<C=g>Welcome to use atest2.</C>\n")
        cprint("<C=g>Let's take a few steps to setup atest2.</C>\n")
        cprint("<C=g>ATest home path = <C=c>%s</C></C>\n" % atest.path.home_path())
        cprint("<C=g>Use <C=y>export ATEST_HOME_PATH=<your_home_path></C> to change your atest home path.</C>\n")


        # generating user conf
        user_conf = atest.path.home_path() / 'conf' / 'user.conf.json'
        user_id = self._get_user_id()
        user_conf_obj = {
            'userid' : user_id,
            'email' : self._get_email(user_id),
            'editor' : self._get_editor('vim'),
        }

        user_conf.write(json.dumps(user_conf_obj, indent=4))

        # check old atest path
        self._check_old_atest_path()

        # check pangu support
        enable_pangu = self._check_pangu_support()
        if enable_pangu == 'yes':
            active = True
        else:
            active = False
        pangu_conf = atest.path.home_path() / 'conf/test/sandbox/pangu.conf.json'
        pangu_conf_obj = {
            'active' : active
        }
        pangu_conf.write(json.dumps(pangu_conf_obj, indent=4))

        cprint("<C=g>------------------------------------------------------</C>\n")

        cprint("<C=g>Setup finished, you can change your settings later in <C=c>%s</C></C>.\n" % user_conf)
        cprint("<C=g>Thank you. Have fun.</C>\n")


