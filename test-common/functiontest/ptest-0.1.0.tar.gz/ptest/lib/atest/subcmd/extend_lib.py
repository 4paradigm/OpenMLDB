import os

import atest.auto as auto
import atest.conf as conf
import atest.log as log
import atest.subcmd
import atest.path
from atest.resource.svn import SVNResource
from atest.subcmd import SubCmd
from atest.path import Path
from atest.exception import ATestException


class ExtendLibRes(SVNResource):

    def build_once(self):

        SVNResource.build_once(self)
        
        install = Path(conf.get('test.extendlib.install'))
        install.mkdir()
        installed_tag = install / 'installed.tag'

        if self._build_step_flag or not installed_tag.isfile():
            installed_tag.remove()
            for item in self.path.tree():
                item.copy_to(install / item.relpath(start=self.path))
            installed_tag.touch()


class ExtendLibSubCmd(SubCmd):

    def do(self):

        # change the atest home into a temporary position
        atest.path._atest_home_path = None
        tmp_home = Path('/tmp/atest-tmp-home')
        os.environ['ATEST_HOME_PATH'] = tmp_home

        # if the atest_home path doesn't exist before, remove it
        remove_flag = False
        home_path = atest.path.home_path(_mkdir=False)
        if not home_path.isdir():
            remove_flag = True

        if os.getuid() != 0:
            raise ATestException("Please use root user to run 'atest2 exlib'.")

        log.prio("Upgrading extend libraries ...")
        install_target = conf.get('test.extendlib.install')

        for extend_lib in conf.get('test.extendlib.##keys'):

            if extend_lib == 'auto_upgrade' or extend_lib == 'install':
                # it's a flag, not an acutally lib
                continue

            extend_lib_conf = conf.get('test.extendlib.%s' % extend_lib)

            # using svn resource to manage library code
            res = ExtendLibRes('lib_' + extend_lib, extend_lib_conf)
            res.build()

        if remove_flag:
            home_path.remove()
        
        tmp_home.remove()
        log.prio("Done")
        
