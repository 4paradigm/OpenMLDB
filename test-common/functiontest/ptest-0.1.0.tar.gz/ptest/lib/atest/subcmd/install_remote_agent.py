import os
import time
import getpass

import atest.log as log
import atest.auto as auto
from atest.auto import AutoCmdRetcodeError, AutoCmdError
from atest.subcmd import SubCmd, SubCmdError
from atest.termcolor import cstring, cprint
import atest.path


class InstallRemoteAgent(SubCmd):

    def _check_expect(self):
        log.info("Check if the 'expect' program is available ...")
        try:
            auto.run("which expect")
        except AutoCmdRetcodeError:
            raise Exception("No 'expect' found. Please install it first.")

    def _ping(self):
        log.info("Pinging %s ..." % self.address)

        try:
            auto.run("/bin/ping -c 1 -w 20 %s" % self.address)
        except AutoCmdRetcodeError:
            raise SubCmdError("Failed to ping %s in 20 seconds." % self.address)
        log.info("Successfully reached remote machine %s." % self.address)

    def _run_expect(self, cmd):
        expect_file = atest.path.my_path() / "autossh.exp"
        expect = expect_file.read() % {
            'cmd' : cmd,
            'password' : self.password,
        }
        tmp_expect_file = atest.path.tmp_path() / 'tmp.exp'
        tmp_expect_file.write(expect)
        auto.interact("/bin/env expect < %s" % tmp_expect_file)
        tmp_expect_file.remove()

    def _run_remote(self, cmd):
        self._run_expect("ssh %s@%s %s" % (self.username, self.address, cmd))

    def _hello(self):
        try:
            self._run_remote("echo hello")
        except AutoCmdRetcodeError:
            return False
        return True

    def _get_password(self):
        flag = False 
        while not flag:
            prompt = cstring(
                "<C=y>%s</C>@<C=c>%s</C> password (or enter to skip):"
                % (self.username, self.address),
                colorful=True
            )

            self.password = getpass.getpass(prompt)
            flag = self._hello()
            if not flag:
                cprint("<C=c>Wrong password, please try again</C>\n")

    def _make_remote_dir(self):
        log.info("Making remote directory ...")
        self._run_remote("mkdir -p /home/%s/.atest_agent" % self.username)

    def _copy_agent(self):
        log.info("Copying atest agent to remote ...")
        agent = atest.path.atest_path() / "lib/atest/agent/server.py"
        self._run_expect("scp %s %s@%s:/home/%s/.atest_agent/atest_agent.py" 
                         % (agent, self.username, self.address, self.username))

    def _kill_agent(self):
        log.info("Killing running atest agent ...")
        self._run_remote(
            "for i in `ps ax | grep atest_agent | grep -v grep | awk '{print \$1}'`\;"
            "do kill -9 \$i\;"
            "done"
        )
    
    def _start_agent(self):
        log.info("Starting atest agent ...")

        prefix = ""
        if self.opts.sudo:
            prefix = "sudo"
        self._run_remote("cd /home/%s/.atest_agent\; chmod +x ./atest_agent.py\; %s nohup ./atest_agent.py > agent.log 2>&1 &" 
                         % (self.username, prefix))

    def _say_hi(self):
        log.info("Trying to say hi with atest.auto ...")
        try:
            auto.run("echo hi", remote=self.address)
        except:
            raise SubCmdError(
                "Failed to say hi to %s via atest.auto, blocked by the firewall."
                % self.address
            )

    def _check_sudo(self):
        log.info("Trying to test if the agent can sudo ...")
        try:
            auto.run("sudo echo hi", remote=self.address)
        except:
            log.warn("The agent is not able to sudo. Some command can fail.")
        
    def do(self):

        self.username = self.opts.username
        if not self.username:
            self.username = getpass.getuser()

        self.address = self.opts.address

        self._check_expect()
        self._ping()
        self._get_password()
        self._make_remote_dir()
        self._copy_agent()
        self._kill_agent()
        self._start_agent()
        
        log.info("Waiting for 5 seconds ...")
        time.sleep(5)

        self._say_hi()
        self._check_sudo()

        log.prio("The remote agent has been successfully started in host '%s'." % self.address)

