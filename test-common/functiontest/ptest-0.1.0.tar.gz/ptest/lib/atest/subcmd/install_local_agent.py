import time

import atest.log as log
import atest.auto as auto
from atest.subcmd import SubCmd, SubCmdError
import atest.path


class InstallLocalAgent(SubCmd):

    def do(self):

        server = atest.path.atest_path() / 'lib/atest/agent/server.py'
        agent = atest.path.home_path() / 'atest_agent.py'
        server.copy_to(agent)
        auto.run("chmod +x %s" % agent)

        log.info("Killing existing local agent ...")

        auto.run(
            "for i in `ps ax | grep atest_agent | grep -v grep | awk '{print $1}'`;"
            "do kill -9 $i;"
            "done"
        )

        log.info("Starting local agent ...")

        auto.run("cd %s; nohup ./%s > tmp/agent.log 2>&1 &" 
                 % (agent.dirname(), agent.basename()))

        log.info("Waiting for 5 seconds ...")
        time.sleep(5)

        try:
            log.info("Try to say hello to localhost with atest.auto ...")
            auto.run("echo hello", remote="localhost")
        except:
            raise SubCmdError("Failed to say hello to localhost with atest.auto")
            
        try:
            log.info("Test if the agent can sudo ...")
            auto.run("sudo echo hello", remote="localhost")
        except:
            log.warn("This agent is not able to sudo, some command can fail.")


        log.prio("The atest agent has been successfully started on localhost.")

