# -*- coding: utf8 -*-
import sys
import types
from argparse import ArgumentParser, HelpFormatter

import atest.log as log
import atest.modld
from atest.conf import get as conf
import atest.path
from atest.exception import ATestException

class SubCmdError(ATestException):
    pass


class SubCmdArgumentParserError(SubCmdError):
    pass


class SubCmdArgumentParser(ArgumentParser):

    def error(self, message):
        raise SubCmdArgumentParserError(message)


class SubCmdHelpFormatter(HelpFormatter):

    def format_help(self):
        help = HelpFormatter.format_help(self)

        help = "\n".join(["<C=*4>%s</C>" % x for x in help.split("\n")])
        return "<C=g>%s</C>" % help


class SubCmd(object):
    
    def __init__(self, sector, subcmd):
        self.retcode = 0
        self._subcmd = subcmd
        self._options = conf("subcmd.%s.%s.##try.option" % (sector, subcmd))
        self._parser = self._init_arg_parser()
            
    def _init_arg_parser(self):

        parser = SubCmdArgumentParser(
            prog="atest2 " + self._subcmd,
            formatter_class=SubCmdHelpFormatter,
            add_help=False,
        )
        
        if self._options == None:
            return parser

        for option in self._options:

            arg_group = {
                'name' : None,
                'flags' : [],
                'help' : None,
                'type' : 'str',
                'nargs' : None,
                'default' : None,
                'required' : 'false',
                'action' : 'store',
            }

            arg_group.update(option)

            if not arg_group['name']:
                raise SubCmdError(
                    "Missing name in options of subcmd %s" % self._subcmd
                )

            type_dict = {
                'str' : str,
                'string' : str,
                'int' : int,
            }

            if arg_group['required'] == 'true':
                required = True
            else:
                required = False
           
            flags = arg_group['flags']
            flags_len = len(flags)

            if arg_group['action'] == 'store_true' or arg_group['action'] == 'store_false':
                parser.add_argument(
                    *flags,
                    dest=arg_group['name'],
                    help=arg_group['help'],
                    default=arg_group['default'],
                    action=arg_group['action']
                )

            elif flags_len == 0:
                parser.add_argument(
                    dest=arg_group['name'],
                    help=arg_group['help'],
                    nargs=arg_group['nargs'],
                    default=arg_group['default'],
                    type=type_dict[arg_group['type']],
                    action=arg_group['action']
                )
                
            else:
                parser.add_argument(
                    *flags,
                    dest=arg_group['name'],
                    help=arg_group['help'],
                    nargs=arg_group['nargs'],
                    default=arg_group['default'],
                    type=type_dict[arg_group['type']],
                    required=required,
                    action=arg_group['action']
                )

        return parser


    def parse_args(self, args):
        self.opts = self._parser.parse_args(args)

    def format_help(self):
        return self._parser.format_help()

    def do(self):
        raise SubCmdError("Sub command '%s' is not implemented." % self._subcmd)


def find(subcmd):
    # Find sub command from sub.conf.json in each sector
    sector = None
    for sec in conf("subcmd.##keys"):
        for sub in conf("subcmd.%s.##keys" % sec):
            if sub == subcmd:
                sector = sec

    if not sector:
        raise SubCmdError(
            "Sub command '%s' not found. Please try 'atest2 help' for usage."
            % subcmd
        )
    
    return sector


def load(sector, subcmd):
    # Load the sub command
    module_name = conf("subcmd.%s.%s.module" % (sector, subcmd))

    subcmd_class = atest.modld.load_class(module_name, SubCmd)
    return subcmd_class(sector, subcmd)


def execute(subcmd, args):
    # Execute the sub command
    sector = find(subcmd)
    subcmd = load(sector, subcmd)
    subcmd.parse_args(args)
    subcmd.do()
    return subcmd.retcode


