# -*- coding: utf8 -*-
#
# $$$
# Author:                  Haowei Yao
# Create Time:             Mon Mar  5 21:08:42 CST 2012
# File:                    lib/atest/exception.py
# Module Path:             lib
# Module Name:             atest.exception
# $$$
#
# Description:             Defines ATestException as a base exception class
#                          to be subclassed for error handling
#


class ATestException(Exception):
    pass

