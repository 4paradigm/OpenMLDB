# -*- coding: utf8 -*-
import sys
import imp
import types
import inspect

from atest.exception import ATestException

class ModuleLoaderError(ATestException):
    pass

def _get_class_from_module(source_name, module, base_class):
    for name, obj in inspect.getmembers(module):
        if (not type(obj) == types.ClassType) and (not type(obj) == types.TypeType):
            continue
        if issubclass(obj, base_class) and obj.__module__ == module.__name__:
            return obj

    raise ModuleLoaderError(
        "Failed to find subclass of '%s' in %s."
        % (base_class.__name__, source_name)
    )

def load_class(module_name, base_class):
    __import__(module_name)
    module = sys.modules[module_name]
    return _get_class_from_module("module '%s'" % module_name, module, base_class)

def load_func(module_name, func_name):
    __import__(module_name)
    module = sys.modules[module_name]

    if hasattr(module, func_name):
        func = getattr(module, func_name)
        if type(func) == types.FunctionType and func.__module__ == module.__name__:
            return func

    raise ModuleLoaderError(
        "Failed to find function '%s' in module '%s'."
        % (func_name, module_name)
    )

modules = {}
load_num = 0
sys.modules['atest_loads'] = imp.new_module('atest_loads')

def load_source(source_file, repeat=False):
    global modules
    global load_num

    if source_file in modules and not repeat:
        name, module = modules[source_file]
    else:
        name = 'atest_loads.' + str(load_num)
        load_num += 1
        module = imp.load_source(name, source_file)
        modules[source_file] = (name, module)
    return module

def load_class_from_source(source_file, base_class):
    module = load_source(source_file)
    return _get_class_from_module(source_file, module, base_class)
