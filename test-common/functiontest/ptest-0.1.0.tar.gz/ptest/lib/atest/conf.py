# -*- coding: utf8 -*-
import json
import re
import ConfigParser

from atest.exception import ATestException
import atest.path
import atest.log as log
from atest.addr import ATestAddrContainer
from atest.addr import ATestAddrError

class ATestConfError(ATestException):
    pass

_init_conf = None
_curr_conf = None


def _find_temp_value(match, addr):
    key = match.group(2)

    try:
        return get(key)
    except ATestConfError:
        pass

    return match.group(0) 


def _apply_temp(value, addr):
    # replace the templates in config values
    # BUG: temp loop not solved

    if isinstance(value, str) or isinstance(value, unicode):
        # replacing %{addr}%
        repl = lambda m: _find_temp_value(m, addr)
        return re.sub("(%\{([\w|\d|_|\.]+)\}%)", repl, str(value))
    elif isinstance(value, list):
        ret = []
        for item in value:
            ret.append(_apply_temp(item, addr))
        return ret
    elif isinstance(value, dict):
        ret = {}
        for k, v in value.iteritems():
            ret[k] = _apply_temp(v, addr)
        return ret

    return value
        

def get(addr):
    try:
        return _apply_temp(_curr_conf.get(addr), addr)
    except ATestAddrError as e:
        raise ATestConfError("Failed to get conf '%s': %s" % (addr, e))


def append_conf_dir(conf_dir):
    global _curr_conf
    data = _read_conf(conf_dir)
    _curr_conf.append(data)


def reset_conf():
    global _curr_conf
    _curr_conf = _init_conf.clone()


_skipped_conf_files = []

def _read_conf(conf_dir, base_key=""):
    global _skipped_conf_files

    conf_data = {}
    if not conf_dir.isdir():
        return conf_data

    for item in conf_dir:
        item_name = item.basename().split('.')[0]
        if item.isdir():
            ret_data = _read_conf(item, base_key="."+item_name)
            conf_data[item_name] = ret_data
        elif item.basename().endswith('.conf') or item.basename().endswith('.profile'):
            # read *.conf and *.profile files
            # *.profile is for backward compatiblity

            if item.basename() == "logging.conf":
                # workaround to bypass the 
                # TODO remove this workaround
                continue

            if item in _skipped_conf_files:
                # prevent reading the invalid formatted conf file again
                continue
                
            if item.basename().endswith('.profile'):
                item_name += "_profile"
                # so atest.profile goes to atest_profile namespace

            conf_data[item_name] = {}
            parser = ConfigParser.ConfigParser()
            parser.optionxform = str   # make this parser case sensitive

            try:
                parser.read(item)
            except Exception as e:
                # read() may fail if the 'conf' file is not in INI format
                # it happens when the user mess it up
                # skip reading it in this case, for backward compatibility
                log.warn("Failed to read '%s' in INI format, skip: %s" % (item, e))
                _skipped_conf_files.append(item)
                continue

            try:
                for section in parser.sections():
                    conf_data[item_name][section] = {}
                    for key, value in parser.items(section):
                        conf_data[item_name][section][key] = value
            except Exception as e:
                # the same reason with the previous handling code
                log.warn("Failed to read '%s' in INI format, skip: %s" % (item, e))
                _skipped_conf_files.append(item)
                continue

        elif item.basename().endswith('.conf.json'):
            try:
                conf_data[item_name] = json.loads(item.read())
            except ValueError as e:
                raise ATestConfError("Failed to read json %s: %s" % (item, e))

    return conf_data
    
    
_init_conf = ATestAddrContainer(_read_conf(atest.path.atest_path() / 'conf'))
_init_conf.append(_read_conf(atest.path.home_path(_mkdir=False) / 'conf'))
_curr_conf = _init_conf.clone()

