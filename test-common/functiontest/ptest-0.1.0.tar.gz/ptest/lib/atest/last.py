import anydbm
import atest.path

dbfile = atest.path.home_data_path() / 'last.db'

def reset():
    return
    dbfile.remove()

def set(key, value):
    return
    db = anydbm.open(dbfile, 'c')
    db[key] = value

def getall():
    return
    db = anydbm.open(dbfile, 'c')
    return db
    
def get(key):
    return
    return getall()[key]

