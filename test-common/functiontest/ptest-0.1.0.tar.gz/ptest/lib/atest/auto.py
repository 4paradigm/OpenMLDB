# -*- coding: utf8 -*-
#
# $$$
# Author:                  Haowei Yao
# Create Time:             Mon Mar  6 15:43:28 CST 2012
# File:                    lib/atest/auto.py
# Module Path:             lib
# Module Name:             atest.auto
# $$$
#
# Description:             Sub process/command high level encapsulation.
#                          Providing sync/async, remote and root user mode to call
#                          a sub process/command, with non-zero exist status
#                          handling and stdout slicing features.
#

import os
import signal
import time
import copy
import subprocess as sub
import threading
import xmlrpclib
from threading import Timer, Thread

import atest.log as log
import atest.path
import atest.usrsig as usrsig
from atest.exception import ATestException
import atest.agent.client


class AutoCmdError(ATestException):
    pass


class AutoCmdRetcodeError(AutoCmdError):
    
    def __init__(self, message, retcode, stderr, stdout):
        AutoCmdError.__init__(self, message)
        self.retcode = retcode
        self.stderr = stderr
        self.stdout = stdout


class AutoCmdTimedOut(AutoCmdError):
    pass


_daemon_list = []


class _AutoCmd:

    # A signal map for print help information when
    # subprocess exited with one of these signals
    __signal_map = {
        '14' : 'SIGALRM',
        '1' : 'SIGHUP',
        '2' : 'SIGINT',
        '9' : 'SIGKILL',
        '13' : 'SIGPIPE',
        '15' : 'SIGTERM',
        '6' : 'SIGABRT',
        '8' : 'SIGFPE',
        '4' : 'SIGILL',
        '3' : 'SIGQUIT',
        '11' : 'SIGSEGV',
        '5' : 'SIGTRAP',
    }

    _max_log_size = 1024

    def __init__(self, cmd, env={}, timeout=0):
        self.cmd = cmd
        self.env = env
        self.timeout = timeout

        self.finished = False
        self.stdin = None
        self.stdout = None
        self.stderr = None
        self.retcode = None
        self.start_time = None
        self.stop_time = None

        self._daemon_cls = _AutoCmdDaemon
        self._title = "_AutoCmd" # to be subclassed
        self._env_str = "(None)"
        self._raw_files = {}

        # compose a help info for env values
        if self.env:
            self._env_str = "".join(
                ["\n<C=*4/>%s = %s" % (k, v) for k, v in env.items()]
            )

    def _get_pid(self):
        return self._process.pid
        
    def _log_wrapper(self, item):
        # a log helper to compose strings for cmd infos,
        ret = ""
        if item is None:
            ret = "(0): (None)"
        elif isinstance(item, str) or isinstance(item, unicode):
            ret = "(%d): " % len(item) + item
        elif isinstance(item, list):
            length = 0
            for l in item:
                ret += "\n<C=*4/>" + l
                length += len(l) + 1
            if length > 0:
                length -= 1
            ret = "(%d):" % length + ret
        elif isinstance(item, tuple):
            ret = "(%d): %s" % item
        else:
            raise AutoCmdError("Failed to compose log: '%s' it's a %s" % 
                               (item, item.__class__.__name__))
        return ret

    def _log_raw_data(self, data, tag):
        raw_file = self._tmp_dir / tag

        raw_data = "\n".join(data)
        if len(raw_data) > self._max_log_size:
            if tag in self._raw_files:
                pass
            else:
                raw_file.write(raw_data)
                self._raw_files[tag] = raw_file
            ret = self._log_wrapper(
                (len(raw_data), "<saved in %s>" % raw_file)
            )
        else:
            ret = self._log_wrapper(data)

        return ret

    def _log_begin(self, method, cmd_str, stdin, title=""):
        # trace info when an auto cmd started
        
        tmp = self._log_wrapper(stdin)

        self._tmp_dir = atest.path.tmp_path() / 'auto' / str(int(time.time())) + "." + self._get_pid()

        log.trace(
            self._title + " Started " + title + '(%s)' % cmd_str +
            "\n@Method: " + method +
            "\n@PID: " + str(self._get_pid()) +
            "\n@CmdStr" + self._log_wrapper(cmd_str) +
            "\n@TimeOut: " + "%.6f" % self.timeout +
            "\n@Env: " + self._env_str +
            "\n@Stdin" + self._log_raw_data(stdin, 'stdin')
        )
        self.start_time = time.time()

    def _log_finish(self, method, cmd_str, 
                    stdin, retcode, stdout, stderr, title=""):
        # trace info when an auto cmd stopped
        ret_info = ""
        if retcode < 0 and str(-retcode) in self.__signal_map:
            ret_info = " (Received %s)" % self.__signal_map[str(-retcode)]
        self.stop_time = time.time()

        log.trace(
            self._title + " Stopped " + title + '(%s)' % cmd_str +
            "\n$Method: " + method +
            "\n$PID: " + str(self._get_pid()) +
            "\n$CmdStr" + self._log_wrapper(cmd_str) +
            "\n$TimeOut: " + "%.6f" % self.timeout +
            "\n$Env: " + self._env_str +
            "\n$Return: " + str(retcode) + ret_info +
            "\n$Duration: " + "%.6f" % (self.stop_time - self.start_time) +
            "\n$Stdin" + self._log_raw_data(stdin, 'stdin') + 
            "\n$Stdout" + self._log_raw_data(stdout, 'stdout') +
            "\n$Stderr" + self._log_raw_data(stderr, 'stderr'),
        )

    def _raise(self, cmd_str, retcode, stderr, stdin=[], title=""):
        # compose an error string with retcode, stderr, stdin, if any
        error = "Command %s (%s) exited with status %d." % (
            title, cmd_str, retcode
        )
        
        if stderr:
            error += " Error: " + "\n".join(stderr)
        if stdin:
            error += " Input: " + "\n".join(stdin)
        return error

    def _warn(self, cmd_str, stderr, stdin=[], title=""):
        # compose a warning string with stderr, stdin if any
        warn = "Command %s (%s) printed error message." % (
            title, cmd_str
        )
        
        if stderr:
            warn += " Error:\n" + "\n".join(stderr)
        if stdin:
            warn += " Input:\n" + "\n".join(stdin)
        return warn

    def _kill_process_helper(self, signum, killcb=os.kill, runcb=None):
        # kill the subprocess
        # to be subclassed for other ways to stop a subprocess, e.g. via xmlrpc

        if not runcb:
            runcb = run

        #self.process.kill() #TODO replace when python upgraded
        ppid = self._get_pid()

        if signum == signal.SIGKILL:
            # When parent got SIGKILL, its child processes will also be killed
            # But we knew it's not always true
            # MAKE SURE the children are killed as well

            # Find all the child pid
            pids = [ppid]
            ppids = [ppid]

            while ppids:
                curr_ppid = ppids[0]
                del ppids[0]
                lines = []
                try:
                    lines = runcb(
                        "ps -o pid --ppid %s --no-headers" % str(curr_ppid)
                    )[:-1]
                except AutoCmdRetcodeError:
                    # no child process
                    pass
                child_pids = [int(x) for x in lines]
                pids += child_pids
                ppids += child_pids

            # make sure each pid is killed
            all_killed = False
            while not all_killed:
                all_killed = True
                for pid in pids:
                    try:
                        killcb(pid, signum)
                        alll_killed = False
                    except OSError:
                        continue
        else:
            killcb(ppid, signum)

    def _start_process_helper(self):
        # start the piped subprocess
        # to be subclassed for other ways to start it, e.g. via xmlrpc

        env = copy.deepcopy(os.environ)
        env.update(self.env)
        process = sub.Popen(self.cmd,
                            stdin=sub.PIPE, stdout=sub.PIPE, 
                            stderr=sub.PIPE,
                            shell=True, env=env)
        self._process = process

    def _finish_process_helper(self, stdin_str=None):
        # wait the subprocess to exit, and fetch the stdout, stderr, retcode
        stdout_str, stderr_str = self._process.communicate(input=stdin_str)
        retcode = self._process.returncode
        return (retcode, stdout_str, stderr_str)

    def _start_process(self, method, stdin, interact=False):
        if interact:
            # for interact mode, use non-piped way
            env = copy.deepcopy(self.env)
            env.update(os.environ)
            self._process = sub.Popen(self.cmd, shell=True, env=env)
        else:
            self._start_process_helper()
        self._log_begin(method, self.cmd, stdin)

    def _finish_process(self, method, stdin, 
                        warn_on_stderr, interact=False):
        # 1, start a timer if time_out set
        # 2, wait the subprocess to finish
        # 3, handle timed out
        # 4, handle return code
        # 5, handle stderr
        # 6, mark the process to be finished, 
        #    and store retcode, stdin, stdout, stderr
        # 7, return stdout and error handling information
        cmd = self.cmd
        warn_str = None
        ret_error_str = None
        timed_out_str = None
        self._timed_out_flag = False
        stdin_str = "\n".join(stdin)
        if self.timeout != 0:
            def timed_out():
                self._timed_out_flag = True
                self._kill_process_helper(signal.SIGKILL)
            self.__timer = Timer(self.timeout, timed_out)
            self.__timer.start()

        stdout_str = None 
        stderr_str = None
        retcode = None

        if interact:
            retcode = self._process.wait()
        else:
            (retcode, stdout_str, stderr_str) = self._finish_process_helper(
                stdin_str=stdin_str
            )

        # TODO when stderr & stdout is huge, process it separately

        if self.timeout != 0:
            self.__timer.cancel()

        if interact:
            stdout = []
            stderr = []
        else:
            if stdout_str:
                stdout = stdout_str.split("\n")
            else:
                stdout = []
            if stderr_str:
                stderr = stderr_str.split("\n")
            else:
                stderr = []

        if self._timed_out_flag:
            # timed out handling
            self._log_finish(method, cmd, stdin, 
                             retcode, stdout, stderr, 
                             title=("\nTimed Out %.6f seconds" % self.timeout))
            timed_out_str = (
                "Command (%s) timed out %.6f seconds." % 
                (cmd, self.timeout)
            )
        else:
            self._log_finish(method, cmd, stdin, retcode, stdout, stderr)
            if retcode != 0:
                ret_error_str = self._raise(cmd, retcode, stderr, stdin=stdin)
            elif stderr_str and warn_on_stderr:
                warn_str = self._warn(cmd, stderr, stdin=stdin)

        self.finished = True
        self.stdout = stdout_str
        self.retcode = retcode
        self.stderr = stderr_str
        self.stdin = stdin_str

        return (stdout, warn_str, ret_error_str, timed_out_str)

    def run(self, stdin=[], warn_on_stderr=True):
        if isinstance(stdin, str) or isinstance(stdin, unicode):
            stdin = [stdin]

        # start a sub process and wait for it
        self._start_process('run', stdin)
        (stdout, warn_str, ret_error_str, timed_out_str) = ( 
            self._finish_process('run', stdin, warn_on_stderr)
        )
        if timed_out_str is not None:
            raise AutoCmdTimedOut(timed_out_str)
        elif ret_error_str is not None:
            raise AutoCmdRetcodeError(ret_error_str, self.retcode, self.stderr, self.stdout)
        elif warn_str is not None:
            log.warn(warn_str)
        return stdout

    def __daemon_thread(self, stdin, warn_on_stderr, raise_on_failure):
        (stdout, warn_str, ret_error_str, timed_out_str) = ( 
            self._finish_process('daemon', stdin, warn_on_stderr)
        )

        if timed_out_str is not None:
            usrsig.raise_error(AutoCmdTimedOut(timed_out_str))
        elif ret_error_str is not None and raise_on_failure:
            usrsig.raise_error(AutoCmdRetcodeError(ret_error_str, self.retcode, self.stderr, self.stdout))
        elif warn_str is not None:
            log.warn(warn_str)
        return stdout

    def daemon(self, stdin=[], warn_on_stderr=True, raise_on_failure=True):
        # start a sub process and return the daemon instance
        self._start_process('daemon', stdin)

        thread = Thread(
            target=self.__daemon_thread,
            name="AutoCmdDaemonThread",
            args=[stdin, warn_on_stderr, raise_on_failure],
        )
        thread.start()
        return self._daemon_cls(self, self._process, thread)

    def interact(self):
        # start a sub process in interactive way
        self._start_process('interact', [], interact=True)
        (stdout, warn_str, ret_error_str, timed_out_str) = (
            self._finish_process('interact', [], False, interact=True)
        )
        if ret_error_str:
            raise AutoCmdRetcodeError(ret_error_str, self.retcode, self.stderr, self.stdout)


class _AutoCmdDaemon:

    def __init__(self, auto, process, thread):
        self.auto = auto
        self._process = process
        self._thread = thread
        self._title = 'daemon'
        global _daemon_list
        _daemon_list.append(self)

    def _get_pid(self):
        return self._process.pid

    def wait(self, nohang=False):
        log.trace(
            "Waiting for %s (%s) PID %s ..." 
            % (self._title, self.auto.cmd, self._get_pid()))

        if nohang:
            self._thread.join(0)
            if self.auto.finished:
                return self.auto.stdout
            else:
                return None
        else:
            self._thread.join()
            return self.auto.stdout

    def terminate(self):
        log.trace(
            "Terminating %s (%s) PID %s ..." 
            % (self._title, self.auto.cmd, self._get_pid()))
        self._send_signal(signal.SIGTERM)

    def kill(self):
        log.trace("Killing %s (%s) PID %s ..." 
                  % (self._title, self.auto.cmd, self._get_pid()))
        self._send_signal(signal.SIGKILL)

    def _send_signal(self, signum):
        try:
            self.auto._kill_process_helper(signum)
            self._thread.join()
        except AutoCmdRetcodeError:
            pass


class _RemoteAutoCmd(_AutoCmd):

    def __init__(self, cmd_str, remote="localhost", env={}, timeout=0):
        _AutoCmd.__init__(self, cmd_str, env=env, timeout=timeout)
        self.remote = remote
        self._proxy = atest.agent.client.get_client(remote)
        self._title = "_RemoteAutoCmd@%s" % remote
        self._daemon_cls = _RemoteAutoCmdDaemon
        self._process = None

    def _get_pid(self):
        return self._process

    def _kill_process_helper(self, signum):
        # create a new proxy here to prevent 'CannotSendRequest' error
        killproxy = atest.agent.client.get_client(self.remote)
        _AutoCmd._kill_process_helper(
            self,
            signum, 
            killcb = killproxy.cmd.kill,
            runcb = lambda x: run(x, remote=self.remote)
        )

    def _start_process_helper(self):
        self._process = self._proxy.cmd.start(self.cmd, self.env, True)

    def _finish_process_helper(self, stdin_str):
        return self._proxy.cmd.finish(self._process, stdin_str)

    def interact(self):
        # this method is not implemented because we could not open a
        # remote terminal via current xmlrpc grp_client

        # TODO implement
        raise AutoCmdError(
            "Sorry, start a remote command interactively " +
            "is not currently supported."
        )

    def kill(self):
        try:
            _AutoCmd.kill(self)
        except xmlrpclib.Fault:
            # no such process
            pass


class _RemoteAutoCmdDaemon(_AutoCmdDaemon):

    def __init__(self, auto, process, thread):
        _AutoCmdDaemon.__init__(self, auto, process, thread)
        self._title = 'daemon'
        self._proxy = self.auto._proxy

    def _get_pid(self):
        return self.auto._process

    def _kill_process_helper(self, signum):
        self.auto._kill_process_helper(signum)

    def kill(self):
        try:
            _AutoCmdDaemon.kill(self)
        except xmlrpclib.Fault:
            # no such process
            pass


class _RootUserAutoCmd(_RemoteAutoCmd):
    
    def __init__(self, cmd_str, remote="localhost", env={}, timeout=0):
        if remote is None:
            remote = "localhost"
        _RemoteAutoCmd.__init__(self, cmd_str, 
                               remote=remote, env=env, timeout=timeout)
        # check if the agent is started with root
        if self._proxy.os.call('os.getuid') != 0:
            raise AutoCmdError(
                "Sorry, atest agent on %s is not started with root user."
                % remote
            )


def cmd(cmd_str, remote=None, root_user=False, env={}, timeout=0):
    # return an instance of AutoCmd (or its subclass) via the user args
    if root_user:
        return _RootUserAutoCmd(cmd_str, remote=remote, 
                                env=env, timeout=timeout)
    elif remote is not None:
        return _RemoteAutoCmd(cmd_str, remote=remote, 
                              env=env, timeout=timeout)
    else:
        return _AutoCmd(cmd_str, env=env, timeout=timeout)


def run(cmd_str, remote=None, root_user=False, env={}, 
        timeout=0, stdin=[], warn_on_stderr=True):
    # shortcut for run
    return cmd(
        cmd_str, remote=remote, root_user=root_user, env=env, timeout=timeout
    ).run(stdin=stdin, warn_on_stderr=warn_on_stderr)


def daemon(cmd_str, remote=None, root_user=False, env={}, 
           timeout=0, stdin=[], warn_on_stderr=True, raise_on_failure=True):
    # shortcut for daemon
    return cmd(
        cmd_str, remote=remote, root_user=root_user, env=env, timeout=timeout
    ).daemon(
        stdin=stdin, 
        warn_on_stderr=warn_on_stderr, 
        raise_on_failure=raise_on_failure,
    )


def interact(cmd_str, env={}, timeout=0):
    # shortcut for interact
    return cmd(cmd_str, env=env, timeout=timeout).interact()


def run_classic(cmd_str, remote=None, root_user=False, env={}, 
                timeout=0, stdin=[], warn_on_stderr=True):
    # some people don't want to use exception to handle command error
    # make them happy
    # return the classic (stdout, stderr, retcode) triple

    cmd_inst = cmd(
        cmd_str, remote=remote, root_user=root_user, env=env, timeout=timeout
    )
    try:
        cmd_inst.run(stdin=stdin, warn_on_stderr=warn_on_stderr)
    except AutoCmdRetcodeError:
        pass

    return cmd_inst.stdout, cmd_inst.stderr, cmd_inst.retcode 


def kill_daemons():
    log.debug("Killing all daemon commands ...")
    global _daemon_list
    for daemon in _daemon_list:
        daemon.kill()
    _daemon_list = []


def wait_daemons():
    log.debug("Waiting for all daemon commands ...")
    global _daemon_list
    for daemon in _daemon_list:
        daemon.wait()
    _daemon_list = []

