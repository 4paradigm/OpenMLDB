import xmlrpclib


def get_client(host, port=51352):
    return xmlrpclib.ServerProxy('http://%s:%d' % (host, port), allow_none=True)

