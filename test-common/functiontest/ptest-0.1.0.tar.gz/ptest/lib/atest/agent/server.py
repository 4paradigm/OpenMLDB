#!/bin/env python

import types
import sys
import os
import os.path
import shutil
import subprocess as sub
import xmlrpclib
from xmlrpclib import Binary
import socket
from SimpleXMLRPCServer import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
from SocketServer import ThreadingMixIn

class ATestAgent:
    pass


class FileAgent(ATestAgent):

    def read(self, path):
        fp = open(path, 'r')
        ret = fp.read()
        fp.close()
        return Binary(ret)

    def readlines(self, path):
        fp = open(path, 'r')
        lines = fp.readlines()
        fp.close()
        return lines

    def write(self, path, content):
        fp = open(path, 'w')
        fp.write(content.data)
        fp.flush()
        fp.close()

    def copy(self, src, dest, host, port):
        proxy = xmlrpclib.ServerProxy('http://%s:%d' % (host, port), allow_none=True)
        proxy.file.write(dest, self.read(src))


class OSCallAgent(ATestAgent):

    def _impfunc(self, funcname):
        modulename, realfuncname = funcname.rsplit('.', 1)

        try:
            __import__(modulename)
        except ImportError:
            raise Exception("Failed to import module '%s'." % modulename)

        module = sys.modules[modulename]
        
        if hasattr(module, realfuncname):
            func = getattr(module, realfuncname)
            if type(func) == types.FunctionType and func.__module__ == module.__name__:
                return func
            elif type(func) == types.BuiltinFunctionType:
                return func

        raise Exception(
            "Failed to find function '%s' in module '%s'."
            % (realfuncname, modulename)
        )


    def call(self, funcname, *args, **kwargs):
        func = self._impfunc(funcname)
        return func(*args, **kwargs)

    def stat(self, path):
        return tuple(os.stat(path))


class CmdAgent(ATestAgent):

    def __init__(self):
        self.map = {}

    def start(self, cmd, env={}, shell=True):
        env.update(os.environ)

        process = sub.Popen(
            cmd, 
            shell=shell,
            env=env,
            stdin=sub.PIPE,
            stdout=sub.PIPE,
            stderr=sub.PIPE,
        )

        self.map[process.pid] = process
        return process.pid

    def finish(self, pid, stdin):
        process = self.map[pid]
        stdout, stderr = process.communicate(input=stdin)
        retcode = process.returncode
        return (retcode, stdout, stderr)

    def kill(self, pid, signum):
        os.kill(pid, signum)


class ATestAgentServer(ThreadingMixIn, SimpleXMLRPCServer):
    allow_none = True
    allow_reuse_address = True

    def __init__(self, addr):
        SimpleXMLRPCServer.__init__(self, addr)
        self.allow_none = True # workaround to make sure allow_none == True
        
        class AgentWrapper:
            pass

        wrapper = AgentWrapper()
        setattr(wrapper, 'file', FileAgent())
        setattr(wrapper, 'os', OSCallAgent())
        setattr(wrapper, 'cmd', CmdAgent())

        self.register_instance(wrapper, allow_dotted_names=True)
        


if __name__ == "__main__":
    port = 51352

    if len(sys.argv) == 2:
        port = int(sys.argv[1])

    server = ATestAgentServer(('', port)) 
    server.serve_forever()

