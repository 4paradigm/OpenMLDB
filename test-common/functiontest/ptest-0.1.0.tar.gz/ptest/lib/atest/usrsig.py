# -*- coding: utf8 -*-
#
# $$$
# Author:                  Haowei Yao
# Create Time:             Mon Mar  6 13:03:25 CST 2012
# File:                    lib/atest/usrsig.py
# Module Path:             lib
# Module Name:             atest.usrsig
# $$$
#
# Description:             Defines handling for signal SIGUSR2, used to trap
#                          callback functions in the main thread, especially 
#                          raising an exception.
#

import os
import signal
import threading

from atest.exception import ATestException

class UserSignalError(ATestException):
    pass

# callback list
# producer: fire
# consumer: _atest_user_signal_handler
_callback_list = [
    # {signame, pid, src, dest, handler, args}
]

def fire(callback,
         args=[],
         kwargs={},
         name="ANON", 
         src="MainThread"):
    # add a callback in the '_callback_list'
    # and fire signal SIGUSR2 to force the main thread to call it

    global _callback_list
    pid = os.getpid()
    _callback_list.append({
        "name" : name,
        "src" : src,
        "callback" : callback,
        "args" : args,
        "kwargs" : kwargs,
    })
    os.kill(pid, signal.SIGUSR2)


def raise_error(error):
    # a shortcut for method 'fire':
    # the typicall usage for 'fire' is force the main thread to raise
    # an exception in the current frame

    # so, we have 'raise_error' as a shortcut
    if not isinstance(error, ATestException):
        raise UserSignalError("error must be an instance of 'ATestException'")

    def to_raise(error):
        raise error

    fire(to_raise, args=[error])


def _atest_user_signal_handler(signum, frame):
    # signal.SIGUSR2 handler
    # it's called in the current frame of the main thread

    global _callback_list
    callback_list = _callback_list
    _callback_list = [] 
    for cb in callback_list:
        if cb["callback"]:
            cb["callback"](*cb["args"], **cb["kwargs"])


signal.signal(signal.SIGUSR2, _atest_user_signal_handler)

