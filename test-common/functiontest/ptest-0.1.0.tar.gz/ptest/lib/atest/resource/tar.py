import os

import atest.log as log
import atest.auto as auto
from atest.path import Path
import atest.path

from atest.resource.local import LocalDirResource, LocalDirResourceError

class TarResourceError(LocalDirResourceError):
    pass


class TarResource(LocalDirResource):

    tag = 'tar'
    default_conf = {
        'build_steps' : [],
        'products' : {},
        'local_dir' : ".",
        'rename' : True,
    }
    required_conf = ['tar']
    report = True

    def _get_tar(self):
        return Path(self.conf['tar'])

    def _untar(self):
        self.local_dir.remove()
        self.local_dir.mkdir()
        auto.run(
            'cd %s; tar xvf %s' % (self.local_dir, self.tar_file)
        )

        if self.conf['rename']:
            listdir = self.local_dir.listdir()
            if len(listdir) == 1:
                item = listdir[0]
                if item.isdir():
                    # the tar file has only one dir
                    tmp_dir = atest.path.tmp_path() / item.basename()
                    item.move_to(tmp_dir) 
                    self.local_dir.remove()
                    tmp_dir.move_to(self.local_dir)

    def _do_update(self):

        self.tar_file = self._get_tar()
        if not self.tar_file.isfile():
            raise TarResourceError(
                "Tar file '%s' doesn't exist." % self.tar_file
            )

        tar_mtime = self.tar_file.mtime() 
    
        if self._built_tag.isfile():
            tag_time = float(self._built_tag.read())
            if tag_time >= tar_mtime:
                self._build_step_flag = False
            else:
                self._untar()
        else:
            if self.local_dir.isdir() and not self.local_dir.isemptydir():
                dir_mtime = self._get_min_mtime(self.local_dir)
                if dir_mtime >= tar_mtime:
                    pass
                else:
                    self._untar()
            else:
                self._untar()

    def desc(self):
        return "Tar Resource %s" % self.conf['tar']

