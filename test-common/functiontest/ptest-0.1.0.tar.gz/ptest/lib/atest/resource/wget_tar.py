import os

import atest.log as log
import atest.auto as auto
from atest.path import Path
import atest.path

from atest.resource.tar import TarResource, TarResourceError
from atest.resource.wget import WgetResource, WgetResourceError

class WgetTarResourceError(TarResourceError, WgetResourceError):
    pass


class WgetTarResource(TarResource, WgetResource):

    tag = 'wget_tar'
    default_conf = {
        'download' : False,
        'build_steps' : [],
        'products' : {},
        'local_dir' : ".",
        'rename' : True,
    }
    required_conf = ['url']
    report = True

    def _get_tar(self):
        return self.package_path

    def _get_package_info(self):
        url_split = self._get_url().split('/')
        self.package_name = url_split[-1]
        self.package_path = atest.path.tmp_path() / self.package_name
        if self.package_path.isfile():
            return True
        return False

    def _do_update(self):

        # download
        WgetResource._do_update(self)

        # untar
        TarResource._do_update(self)

    def desc(self):
        return "WgetTar Resource %s" % self.conf['url']

