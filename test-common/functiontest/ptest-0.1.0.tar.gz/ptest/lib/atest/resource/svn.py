import re

import atest.path
import atest.log as log
import atest.auto as auto
from atest.auto import AutoCmdRetcodeError
from atest.resource.local import LocalDirResource, LocalDirResourceError
from atest.conf import get as env


class SVNResourceError(LocalDirResourceError):
    pass


class SVNResource(LocalDirResource):

    tag = 'svn'
    
    default_conf = {
        'update' : True,
        'revert' : False,
        'revision' : 'newest',
        'build_steps' : [],
        'products' : {},
        'local_dir' : ".",
    }

    required_conf = ['url']

    report = True

    def __init__(self, res_addr, conf):

        LocalDirResource.__init__(self, res_addr, conf)

        self._auth_str = (
            "--username=%s --password=%s" 
            % (env("user.svn.username"), env("user.svn.password"))
        )

        self._revi_str = ""
        if self.conf['revision'] != 'newest':
            self._revi_str = "-r%s" % str(self.conf['revision'])

    def _svn_co(self):
        self.local_dir.remove()
        return auto.run("svn co --non-interactive %s %s %s %s"
                        % (self._revi_str, self._auth_str, 
                           self.conf['url'], self.local_dir))
                                                                                    
    def _svn_up(self):
        return auto.run("cd %s; svn up --non-interactive %s %s"
                        % (self.local_dir, self._revi_str, self._auth_str))

    def _svn_revert(self):
        return auto.run("cd %s; svn revert -R --non-interactive ." % self.local_dir)

    def _get_svn_info(self):
        ret = {}
        try:
            lines = auto.run("svn info %s" % self.local_dir)
        except AutoCmdRetcodeError:
            return None
        for line in lines:
            match = re.match("^URL:\s+(.*)$", line)
            if match:
                ret['url'] = match.group(1)
            match = re.match("^Revision:\s+(.*)$", line)
            if match:
                ret['revision'] = match.group(1)
        return ret

    def _do_update(self):

        if self.local_dir.isdir():

            svn_info = self._get_svn_info()

            if svn_info == None:
                # not a svn working copy
                self._svn_co()

            elif svn_info['url'] != self.conf['url'].rstrip('/'):
                # the svn url has changed, so check out a new one
                self._svn_co()

            elif self.conf['update']:
                if self.conf['revert']:
                    self._svn_revert()
                    self._svn_up()
                else:
                    ret = self._svn_up()
                    if len(ret) <= 2 and self._built_tag.isfile():
                        # no changes
                        self._build_step_flag = False

            else:
                # the user set update=false
                self._svn_co()
        else:
            self._svn_co()

        self._svn_info = self._get_svn_info()

    def svn_info(self):
        return self._svn_info

    def desc(self):
        return "SVN Resource %s Revision=%s" % (self._svn_info['url'], str(self._svn_info['revision']))

