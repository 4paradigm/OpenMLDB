import atest.path
import atest.log as log
import atest.auto as auto
from atest.auto import AutoCmdRetcodeError
from atest.resource.local import LocalDirResource, LocalDirResourceError
from atest.conf import get as env

class WgetResourceError(LocalDirResourceError):
    pass


class WgetResource(LocalDirResource):

    report = True
    
    default_conf = {
        'download'  : True,
        'build_steps' : [],
        'products' : {},
        'local_dir' : ".",
    }

    required_conf = ['url']

    tag = 'wget'

    def _get_url(self):
        return self.conf['url']

    def _get_package_info(self):
        url_split = self._get_url().split('/')
        self.package_name = url_split[-1]
        self.package_path = self.local_dir / self.package_name
        if self.package_path.isfile():
            return True
        return False
    
    def _wget(self):
        self.local_dir.remove()
        self.local_dir.mkdir()
        auto.run('wget ' + self._get_url() + ' --no-cache --retry-connrefused '
                 + ' -O ' + self.package_path)

    def _do_update(self):
        if self._get_package_info() and self._built_tag.isfile():
            log.debug("package %s already exists" % self.package_path)
            if self.conf['download']:
                self.package_path.remove()
                self._wget()
            else:
                self._build_step_flag = False
        else:
            self._wget()

    def desc(self):
        return "Wget Resource %s" % (self.package_name)

