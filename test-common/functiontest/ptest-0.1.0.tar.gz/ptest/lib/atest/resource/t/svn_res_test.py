# -*- coding: utf8 -*-
from atest.resource.svn import SVNResource
url_base = 'http://svn.simba.taobao.com/svn/ECommercePlatform_Aliyun/Engine-Platform/search_basics/atest/branches/atest_1_1/lib/atest/resource/t/'

# new
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
    }
)

built_tag = sample_svn_res.path / 'res_built.tag'
path = sample_svn_res.local_dir
path.remove()
sample_svn_res.build()
print (path / 'hello_world').read()
assert (path / 'hello_world').read() == "hello, world!\n"
assert sample_svn_res._svn_info['url'] == url_base + 'sample_svn_res'
assert int(sample_svn_res._svn_info['revision']) != 0

(path / "ncv_online").touch()
(path / "hello_world").write("blah")

# update = false, revert = false
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'update' : 'false',
    }
)

sample_svn_res.build()
assert not (path / "ncv_online").isfile()
assert (path / 'hello_world').read() == "hello, world!\n"
(path / "ncv_online").touch()
(path / "hello_world").write("blah")

# update = true, revert = false
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
    }
)

built_tag.remove()
sample_svn_res.build()
assert (path / "ncv_online").isfile()
assert (path / 'hello_world').read() == "blah"
(path / "ncv_online").touch()
(path / "hello_world").write("blah")

# update=true, revert=true
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'revert' : 'true'
    }
)

built_tag.remove()
sample_svn_res.build()
assert (path / 'ncv_online').isfile()
assert (path / 'hello_world').read() == "hello, world!\n"

# update=false revision
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'update' : 'false',
        'revision' : 90821,
    }
)

built_tag.remove()
sample_svn_res.build()
assert (path / 'hello_world').read() == "hello, world!\n\n"
assert sample_svn_res._svn_info['revision'] == '90821'

# update=true revision
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'update' : 'true',
        'revision' : '90825',
    }
)

built_tag.remove()
sample_svn_res.build()
assert not (path / 'hello_world_2').isfile()
assert sample_svn_res._svn_info['revision'] == '90825'

# build steps and product
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'update' : 'true',
        'revision' : 90825,
        'build_steps' : [
            'touch product_1',
            'touch product_2'
        ],
        'products' : {
            'product_1' : 'product_1',
            'product_2' : 'product_2'
        }
    }
)

built_tag.remove()
sample_svn_res.build()
assert (path / 'product_1').isfile()
assert (path / 'product_2').isfile()

# url changed
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res_2',
    }
)

built_tag.remove()
sample_svn_res.build()
assert sample_svn_res._svn_info['url'] == url_base + 'sample_svn_res_2'
assert not (path / 'hello_world').isfile()

# local dir specified
sample_svn_res = SVNResource(
    'sample_svn_res',
    {
        'url' : url_base + 'sample_svn_res',
        'update' : 'true',
        'revision' : 90825,
        'local_dir' : 'download',
        'build_steps' : [
            'cd download',
            'touch product_1',
            'touch product_2',
        ],
        'products' : {
            'product_1' : 'download/product_1',
            'product_2' : 'download/product_2'
        }
    }
)

built_tag.remove()
sample_svn_res.build()
assert (path / 'download/product_1').isfile()
assert (path / 'download/product_2').isfile()

