import time
from atest.path import Path

import atest.resource as res
from atest.resource import ATestResourceError
from atest.test.fixture import BaseTestFixture

class LocalDirTestFixture(BaseTestFixture):

    def case_setup(self, case):
        for key in res._res_cache.keys():
            if key.startswith('local_dir'):
                del res._res_cache[key]


        case.base = Path('/tmp/atest_local_dir_res')
        case.base.remove()
        case.base.mkdir()
        (case.base / 'sample').write('0')

    def case_teardown(self, case):
        pass


def tc_without_path(tc):
    try:
        res.get('local_dir_without_path')
        raise Exception("Expect an exception")
    except ATestResourceError:
        pass


def tc_normal(tc):
    res.get('local_dir')


def tc_local_dir_param(tc):
    path = res.get('local_dir_with_local_dir').path
    assert (path / 'sub').isdir()
    assert (path / 'sub' / 'sample').read() == '0'


def tc_with_build_steps(tc):

    path = res.get('local_dir_with_build_steps').path
    assert (path / 'ncv').read() == 'hello\n'


def tc_with_build_again(tc):
    path = res.get('local_dir_with_build_steps').path
    assert (path / 'ncv').read() == 'hello\n'

    time.sleep(2)

    (path / 'ncv').write('blah')
    for key in res._res_cache.keys():
        resaddr = key.split('@')[0]
        if resaddr == 'local_dir_with_build_steps':
            del res._res_cache[key]

    path = res.get('local_dir_with_build_steps').path
    assert (path / 'ncv').read() == 'hello\n'


def tc_with_build_again_no_change(tc):
    path = res.get('local_dir_with_build_steps').path
    assert (path / 'ncv').read() == 'hello\n'

    start = (path / 'res_built.tag').read()

    for key in res._res_cache.keys():
        resaddr = key.split('@')[0]
        if resaddr == 'local_dir_with_build_steps':
            del res._res_cache[key]

    path = res.get('local_dir_with_build_steps').path
    assert (path / 'ncv').read() == 'hello\n'
    end = (path / 'res_built.tag').read()
    assert start == end

