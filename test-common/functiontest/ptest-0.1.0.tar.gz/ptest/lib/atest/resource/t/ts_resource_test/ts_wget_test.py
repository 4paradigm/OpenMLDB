import atest.resource as res

def tc_normal(tc):
    res.get('sample_wget_res')
