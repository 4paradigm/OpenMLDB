import atest.auto as auto
import atest.resource as res

def tc_normal(tc):

    url = "http://dev3.dev.sd.aliyun.com/packages/atest-1.1.8.tar.gz"
    auto.run("wget %s -O /tmp/sample.tar.gz" % url)

    res.get('sample_tar_res')
