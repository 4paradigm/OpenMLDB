import atest.resource as res

def tc_normal(tc):
    res.get('sample_svn_res')
