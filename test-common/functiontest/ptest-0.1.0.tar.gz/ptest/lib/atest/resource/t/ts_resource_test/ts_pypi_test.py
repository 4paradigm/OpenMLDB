import atest.auto as auto
import atest.resource as res

def tc_normal(tc):

    res.get('sample_pypi_res')
