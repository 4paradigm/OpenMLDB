import os

import atest.path
from atest.path import Path
import atest.log as log
import atest.auto as auto
from atest.resource import HelperResource, ATestResourceError


class LocalDirResourceError(ATestResourceError):
    pass


class LocalDirResource(HelperResource):

    tag = 'localdir'

    default_conf = {
        'build_steps' : [],
        'products' : {},
        'local_dir' : '.',  # a relative dir from the base dir, used in subclasses like svn resource
    }

    required_conf = ['path']

    report = True

    def __init__(self, res_addr, conf):

        HelperResource.__init__(self, res_addr, conf)

        # dealing with build steps
        build_steps = self.conf['build_steps']
        if isinstance(build_steps, str):
            self.conf['build_steps'] = [build_steps]

        self.products = {}
        self.local_dir = self.path / self.conf['local_dir']

    def _get_max_mtime(self, path):
        return max([float(f.mtime()) for f in path.tree()])
        
    def _get_min_mtime(self, path):
        return min([float(f.mtime()) for f in path.tree()])

    def _check_built_time(self, built_tag):
        try:
            built_time = float(built_tag.read())
        except ValueError:
            return

        max_mtime = self._get_max_mtime(self.local_dir)

        if built_time >= max_mtime:
            self._build_step_flag = False

    def build_once(self):
        log.info("Building %s resource %s ..." % (self.tag, self.addr))

        self._build_step_flag = True
        self._built_tag = self.path / 'res_built.tag'

        self._do_update()

        if self._build_step_flag:
            self._do_build_steps()

        self._do_prepare_products()

    def _do_update(self):
        self.local_dir.remove()
        self.dest_path = Path(self.conf['path'])

        if not self.dest_path.isdir():
            raise LocalDirResourceError("Local dir '%s' doesn't exists." % self.dest_path)

        auto.run("ln -sf %s %s" % (self.dest_path, self.local_dir))
        
        if self._built_tag.isfile():
            self._check_built_time(self._built_tag)

    def _do_prepare_products(self):
        for name, product in self.conf['products'].iteritems():
            product_path = self.path / product
            if not product_path.exists():
                raise ATestResourceError(
                    "product '%s' doesn't exists after building %s resource %s : %s ..."
                    % (product, self.tag, self.addr, product_path)
                )
            self.products[name] = product_path
            
    def _gen_env_values(self):
        res_src_dir = self.res_file.dirname()

        return {
            'RES_SRC_DIR' : res_src_dir,
            'ATEST_HOME_PATH' : atest.path.home_path(),
            'TMP_DIR' : atest.path.tmp_path(),
        }


    def _do_build_steps(self):
        self._built_tag.remove()
        # execute additional build steps
        if self.conf['build_steps']:
            auto.cmd(
                "cd %s; sh -xe" % self.path,
                env=self._gen_env_values()
            ).run(stdin=self.conf['build_steps'])
        max_mtime = self._get_max_mtime(self.local_dir)
        self._built_tag.write(str(max_mtime))

    def desc(self):
        return "LocalDir Resource %s" % self.conf['path']

