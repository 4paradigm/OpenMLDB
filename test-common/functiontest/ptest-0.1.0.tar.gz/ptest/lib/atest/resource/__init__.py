# -*- coding: utf8 -*-
import re
import copy
import json
import traceback
import ConfigParser

import atest.log as log
import atest.path
import atest.path.remote
import atest.modld
from atest.exception import ATestException
from atest.addr import ATestAddrContainer
from atest.addr import ATestAddrError
import atest.test.param


class ATestResourceError(ATestException):
    pass


class ATestBaseResource:

    report = False 
    skip_destroy_if_build_failed = True

    def __init__(self, res_addr, conf={}, default_conf={}):
        self.addr = res_addr
        self.conf = copy.deepcopy(default_conf)
        if conf.keys():
            self.conf.update(conf)

        self.path = atest.path.home_data_path() / 'rescache' / self.addr
        self.path.mkdir()

        self.built_flag = False
        self.build_failed = False
        self.destroyed_flag = False
        self.destroy_failed = False
        self.dependers = []
        self.dependees = []

    def remote_res_path(self, host):
        return atest.path.remote.remote_home_data_path(host) / 'rescache' / self.addr

    def add_depender(self, depender):
        tmp = []

        for item in self.dependers:
            if not item.addr == depender.addr:
                tmp.append(item)

        tmp.append(depender)
        self.dependers = tmp
        
    def add_dependee(self, dependee):
        tmp = []

        for item in self.dependees:
            if not item.addr == dependee.addr:
                tmp.append(item)

        tmp.append(dependee)
        self.dependees = tmp

    def _do_build(self):
        try:
            self.build_once()
        except KeyboardInterrupt as e:
            raise e
        except BaseException as e:
            self.build_failed = True
            log.warn(
                "Failed to build resource %s: %s: %s\n%s"
                % (self.addr, e.__class__.__name__, str(e), 
                   traceback.format_exc())
            )
            raise ATestResourceError(
                "%s build failed: %s: %s" % 
                (self.addr, e.__class__.__name__, str(e))
            )


    def build(self):

        if self.build_failed:
            raise ATestResourceError(
                "%s: Previous build failed, skip" % self.addr
            )

        if not self.built_flag:
            for dependee in self.dependees:
                dependee.build()

        if not self.built_flag:
            log.debug("Building resource %s ..." % self.addr)
            self._do_build()
            self.built_flag = True

        if self.report:
            atest.test.param.append(self.addr, self.desc())

    def build_once(self):
        pass

    def _do_destroy(self):
        try:
            self.destroy_once()
        except KeyboardInterrupt as e:
            raise e
        except BaseException as e:
            self.destroy_failed = True
            log.warn(
                "Failed to destroy resource %s: %s: %s\n%s"
                % (self.addr, e.__class__.__name__, str(e), 
                   traceback.format_exc())
            )
            raise ATestResourceError(
                "%s destroy failed: %s: %s" % 
                (self.addr, e.__class__.__name__, str(e))
            )


    def destroy(self):
        if not self.built_flag and self.skip_destroy_if_build_failed:
            return

        if self.destroy_failed:
            raise ATestResourceError(
                "%s: Previous destroy failed, skip" % self.addr
            )

        if not self.destroyed_flag:

            for depender in self.dependers:
                depender.destroy()

            log.debug("Destroying resource %s ..." % self.addr)
            self._do_destroy()
            self.destroyed_flag = True

    def destroy_once(self):
        pass

    def xget(self):
        return self

    def desc(self):
        pass


class HelperResource(ATestBaseResource):

    tag = 'helper'
    default_conf = {}
    required_conf = []

    def __init__(self, res_addr, conf):

        ATestBaseResource.__init__(self, res_addr, conf, default_conf=self.default_conf)

        for required in self.required_conf:
            if required not in self.conf:
                raise ATestResourceError(
                    "Param '%s' required for %s resource '%s'." % (required, self.tag, self.addr)
                )

        for k, v in self.conf.iteritems():
            if v == 'true':
                self.conf[k] = True
            if v == 'false':
                self.conf[k] = False
        
        self.path.mkdir()



def get_static_res(res_addr, build=True):
    
    global _res_cache
    res_file = None
    try:
        res_file = _curr_res_cntr.get(res_addr)
    except ATestAddrError, e:
        log.debug("Caught exception when getting resource '%s': %s" % (res_addr, e))
        raise ATestResourceError("Failed to get resource '%s'" % res_addr)
    res_key = res_addr + '@' + res_file

    # check if the resource is already in the cache
    if res_key in _res_cache:
        res_inst = _res_cache[res_key]
        if res_inst.build_failed:
            raise ATestResourceError("Resource %s built failed in the previous request." % res_addr)
        return _res_cache[res_key]

    if res_file.endswith('.res.json'):
        try:
            res_conf = json.loads(res_file.read())
        except ValueError as e:
            raise ATestResourceError("Failed to read resource file %s: %s" % (res_file, e))
    else:
        raise ATestResourceError("Failed to read resource file %s: unsupported format." % res_file)
    
    # check resource interpreting module name
    if 'module' not in res_conf:
        raise ATestResourceError(
            "No 'module' specified in resource file %s" % res_file
        )

    # load the module, new the instance
    module = res_conf['module']
    res_class = atest.modld.load_class(module, ATestBaseResource)
    res_inst = res_class(res_addr, res_conf)
    res_inst.res_file = res_file

    _res_cache[res_key] = res_inst
    if build:
        res_inst.build()

    return res_inst


def get_dynamic_res(res_addr, build=True):
    global _res_cache
    if res_addr in _res_cache:
        res_inst = _res_cache[res_addr]
        if build:
            res_inst.build()

        return res_inst
    else:
        raise ATestResourceError("No such dynamic resource: %s" % res_addr)


def get(res_addr):
    if res_addr.startswith('__dynamic__'):
        return get_dynamic_res(res_addr).xget()
    else:
        return get_static_res(res_addr).xget()


def set_res(res_addr, res):
    global _res_cache
    res_key = '__dynamic__.' + res_addr
    _res_cache[res_key] = res
    res.addr = res_key
    return res_key

def set_dependency(depender, dependee):
    depender.add_dependee(dependee)
    dependee.add_depender(depender)


def append_res_dir(res_dir):
    global _curr_res_cntr
    res_data = _read_res(res_dir)
    _curr_res_cntr.append(res_data)


def append_init_res_dir(res_dir):
    global _init_res_cntr
    global _curr_res_cntr
    res_data = _read_res(res_dir)
    _init_res_cntr.append(res_data)
    _curr_res_cntr.append(res_data)


def reset_res():
    global _curr_res_cntr
    _curr_res_cntr = _init_res_cntr.clone()


def init_res():
    global _init_res_cntr
    global _curr_res_cntr
    global _res_cache
    _res_cache = {}
    _init_res_cntr = ATestAddrContainer({})
    for path in [atest.path.atest_path() / 'res', atest.path.home_path(_mkdir=False) / 'res']:
        _init_res_cntr.append(_read_res(path))
    _curr_res_cntr = _init_res_cntr.clone()


def destroy_all():
    global _res_cache
    for res_key, res_inst in _res_cache.iteritems():
        res_addr = res_key.split('@')[0]
        try:
            res_inst.destroy()
        except ATestResourceError:
            pass
    _res_cache = {}


def _read_res(res_dir, base_key=""):
    if not res_dir.isdir():
        return {}

    res_data = {}

    for item in res_dir:
        item_name = item.basename().split('.')[0]
        if item.isdir():
            ret_data = _read_res(item, base_key="."+item_name)
            res_data[item_name] = ret_data
        elif item.basename().endswith('.res.json'):
            res_data[item_name] = item

    return res_data

# init steps
_res_cache = {}
_init_res_ctnr = None
_curr_res_ctnr = None
init_res()

__import__('pkg_resources').declare_namespace(__name__)
