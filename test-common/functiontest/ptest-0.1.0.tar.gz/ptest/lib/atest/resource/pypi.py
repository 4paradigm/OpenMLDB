import re
import urllib2
from urllib2 import HTTPError
from HTMLParser import HTMLParser
from collections import OrderedDict
from pkg_resources import parse_version

import atest.path
import atest.log as log
import atest.auto as auto
from atest.resource.wget_tar import WgetTarResourceError, WgetTarResource


class PyPIResourceError(WgetTarResourceError):
    pass


class PyPIResource(WgetTarResource):
    
    tag = 'pypi'
    default_conf = {
        'download' : False,  # DON'T CHANGE
        'build_steps' : [],
        'products' : {},
        'local_dir' : ".",   # DON'T CHANGE
        'rename' : True,     # DON'T CHANGE
        'version' : "<newest>", # package version
        'urlbase' : 'http://pypi.python.org/packages/source',
        'install' : True,
        'target_module' : '<none>',
        'python_version' : '2.7',
        'python_binary' : '<none>',
    }
    required_conf = ['name']
    report = True


    def _get_newest_version(self, name, list_page):

        log.info("Trying to find the newest version of '%s' ..." % name)
        
        class NewestVersionFinder(HTMLParser):

            def __init__(self):
                HTMLParser.__init__(self)
                self.version = "0.0.0"

            def handle_starttag(self, tag, attrs):
                if tag != 'a':
                    return

                attrs = OrderedDict(attrs)

                if 'href' not in attrs:
                    return

                href = attrs['href']
                match = re.match("(\S+)-(\d+\.\d+\.\d+(\w\d+)?)\.tar\.gz$", href)

                if not match or match.group(1) != name:
                    return

                tmp_version = match.group(2)
                if parse_version(tmp_version) > parse_version(finder.version):
                    finder.version = tmp_version

        try:
            fp = urllib2.urlopen(list_page, timeout=30)
            html = fp.read()
        except HTTPError as e:
            if 'Not Found' in str(e):
                raise PyPIResourceError("Package '%s' not found." % name)
            else:
                raise PyPIResourceError("Failed to get newest version of '%s'." % name)
            
        finder = NewestVersionFinder()
        finder.feed(html)

        if finder.version == "0.0.0":
            raise PyPIResourceError(
                "Failed to find newest version of '%s' in %s"
                % (name, list_page)
            )

        version = finder.version
        log.info("Found newest version %s for python package '%s'." % (version, name))
        return version

    def _get_url(self):
        return self._url

    def _do_update(self):

        packname = self.conf['name']
        list_page = self.conf['urlbase'] + '/' + packname[0] + '/' + packname
        # decide version
        self._version = self.conf['version']
        if self._version == '<newest>':
            self._version = self._get_newest_version(packname, list_page)

        self._url = list_page + '/' + packname + '-' + self._version + '.tar.gz'

        WgetTarResource._do_update(self)

        if self.conf['install'] and not self._built_tag.isfile():
            self._do_install()

    def _do_install(self):
        pybin = self.conf['python_binary']
        if pybin == '<none>':
            pybin = auto.run('which python%s' % self.conf['python_version'])[0]

        auto.run('cd %s; %s setup.py install' % (self.local_dir, pybin), root_user=True)

        # after we did sudo ops, change the permission back
        auto.run('cd %s; chmod -R a+rw *' % self.local_dir, root_user=True)

        if self.conf['target_module'] != "<none>":
            for module in [x.strip() for x in self.conf['target_module'].split(';')]:
                ret = auto.run_classic("%s -c 'import %s'" % (pybin, module))[2]
                if ret != 0:
                    raise PyPIResourceError(
                        "Failed to import %s after built python package %s." % (module, self.conf['name'])
                    )

    def desc(self):
        return "PyPI Resource %s version=%s" % (self.conf['name'], self._version)

