# -*- coding: utf8 -*-
import traceback

from atest.log import ATestLogger
from atest.exception import ATestException
import atest.log as log

class InvalidError(Exception):
    pass

class ValidError(ATestException):
    pass

def test_1():
    # test a serial of logs
    log.trace("this is a trace log")
    log.debug("this is a debug log")
    log.info("this is an info log")
    log.prio("this is a priority log")
    log.warn("this is a warning log")

    log.error("this is an error log with an invalid exception")

def test_4():
    log.info([1, 2, 3])
    log.info("args string %s", "ncv")


def test_2():
    # test log file recording
    logger = ATestLogger('atest') 
    logger.addHandler(log.StandardFileLogHandler("test.log"))
    log.trace("this is a trace log")
    log.debug("this is a debug log")
    log.info("this is an info log")
    log.prio("this is a priority log")
    log.warn("this is a warning log")
    log.error("this is an error log with a valid exception")

    

test_1()
test_4()
test_2()
