# -*- coding: utf8 -*-
from atest.conf import ATestConf

def base_class_test():

    conf = ATestConf({
        'key1' : 'value1',
        'key2' : {
            'key3' : 'value3',
        }
    })
    conf.get('key1') == 'value1'
    conf.get('key3.key3') == 'value3'
