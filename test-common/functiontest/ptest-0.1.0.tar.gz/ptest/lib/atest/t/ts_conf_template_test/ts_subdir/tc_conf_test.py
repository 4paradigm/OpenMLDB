import atest.conf as conf
import atest.log as log

log.info("service.name = %s", conf.get('service.name'))
log.info("service.host = %s", conf.get('service.host'))
log.info("service.na = %s", conf.get('service.na'))

