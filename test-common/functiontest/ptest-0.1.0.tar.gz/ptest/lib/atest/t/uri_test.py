# -*- coding: utf8 -*-
from atest.uri import ATestURIContainer

def base_test():

    uri = ATestURIContainer({
        'key1' : 'value1',
        'key2' : {
            'key3' : 'value3',
        }
    })
    assert uri.get('key1') == 'value1'
    assert uri.get('key2.key3') == 'value3'

def complicated_test():

    uri = ATestURIContainer(
        {
            'key1' : 'value1',
            'key2' : {
                'key3' : 'value3',
                'key4' : ['ncv', 'online'],
                'key5' : {
                    'key6' : 'value6',
                    'key7' : 'value7'
                }
            }
        },
        data_source = [
            ('key1', 'key1.file'),
            ('key2', 'key2.file')
        ]
    )

    assert uri.get('key2.key4') == ['ncv', 'online']
    uri.append(
        {
            'key1' : ['blah', 'blah'],
            'key2' : {
                'key5' : {
                    'key7' : ['ncv', 'ncv']
                }
            },
            'key8' : 'value8'
        },
        data_source = [
            ('key2', 'key2_new.file'),
            ('key8', 'key8.file')
        ]
    )
    assert uri.get('key1') == ['blah', 'blah']
    assert uri.get('key2.key3') == 'value3'
    assert uri.get('key2.key4') == ['ncv', 'online']
    assert uri.get('key2.key5.key6') == 'value6'
    assert uri.get('key2.key5.key7') == ['ncv', 'ncv']
    assert uri.get('key8') == 'value8'
    print uri.uri_data

base_test()
complicated_test()
