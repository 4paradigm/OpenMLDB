# -*- coding: utf8 -*-
#!/usr/bin/python

# TestTarget: lib/atest/termcolor.py

from atest.termcolor import cprint

# test if a normal string works
cprint("hello, word!\n")

# test if a simple colorful string works
cprint("<C=c>hello, world!</C>\n")

# test if two color tags works together
cprint("I am <C=c>Haowei</C> Yao. <C=r>Hi, my friend</C>\n")

# test if doc style marks work
cprint("<C=*4/>|<C=$12>blah</C>|<C=^10>shit</C>|\n")

# test if nested color tags work
cprint("<C=*4c>ATest Test Framework<C=*4r>0.1.0.0</C><C=*8/>Command Line Interface</C>\n")


names = ["Ross", "Rachel", "Phoebe", "Monica", "Joey", "Chandler"]
colors = ["Monday", "Pink", "Green", "Red", "White", "Yellow"]
for i in range(0, 6):
    cprint("<C=*5/><C=b^6>%s</C> likes <C=g$6>%s</C>.\n" % (names[i], colors[i]))
