# -*- coding: utf8 -*-
#
#
# @ts_info@
#
# @ts_type      classic
# @loader       galaxy.test.loader
#


# @tc_ncv_online@
def tc_ncv_online(tc):
    # @purpose test ncv online
    pass
