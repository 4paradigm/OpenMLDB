# -*- coding: utf8 -*-
import traceback
import time

import atest.auto as auto
from atest.auto import AutoCmdRetcodeError, AutoCmdTimedOut
import atest.log as log
log.set_logger(log.ATestLogger(terminal_level='trace'))

# test local commands
def test_local():
    # test sync commands
    auto.cmd("echo hello | grep hello").run()

    try:
        auto.cmd("ls blahblahblah").run()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    auto.cmd("echo error >&2").run()

    try:
        auto.cmd("sleep 5", timeout=0.5).run()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    # test async commands
    daemon = auto.cmd(
        "for i in 1 2 3 4 5; do sleep 0.5; echo $i; done"
    ).daemon()
    daemon.wait()

    daemon = auto.cmd("echo error >&2").daemon()
    daemon.wait()

    try:
        daemon = auto.cmd("ls blahblahblah").daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    try:
        daemon = auto.cmd("sleep 5", timeout=0.5).daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    daemon = auto.cmd("sleep 9", timeout=0.5).daemon()
    daemon.terminate()

    daemon = auto.cmd("sleep 5; echo hello | grep hello").daemon()
    daemon.terminate()

    daemon1 = auto.daemon("sleep 5;")
    daemon2 = auto.daemon("sleep 5;")
    daemon1.kill()
    daemon2.kill()

    # test interact commands
    auto.cmd(
        "for i in 1 2; do sleep 0.5; echo you will see this line twice; done"
    ).interact()
    try:
        auto.cmd("ls blahbalhasdfklajsdl").interact()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()


def test_remote():
    # test sync commands
    auto.cmd("echo hello | grep hello", remote="localhost").run()
    
    try:
        auto.cmd("ls blahblahblah", remote="localhost").run()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    print "hit"
    auto.cmd("echo error >&2", remote="localhost").run()

    try:
        auto.cmd("sleep 5", remote="localhost", timeout=0.5).run()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    # test async commands
    daemon = auto.cmd(
        "for i in 1 2 3 4 5; do sleep 0.5; echo $i; done",
        remote="localhost"
    ).daemon()
    daemon.wait()

    daemon = auto.cmd("echo error >&2", remote="localhost").daemon()
    daemon.wait()

    try:
        daemon = auto.cmd("ls blahblahblah", remote="localhost").daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    try:
        daemon = auto.cmd("sleep 5", remote="localhost", timeout=0.5).daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    daemon = auto.cmd("sleep 1111", remote="localhost", timeout=0.5).daemon()
    daemon.kill()

    daemon = auto.cmd(
        "sleep 5; echo hello | grep hello", remote="localhost"
    ).daemon()
    daemon.terminate()

    auto.kill_daemons()


def test_root_user():
    # test sync commands
    auto.cmd("echo hello | grep hello", root_user=True).run()
    
    try:
        auto.cmd("ls blahblahblah", root_user=True).run()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    auto.cmd("echo error >&2", root_user=True).run()

    try:
        auto.cmd("sleep 5", root_user=True, timeout=0.5).run()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    # test async commands
    daemon = auto.cmd(
        "for i in 1 2 3 4 5; do sleep 0.5; echo $i; done",
        root_user=True
    ).daemon()
    daemon.wait()

    daemon = auto.cmd("echo error >&2", root_user=True).daemon()
    daemon.wait()

    try:
        daemon = auto.cmd("ls blahblahblah", root_user=True).daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdRetcodeError, e:
        traceback.print_exc()

    try:
        daemon = auto.cmd("sleep 5", root_user=True, timeout=0.5).daemon()
        daemon.wait()
        log.error("Expected an exception")
    except AutoCmdTimedOut, e:
        traceback.print_exc()

    daemon = auto.cmd("sleep 1111", root_user=True, timeout=0.5).daemon()
    daemon.kill()

    daemon = auto.cmd(
        "sleep 5; echo hello | grep hello", root_user=True
    ).daemon()
    daemon.terminate()

    auto.kill_daemons()


def test_shortcuts():

    auto.run("echo hello")
    auto.daemon("sleep 30")
    auto.interact("echo hello")

    stdout, stderr, retcode = auto.run_classic('echo hello')
    assert stdout == "hello\n"
    assert stderr == ""
    assert retcode == 0
    stdout, stderr, retcode = auto.run_classic('ls alsdkfkla')
    assert retcode != 0
    auto.kill_daemons()


def test_wired_usage():
    auto.run("sleep 30 &")


def test_codec():
    auto.run("cat", stdin=["中国"])
    auto.run("cat", stdin=[u"中国"])
    auto.run("cat", stdin=["blah\x80"])


def test_bigdata():
    log.info("testing big input, if you didn't see next log very soon, the case is failed")
    start_time = time.time()
    auto.run('cat', stdin=['-' * 1024 * 1024 * 1024])
    stop_time = time.time()
    log.info("Duration = %.3f" % (stop_time - start_time))

test_local()
test_remote() # TODO reopen
#test_root_user() # TODO reopen
test_shortcuts()
test_wired_usage()
#test_codec()
test_bigdata()
print "Passed"

