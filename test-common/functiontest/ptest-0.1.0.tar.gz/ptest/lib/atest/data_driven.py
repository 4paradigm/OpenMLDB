#!/bin/env python
# -*- coding:utf-8 -*-

"""Data-driven APIs testing framework.
@version: 0.0.3
@author: U{jingcheng.lijc<mailto:jingcheng.lijc@aliyun-inc.com>}
@see: U{http://grd.alibaba-inc.com/projects/galaxy/wiki/data_driven_API}
"""

import os
import types
import inspect

import atest.log as log

log.warn("Use of atest.data_driven is deprecated. Please use atest2 style data driven instead.")

class DataDriven:
    """
    Features:
    1. Api form of data-driven support;
    2. Test-driven programming framework to reduce the test-driven development of complexity;
    3. The test data must follow the test data format definition.
    """

    def __init__(self, suite_cls):
        """
        @param suite_cls: Test suite class, eg: sut_data_driven_test.py
        """
        self.suite_cls = suite_cls
        self.case_index = {}
        self.case_datas = {}
        self.executable_ids = {}

    def get_case_input(self):
        """
        @return: Datas of a subset of a case input.
        @rtype: dict type.
        """
        method_tmpl_name = inspect.stack()[1][3]
        executable_ids = filter(lambda x: self.case_index[method_tmpl_name] < x, self.executable_ids[method_tmpl_name])
        if executable_ids:
            self.case_index[method_tmpl_name] = executable_ids[0]
        else:
            self.case_index[method_tmpl_name] += 1
        return self.case_datas[method_tmpl_name][self.case_index[method_tmpl_name]]

    def create_case(self, method_tmpl_name, data_file_path, executable_ids=[]):
        """
        @param method_tmpl_name: Custom case template method, and must be the beginning of this, not 'test_': 
        >>> def case_template(self):
        ...    data = self.dd.get_case_input()
        @param data_file_path: Test data file name or list.
        @param executable_ids: executable id or id list.
        """
        self.case_index[method_tmpl_name] = -1
        self.case_datas[method_tmpl_name] = {}
        self.executable_ids[method_tmpl_name] = executable_ids if type(executable_ids) == types.ListType else [executable_ids]
        data = {}
        data_file_paths = data_file_path if type(data_file_path) == types.ListType else [data_file_path]
        for data_file_path in data_file_paths:
            data_file_path = os.path.join(os.path.dirname(inspect.stack()[1][1]), data_file_path)
            lines = open(data_file_path, "r").readlines()
            lines.append("=")
            for line in lines:
                if line.startswith("=") and data:
                    num = len(self.case_datas[method_tmpl_name])
                    method_object_name = "test_%s_dd_%s" % (method_tmpl_name, num)
                    data["case_name"] = method_object_name
                    self.case_datas[method_tmpl_name][num] = data
                    if not self.executable_ids[method_tmpl_name] or num in self.executable_ids[method_tmpl_name]:
                        method = getattr(self.suite_cls, method_tmpl_name).im_func
                        setattr(self.suite_cls, method_object_name, method)
                    data = {}
                elif line.startswith("#") or line.startswith("=") or not line.strip():
                    continue
                else:
                    fields = line.strip().split(None, 1)
                    fields = [field.strip() for field in fields]
                    data[fields[0]] = fields[1] if len(fields) == 2 else ""
